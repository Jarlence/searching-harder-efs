"""Independently recompute complete X12m results; never fit a learner.

--selftest uses in-memory, hand-computable synthetic scores only.
--verify requires the final 800-job analysis and writes a new check receipt.
The production analysis module and its aggregation functions are never imported.
"""
import argparse
import copy
import csv
import hashlib
import importlib
import json
import math
import os
import statistics
import sys
import tempfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from scipy.stats import t

ROOT = Path(__file__).resolve().parents[3]
DEFAULT_RECEIPT = Path(__file__).with_name("independent_x12m_receipt.json")
EXPECTED_FREEZE_SHA256 = "745f1ffecba10f08f1f3870ae91280caca6c7ec77047814e9d0350b61895db69"
CONFIGS = (("ga", "ridge"), ("nsga2", "knn"))
EXPECTED_OUTPUTS = {
    name + ".csv" for name in (
        "per_run_components", "dataset_effects", "family_summary", "component_levels",
        "dataset_component_levels", "paired_advantages", "dataset_paired_advantages",
        "ordinary_reference", "dataset_ordinary_reference", "execution")
} | {"job_hashes.json", "comparator_hashes.json", "family_summary.json", "REPORT.md"}
ABS_TOL_PP = 1e-9


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def valid_digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def job_key(spec):
    return spec["ds"], spec["algo"], spec["learner"], spec["rep"], spec["fold"]


def check_design(specs, datasets):
    datasets = tuple(datasets)
    require(len(datasets) == len(set(datasets)) == 8, "Exactly eight datasets are required")
    expected = {(ds, algo, learner, rep, fold) for ds in datasets for algo, learner in CONFIGS
                for rep in range(10) for fold in range(5)}
    keys = []
    for spec in specs:
        require(set(spec) == {"suite", "kind", "ds", "algo", "learner", "rep", "fold", "budget"},
                "Unexpected job specification fields")
        require(spec["suite"] == "X12m" and spec["kind"] == "strict_samesize_rs" and spec["budget"] == 4000,
                "Changed suite or request budget")
        require(all(type(spec[field]) is int for field in ("rep", "fold", "budget")),
                "Repeat, fold and budget must be integers")
        keys.append(job_key(spec))
    require(len(keys) == len(set(keys)) == 800 and set(keys) == expected,
            "Complete, unique, exact 800-job coverage is required")


def score(row):
    values = []
    for name in ("inner_err", "test_ba"):
        value = row[name]
        require(type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1,
                "Invalid raw BA score: " + name)
        values.append(value)
    require(type(row["calls"]) is int and row["calls"] == 4000, "Wrong request count")
    require(type(row["distinct"]) is int and 1 <= row["distinct"] <= 4000, "Invalid distinct count")
    require(type(row["k"]) is int and 1 <= row["k"] <= 100, "Invalid selected cardinality")
    f, outer = 1 - values[0], values[1]
    return {"F": f, "T": outer, "B": f - outer}


def check_learner_counts(record):
    """Each cache miss evaluates five folds; exactly one final outer fit follows.

    CudaFoldScaledWrapper.evaluate calls scores only on a new cache key; scores
    calls _fit_predict_tensors once per inner fold. The final fit_predict_gpu
    calls it once more. Its ridge/knn branch increments the relevant counter.
    """
    learner = record["spec"]["learner"]
    field = "cuda_ridge_fits" if learner == "ridge" else "cuda_knn_distance_matrices"
    distinct = record["result"]["4000"]["distinct"]
    require(type(distinct) is int and 1 <= distinct <= 4000, "Invalid distinct count for fit identity")
    actual = record["gpu_diagnostics"][field]
    expected = 5 * distinct + 1
    require(type(actual) is int and actual == expected,
            "%s: expected 5*distinct+1=%d, found %r" % (field, expected, actual))
    return field, actual


def summarize(dataset_values, family=False):
    """A separate statistics implementation using math/statistics, not NumPy."""
    values = [100 * value for value in dataset_values]
    require(len(values) == 8 and all(math.isfinite(v) for v in values), "Eight finite dataset means required")
    mean = statistics.mean(values)
    sd = statistics.stdev(values)
    se = sd / math.sqrt(8)
    half = float(t.ppf(.975, 7)) * se
    row = dict(n_datasets=8, df=7, mean_pp=mean, sd_pp=sd, se_pp=se,
               ci95_lo_pp=mean-half, ci95_hi_pp=mean+half,
               median_pp=statistics.median(values), min_pp=min(values), max_pp=max(values),
               n_positive=sum(v > 0 for v in values))
    if family:
        family_half = float(t.ppf(.99375, 7)) * se
        row.update(family_n=4, family_confidence=.9875, family_quantile=.99375,
                   family_lo_pp=mean-family_half, family_hi_pp=mean+family_half)
    return row


def recompute(records, datasets):
    """Recompute S/O/D after exact coverage validation, without reading files."""
    records = list(records)
    datasets = tuple(datasets)
    check_design([record["spec"] for record in records], datasets)
    grouped = defaultdict(list)
    ordinary_components = defaultdict(list)
    residual = 0.0
    for record in records:
        require(record["status"] == "ok" and set(record["result"]) == {"4000"}, "Invalid new record")
        spec = record["spec"]
        ds, algo, learner, _, _ = job_key(spec)
        comparators = record["comparators"]
        require(set(comparators) == {"algorithm", "ordinary_rs"}, "Missing comparator role")
        a = score(comparators["algorithm"]["result"])
        r = score(comparators["ordinary_rs"]["result"])
        k = score(record["result"]["4000"])
        require(comparators["algorithm"]["result"]["k"] == record["result"]["4000"]["k"],
                "Same-size reference has the wrong final k")
        s = (a["F"]-k["F"]) - (a["T"]-k["T"])
        o = (a["F"]-r["F"]) - (a["T"]-r["T"])
        d = s-o
        direct = r["B"]-k["B"]
        residual = max(residual, abs(d-direct), abs(s-(a["B"]-k["B"])))
        require(math.isclose(d, direct, abs_tol=1e-12, rel_tol=0), "Algorithm cancellation failed")
        for label, value in (("S", s), ("O", o), ("D", d)):
            grouped[(algo, learner, label, ds)].append(value)
        for field in ("F", "T", "B"):
            ordinary_components[(algo, learner, field, ds)].append(a[field]-r[field])

    def dataset_means(group, prefix):
        values = []
        for ds in datasets:
            runs = group[prefix+(ds,)]
            require(len(runs) == 50, "Each dataset/configuration requires 50 paired runs")
            values.append(statistics.mean(runs))
        return values

    tables = {name: [] for name in ("family_summary", "dataset_effects", "ordinary_reference",
                                    "dataset_ordinary_reference")}
    for algo, learner in CONFIGS:
        meta = dict(algorithm=algo, learner=learner, budget=4000)
        for estimand in ("S", "D"):
            values = dataset_means(grouped, (algo, learner, estimand))
            definition = "B_algorithm-B_same_size_RS" if estimand == "S" else "S-O=B_ordinary_RS-B_same_size_RS"
            label = dict(meta, contrast=estimand+"_"+algo+"_"+learner, estimand=estimand,
                         definition=definition, status="exploratory_four_estimate_family")
            tables["family_summary"].append(dict(label, **summarize(values, family=True)))
            tables["dataset_effects"].extend(dict(label, dataset=ds, runs=50, value_pp=100*value)
                                             for ds, value in zip(datasets, values))
        for field in ("F", "T", "B"):
            values = dataset_means(ordinary_components, (algo, learner, field))
            label = dict(meta, field=field, estimand="O" if field == "B" else field+"_advantage",
                         definition="algorithm-minus-ordinary-RS", status="descriptive_ordinary_reference")
            tables["ordinary_reference"].append(dict(label, **summarize(values)))
            tables["dataset_ordinary_reference"].extend(dict(label, dataset=ds, runs=50, value_pp=100*value)
                                                       for ds, value in zip(datasets, values))
        o_values = dataset_means(grouped, (algo, learner, "O"))
        b_values = dataset_means(ordinary_components, (algo, learner, "B"))
        require(all(math.isclose(x, y, rel_tol=0, abs_tol=1e-12) for x, y in zip(o_values, b_values)),
                "Ordinary-reference O identity failed")
    return tables, residual


def compare_rows(expected, actual, key_fields, label):
    def indexed(rows):
        mapped = {}
        for row in rows:
            key = tuple(str(row[name]) for name in key_fields)
            require(key not in mapped, label + ": duplicate row key " + repr(key))
            mapped[key] = row
        return mapped
    left, right = indexed(expected), indexed(actual)
    require(set(left) == set(right), label + ": missing or extra rows")
    largest = 0.0
    for key, row in left.items():
        found = right[key]
        require(set(row) == set(found), label + ": changed output fields")
        for name, value in row.items():
            if type(value) in (int, float):
                try:
                    observed = float(found[name])
                except (TypeError, ValueError):
                    raise RuntimeError(label + ": nonnumeric " + name)
                require(math.isfinite(observed), label + ": nonfinite " + name)
                if type(value) is int:
                    require(observed == value, label + ": integer mismatch " + name)
                else:
                    largest = max(largest, abs(value-observed))
                    require(math.isclose(value, observed, rel_tol=0, abs_tol=ABS_TOL_PP),
                            "%s: %s mismatch for %r: expected %.17g, found %.17g" %
                            (label, name, key, value, observed))
            else:
                require(found[name] == value, label + ": metadata mismatch " + name)
    return dict(rows=len(left), fields_compared=sum(len(row) for row in expected), max_abs_difference=largest)


def verify_complete(root=ROOT, receipt_path=DEFAULT_RECEIPT):
    """Read real outcomes only after the complete published validation exists."""
    root = Path(root).resolve()
    analysis = root / "results/new_data_samesize"
    validation_path = analysis / "validation.json"
    require(validation_path.is_file(), "Complete analysis validation.json is required before checking any jobs")
    validation = read_json(validation_path)
    required = dict(suite="X12m", jobs=800, checkpoints=800, budget=4000, repeats=10,
                    outer_folds=5, inner_folds=5, family_n=4, family_confidence=.9875,
                    family_quantile=.99375, n_inference_units=8, df=7, inference_unit="dataset",
                    dataset_weighting="equal", no_partial_results=True,
                    independent_confirmation=False, public_preregistration_claim=False)
    require(all(validation.get(name) == value for name, value in required.items()), "Incomplete or changed analysis validation")
    require(validation.get("configs") == [list(config) for config in CONFIGS], "Changed analysis configurations")
    outputs = validation.get("outputs", {})
    require(set(outputs) == EXPECTED_OUTPUTS, "Incomplete analysis output manifest")
    require({p.name for p in analysis.iterdir()} == EXPECTED_OUTPUTS | {"validation.json"},
            "Unexpected or incomplete published analysis files")
    for name, digest in outputs.items():
        path = analysis / name
        require(path.is_file() and not path.is_symlink() and valid_digest(digest) and sha256_file(path) == digest,
                "Analysis output integrity failed: " + name)

    sys.path.insert(0, str(root / "extras"))
    suite = importlib.import_module("ex_suites8")
    require(Path(suite.ROOT).resolve() == root, "Loaded suite belongs to a different workspace")
    require(sha256_file(suite.FREEZE) == EXPECTED_FREEZE_SHA256, "Unexpected X12m execution freeze")
    freeze = suite.frozen(verify_inputs=True)  # Integrity only; no learner fitting.
    require(validation.get("freeze_sha256") == EXPECTED_FREEZE_SHA256 and
            validation.get("source_fingerprint") == freeze["source_fingerprint"] and
            validation.get("gpu_environment") == freeze["gpu_environment"], "Analysis/freeze binding mismatch")
    datasets, jobs = tuple(freeze["datasets"]), freeze["jobs"]
    require(set(validation.get("datasets", [])) == set(datasets), "Dataset inventory changed")
    check_design(jobs, datasets)
    paths = [Path(suite.job_path(spec)).resolve() for spec in jobs]
    require(len(set(paths)) == 800 and all(p.is_file() and not p.is_symlink() for p in paths),
            "All 800 frozen job JSON files are required")
    require({p.resolve() for p in Path(suite.OUTPUT).glob("*.json")} == set(paths), "Unexpected or missing job JSON files")
    records, job_hashes, comparator_hashes = [], {}, {}
    counts = defaultdict(int)
    for spec, path in zip(jobs, paths):
        raw = path.read_bytes()
        record = json.loads(raw)
        suite.validate_record(record, spec)  # Full source/target/split/backend binding.
        field, count = check_learner_counts(record)
        counts[field] += count
        job_hashes[path.relative_to(root).as_posix()] = hashlib.sha256(raw).hexdigest()
        for payload in record["comparators"].values():
            name, digest = payload["path"], payload["sha256"]
            require(name not in comparator_hashes or comparator_hashes[name] == digest, "Comparator hash conflict")
            comparator_hashes[name] = digest
        records.append(record)
    require(job_hashes == read_json(analysis / "job_hashes.json"), "Published job inventory differs from the frozen 800 JSON files")
    require(len(comparator_hashes) == 1600 and comparator_hashes == freeze["comparator_hashes"] and
            comparator_hashes == read_json(analysis / "comparator_hashes.json"), "Comparator inventories disagree")
    tables, residual = recompute(records, datasets)
    comparisons = {}
    table_keys = dict(family_summary=("algorithm", "learner", "estimand"),
                      dataset_effects=("algorithm", "learner", "estimand", "dataset"),
                      ordinary_reference=("algorithm", "learner", "field"),
                      dataset_ordinary_reference=("algorithm", "learner", "field", "dataset"))
    for name, keys in table_keys.items():
        with (analysis / (name+".csv")).open(encoding="utf-8", newline="") as stream:
            comparisons[name+".csv"] = compare_rows(tables[name], list(csv.DictReader(stream)), keys, name)
    comparisons["family_summary.json"] = compare_rows(
        tables["family_summary"], read_json(analysis / "family_summary.json"), table_keys["family_summary"], "family_summary.json")
    receipt = dict(status="passed", created_utc=datetime.now(timezone.utc).isoformat(),
                   checker_sha256=sha256_file(__file__), execution_freeze_sha256=EXPECTED_FREEZE_SHA256,
                   analysis_validation_sha256=sha256_file(validation_path), jobs=800, comparators=1600,
                   datasets=list(datasets), n_inference_units=8, df=7, family_n=4,
                   recomputation="independent raw-record arithmetic and Python statistics; no analysis aggregation import",
                   absolute_comparison_tolerance=ABS_TOL_PP, comparisons=comparisons,
                   max_cancellation_residual_proportion=residual,
                   learner_fit_identity="relevant CUDA counter = 5 * distinct + 1 for every new job",
                   learner_fit_identity_jobs_checked=800, relevant_counter_totals=dict(counts),
                   analysis_output_hashes=outputs, job_hashes=job_hashes,
                   no_learner_fitting=True, no_analysis_or_job_files_modified=True)
    receipt_path = Path(receipt_path)
    require(not receipt_path.exists(), "Existing independent receipt will not be overwritten")
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    # An exclusive create prevents replacement of an existing receipt.
    with receipt_path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(receipt, sort_keys=True, indent=2, allow_nan=False)+"\n")
    return receipt


def selftest():
    """Hand example: S=1..8 pp, D=.2..1.6 pp, O=.8..6.4 pp."""
    datasets = tuple("hand_example_%d" % i for i in range(1, 9))
    records = []
    for index, ds in enumerate(datasets, 1):
        for algo, learner in CONFIGS:
            for rep in range(10):
                for fold in range(5):
                    def row(f):
                        return dict(inner_err=1-f, test_ba=.5, k=3, calls=4000, distinct=2)
                    field = "cuda_ridge_fits" if learner == "ridge" else "cuda_knn_distance_matrices"
                    records.append(dict(status="ok", spec=dict(suite="X12m", kind="strict_samesize_rs",
                        ds=ds, algo=algo, learner=learner, rep=rep, fold=fold, budget=4000),
                        result={"4000": row(.60)}, comparators={
                            "algorithm": dict(result=row(.60+.01*index)),
                            "ordinary_rs": dict(result=row(.60+.002*index))},
                        gpu_diagnostics={field: 11}))
    tables, residual = recompute(records, datasets)
    for result in tables["family_summary"]:
        factor = 1 if result["estimand"] == "S" else .2
        mean, se = 4.5*factor, math.sqrt(.75)*factor
        require(math.isclose(result["mean_pp"], mean, abs_tol=1e-12), "Hand-computed mean failed")
        require(math.isclose(result["sd_pp"], math.sqrt(6)*factor, abs_tol=1e-12), "Hand-computed sample SD failed")
        require(math.isclose(result["se_pp"], se, abs_tol=1e-12), "Hand-computed standard error failed")
        require(math.isclose(result["ci95_lo_pp"], mean-2.3646242515927844*se, abs_tol=1e-10), "Hand 95% CI failed")
        require(math.isclose(result["family_hi_pp"], mean+3.3352949398170852*se, abs_tol=1e-10), "Hand four-estimate CI failed")
    for result in tables["ordinary_reference"]:
        expected = 0 if result["field"] == "T" else 3.6
        require(math.isclose(result["mean_pp"], expected, abs_tol=1e-12), "Hand-computed O failed")
    for result in tables["dataset_effects"]:
        index = datasets.index(result["dataset"])+1
        expected = index*(1 if result["estimand"] == "S" else .2)
        require(math.isclose(result["value_pp"], expected, abs_tol=1e-12), "Hand dataset effect failed")
    for record in records:
        check_learner_counts(record)
    try:
        recompute(records[:-1], datasets)
    except RuntimeError:
        pass
    else:
        raise RuntimeError("Incomplete synthetic coverage was accepted")
    wrong = copy.deepcopy(records[0])
    wrong["gpu_diagnostics"]["cuda_ridge_fits"] = 10
    try:
        check_learner_counts(wrong)
    except RuntimeError:
        pass
    else:
        raise RuntimeError("Incorrect learner-fit identity was accepted")
    published = copy.deepcopy(tables["family_summary"])
    published[0]["mean_pp"] += .1
    try:
        compare_rows(tables["family_summary"], published, ("algorithm", "learner", "estimand"), "synthetic")
    except RuntimeError:
        pass
    else:
        raise RuntimeError("Corrupt published estimate was accepted")
    require(summarize([0.0]*8, family=True)["family_hi_pp"] == 0, "Zero-variance handling failed")
    with tempfile.TemporaryDirectory(prefix="x12m_no_analysis_") as temporary:
        try:
            verify_complete(root=temporary)
        except RuntimeError as exc:
            require("Complete analysis validation.json" in str(exc), "Wrong incomplete-analysis gate")
        else:
            raise RuntimeError("Missing complete analysis was accepted")
    return dict(status="synthetic_selftest_passed", records=800, family_rows=4,
                dataset_effect_rows=32, ordinary_reference_rows=6,
                hand_S_mean_pp=4.5, hand_D_mean_pp=.9, hand_O_mean_pp=3.6,
                learner_fit_identity_checked=True, incomplete_analysis_and_coverage_rejected=True,
                max_cancellation_residual_proportion=residual, real_outcomes_read=False,
                learner_fits=0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--selftest", action="store_true")
    mode.add_argument("--verify", action="store_true")
    parser.add_argument("--receipt", type=Path, default=DEFAULT_RECEIPT)
    args = parser.parse_args()
    if args.selftest:
        result = selftest()
    else:
        receipt = verify_complete(receipt_path=args.receipt)
        result = dict(status=receipt["status"], jobs=receipt["jobs"], receipt=str(args.receipt.resolve()),
                      comparisons=receipt["comparisons"], learner_fit_identity_jobs_checked=800)
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
