"""Export new X12m LaTeX displays from an intact, complete analysis receipt.

No statistical quantities are estimated here. Every displayed number comes from
an existing *_pp CSV field, already in BA percentage points. Default execution
requires results/new_data_samesize/validation.json and verifies every analysis
output hash before writing four new paper/generated files. Existing destination
files are refused, even if their contents match.

API: export_display(source_dir=None, output_dir=None) -> export receipt.
     selftest(passdir) -> synthetic-only test receipt and retained fixture path.
CLI: python export_x12m_display.py
     python export_x12m_display.py --selftest --passdir ABSOLUTE_DIRECTORY
"""
import argparse
import csv
import hashlib
import io
import json
import re
import tempfile
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "results/new_data_samesize"
OUTPUT = ROOT / "paper/generated"
CONFIGS = (("ga", "ridge"), ("nsga2", "knn"))
CONFIG_LABELS = {("ga", "ridge"): "GA--ridge", ("nsga2", "knn"): "NSGA-II--5-NN"}
MACRO_CONFIGS = {("ga", "ridge"): "GaRidge", ("nsga2", "knn"): "NsgaKnn"}
REFERENCES = ("ordinary_rs", "same_size_rs")
OUTPUT_NAMES = ("numbers_x12m.tex", "tab_x12m_family.tex", "tab_x12m_datasets.tex", "tab_x12m_components.tex")
ANALYSIS_OUTPUTS = {
    "per_run_components.csv", "dataset_effects.csv", "family_summary.csv",
    "component_levels.csv", "dataset_component_levels.csv", "paired_advantages.csv",
    "dataset_paired_advantages.csv", "ordinary_reference.csv", "dataset_ordinary_reference.csv",
    "execution.csv", "job_hashes.json", "comparator_hashes.json", "family_summary.json", "REPORT.md",
}


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _valid_sha(value):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value) is not None


def _decimal(row, key):
    try:
        value = Decimal(str(row[key]))
    except (KeyError, InvalidOperation, ValueError):
        raise RuntimeError("Missing or invalid numeric CSV field: " + key)
    if not value.is_finite():
        raise RuntimeError("Nonfinite CSV field: " + key)
    return value


def _require_number(row, key, expected):
    if _decimal(row, key) != Decimal(str(expected)):
        raise RuntimeError("Changed fixed CSV/validation field: " + key)


def _interval(row, family=False):
    low, high = ("family_lo_pp", "family_hi_pp") if family else ("ci95_lo_pp", "ci95_hi_pp")
    mean, lo, hi = _decimal(row, "mean_pp"), _decimal(row, low), _decimal(row, high)
    if not lo <= mean <= hi:
        raise RuntimeError("CSV interval does not enclose its reported mean")
    return lo, hi


def _rows(raw, name):
    try:
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
        if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise RuntimeError("Missing or duplicate CSV headers: " + name)
        result = list(reader)
    except (UnicodeDecodeError, csv.Error) as exc:
        raise RuntimeError("Unreadable CSV: " + name) from exc
    if not result or any(None in row or any(value is None for value in row.values()) for row in result):
        raise RuntimeError("Empty or malformed CSV: " + name)
    return result


def _index(rows, key_fields, expected, name):
    index = {}
    for row in rows:
        try:
            key = tuple(row[field] for field in key_fields)
        except KeyError as exc:
            raise RuntimeError("Missing CSV key in " + name) from exc
        if key in index:
            raise RuntimeError("Duplicate CSV row in " + name)
        index[key] = row
    if set(index) != set(expected):
        raise RuntimeError("Incomplete or changed CSV coverage: " + name)
    return index


def load_verified_summaries(source_dir):
    """Verify the complete output manifest, then parse only display summaries.

    CSV bytes are retained from the hash pass, so rendering consumes the exact
    bytes verified against the receipt. Individual job and comparator records
    are never opened by this display exporter.
    """
    source_dir = Path(source_dir)
    receipt_path = source_dir / "validation.json"
    if not receipt_path.is_file() or receipt_path.is_symlink():
        raise RuntimeError("Complete X12m validation.json is required before export")
    receipt_raw = receipt_path.read_bytes()
    receipt = json.loads(receipt_raw.decode("utf-8"))
    for key, expected in (("jobs", 800), ("checkpoints", 800), ("family_n", 4),
                          ("budget", 4000), ("n_inference_units", 8), ("df", 7),
                          ("family_confidence", ".9875"), ("family_quantile", ".99375")):
        _require_number(receipt, key, expected)
    if (receipt.get("suite") != "X12m" or receipt.get("no_partial_results") is not True or
            receipt.get("configs") != [list(c) for c in CONFIGS] or
            receipt.get("status") != "exploratory_known_eight_datasets" or
            receipt.get("inference_unit") != "dataset" or receipt.get("dataset_weighting") != "equal"):
        raise RuntimeError("Wrong X12m analysis scope or incomplete validation")
    datasets = receipt.get("datasets")
    if (not isinstance(datasets, list) or len(datasets) != 8 or
            any(not isinstance(ds, str) or not ds for ds in datasets) or len(set(datasets)) != 8):
        raise RuntimeError("Exactly eight validated dataset names are required")
    if any(not _valid_sha(receipt.get(key)) for key in ("freeze_sha256", "source_fingerprint")):
        raise RuntimeError("Missing frozen source provenance in validation")
    outputs = receipt.get("outputs", {})
    if set(outputs) != ANALYSIS_OUTPUTS:
        raise RuntimeError("Complete fixed analysis output manifest is required")
    verified = {}
    for name in sorted(ANALYSIS_OUTPUTS):
        path, digest = source_dir / name, outputs[name]
        if path.is_symlink() or not path.is_file() or not _valid_sha(digest):
            raise RuntimeError("Missing or unsafe analysis output: " + name)
        raw = path.read_bytes()
        if _sha(raw) != digest:
            raise RuntimeError("Analysis output hash mismatch: " + name)
        verified[name] = raw

    family = _index(_rows(verified["family_summary.csv"], "family_summary.csv"),
                    ("algorithm", "learner", "estimand"),
                    {(a, l, e) for a, l in CONFIGS for e in ("S", "D")}, "family_summary.csv")
    for (algo, learner, estimand), row in family.items():
        for key, expected in (("budget", 4000), ("n_datasets", 8), ("df", 7),
                              ("family_n", 4), ("family_confidence", ".9875"), ("family_quantile", ".99375")):
            _require_number(row, key, expected)
        if row.get("contrast") != estimand+"_"+algo+"_"+learner:
            raise RuntimeError("Changed family contrast identifier")
        if row.get("status") != "exploratory_four_estimate_family":
            raise RuntimeError("Changed family interpretation")
        _interval(row)
        lo, hi = _interval(row, family=True)
        ordinary_lo, ordinary_hi = _interval(row)
        if lo > ordinary_lo or hi < ordinary_hi:
            raise RuntimeError("Family interval is narrower than its ordinary interval")

    dataset_effects = _index(_rows(verified["dataset_effects.csv"], "dataset_effects.csv"),
                             ("dataset", "algorithm", "learner", "estimand"),
                             {(ds, a, l, e) for ds in datasets for a, l in CONFIGS for e in ("S", "D")},
                             "dataset_effects.csv")
    for row in dataset_effects.values():
        _require_number(row, "budget", 4000)
        _require_number(row, "runs", 50)
        _decimal(row, "value_pp")

    pairs = (("algorithm", "same_size_rs"), ("algorithm", "ordinary_rs"), ("ordinary_rs", "same_size_rs"))
    paired = _index(_rows(verified["paired_advantages.csv"], "paired_advantages.csv"),
                    ("algorithm", "learner", "left", "reference", "field"),
                    {(a, l, left, right, f) for a, l in CONFIGS for left, right in pairs for f in ("F", "T", "B")},
                    "paired_advantages.csv")
    for row in paired.values():
        for key, expected in (("budget", 4000), ("n_datasets", 8), ("df", 7)):
            _require_number(row, key, expected)
        if row.get("status") != "descriptive":
            raise RuntimeError("Component advantages must remain descriptive")
        _interval(row)
    return dict(validation=receipt, validation_sha256=_sha(receipt_raw),
                datasets=datasets, family=family, dataset_effects=dataset_effects, paired=paired)


def _number(value):
    """Round BA points for display only; never rescale the CSV value."""
    rounded = Decimal(str(value)).quantize(Decimal(".01"), rounding=ROUND_HALF_UP)
    if rounded == 0:
        rounded = abs(rounded)
    text = format(abs(rounded), ".2f")
    return r"\ensuremath{-}"+text if rounded < 0 else text


def _ci(row, family=False):
    lo, hi = _interval(row, family)
    return "["+_number(lo)+", "+_number(hi)+"]"


def _escape(value):
    replacements = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
                    "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
                    "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    return "".join(replacements.get(char, char) for char in str(value))


def render_displays(verified):
    """Pure rendering from verified CSV fields; returns exactly four TeX texts."""
    comment = ("% Generated by export_x12m_display.py; exploratory X12m follow-up.\n"
               "% All numeric fields already use BA points; no statistical re-estimation.\n"
               "% Source validation SHA-256: "+verified["validation_sha256"]+"\n")
    macros = []
    def macro(name, value):
        macros.append("\\newcommand{\\"+name+"}{"+str(value)+"}")
    for name, value in (("Jobs", "800"), ("Datasets", "8"), ("FamilyN", "4"),
                        ("Budget", "4{,}000"), ("DF", "7"), ("FamilyConfidence", r"98.75\%")):
        macro("xTwelve"+name, value)
    family_lines = [r"\begin{tabular}{llrrr}", r"\toprule",
                    r"Config. & Est. & Mean & 95\% CI & Family CI \\", r"\midrule"]
    for cfg in CONFIGS:
        for estimand in ("S", "D"):
            row = verified["family"][cfg+(estimand,)]
            prefix = "xTwelve"+MACRO_CONFIGS[cfg]+estimand
            for suffix, field in (("Mean", "mean_pp"), ("CILo", "ci95_lo_pp"), ("CIHi", "ci95_hi_pp"),
                                  ("FamilyLo", "family_lo_pp"), ("FamilyHi", "family_hi_pp")):
                macro(prefix+suffix, _number(row[field]))
            macro(prefix+"CI", _ci(row))
            macro(prefix+"FamilyCI", _ci(row, family=True))
            family_lines.append("%s & $%s$ & %s & %s & %s \\\\" %
                                (CONFIG_LABELS[cfg], estimand, _number(row["mean_pp"]), _ci(row), _ci(row, True)))
    family_lines += [r"\bottomrule", r"\end{tabular}",
                     r"\par\smallskip{\footnotesize BA points. Family intervals: 98.75\%; four estimates.}"]

    dataset_lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
                     r"Dataset & GA $S$ & GA $D$ & NSGA-II $S$ & NSGA-II $D$ \\", r"\midrule"]
    for ds in verified["datasets"]:
        values = [verified["dataset_effects"][(ds,)+cfg+(estimand,)]["value_pp"]
                  for cfg in CONFIGS for estimand in ("S", "D")]
        dataset_lines.append(_escape(ds)+" & "+" & ".join(_number(value) for value in values)+r" \\")
    dataset_lines += [r"\bottomrule", r"\end{tabular}",
                      r"\par\smallskip{\footnotesize BA points; 50 paired runs averaged within each dataset.}"]

    component_lines = [r"\begin{tabular}{llrrr}", r"\toprule",
                       r"Config. & RS ref. & Inner adv. & Outer adv. & Discrepancy \\", r"\midrule"]
    for cfg in CONFIGS:
        for reference in REFERENCES:
            cells = []
            for field in ("F", "T", "B"):
                row = verified["paired"][cfg+("algorithm", reference, field)]
                prefix = "xTwelve"+MACRO_CONFIGS[cfg]+("Ordinary" if reference == "ordinary_rs" else "SameSize")+field
                for suffix, source in (("Mean", "mean_pp"), ("CILo", "ci95_lo_pp"), ("CIHi", "ci95_hi_pp")):
                    macro(prefix+suffix, _number(row[source]))
                macro(prefix+"CI", _ci(row))
                cells.append(r"\shortstack[r]{"+_number(row["mean_pp"])+r"\\{}"+_ci(row)+"}")
            label = "Ordinary" if reference == "ordinary_rs" else "Same-size"
            component_lines.append(CONFIG_LABELS[cfg]+" & "+label+" & "+" & ".join(cells)+r" \\")
    component_lines += [r"\bottomrule", r"\end{tabular}",
                        r"\par\smallskip{\footnotesize Algorithm minus RS, in BA points; mean [ordinary 95\% CI].",
                        r"Inner: $F_a-F_r$; outer: $T_a-T_r$; discrepancy: $B_a-B_r$. Descriptive estimates.}"]
    names = [re.search(r"\\newcommand\{\\([A-Za-z]+)\}", line).group(1) for line in macros]
    if len(names) != len(set(names)):
        raise RuntimeError("Duplicate LaTeX macro name")
    return {"numbers_x12m.tex": comment+"\n".join(macros)+"\n",
            "tab_x12m_family.tex": comment+"\n".join(family_lines)+"\n",
            "tab_x12m_datasets.tex": comment+"\n".join(dataset_lines)+"\n",
            "tab_x12m_components.tex": comment+"\n".join(component_lines)+"\n"}


def export_display(source_dir=None, output_dir=None):
    """Verify, render and exclusively create four new TeX files; never overwrite."""
    source_dir, output_dir = Path(SOURCE if source_dir is None else source_dir), Path(OUTPUT if output_dir is None else output_dir)
    verified = load_verified_summaries(source_dir)
    rendered = render_displays(verified)
    conflicts = [str(output_dir / name) for name in OUTPUT_NAMES if (output_dir / name).exists()]
    if conflicts:
        raise FileExistsError("Refusing to overwrite existing X12m display: "+", ".join(conflicts))
    output_dir.mkdir(parents=True, exist_ok=True)
    hashes = {}
    for name in OUTPUT_NAMES:
        # Exclusive creation also refuses a destination created after preflight.
        with (output_dir / name).open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(rendered[name])
        hashes[name] = _sha((output_dir / name).read_bytes())
    return dict(status="new_x12m_displays_exported", source_validation_sha256=verified["validation_sha256"],
                jobs=800, family_n=4, numeric_units="BA points already present in CSV", reestimated=False,
                output_directory=str(output_dir.resolve()), outputs=hashes)


def _write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _synthetic_source(directory):
    """Create hand-written display fixtures, not statistical test results."""
    directory.mkdir()
    datasets = ["synthetic_%d" % i for i in range(8)]
    datasets[1] += "&percent%"
    family, effects, paired = [], [], []
    for c, (algo, learner) in enumerate(CONFIGS):
        for estimand in ("S", "D"):
            mean = Decimal("1.23456789")+c if estimand == "S" else Decimal("-.03456789")-c
            family.append(dict(algorithm=algo, learner=learner, estimand=estimand,
                               contrast=estimand+"_"+algo+"_"+learner, budget=4000, n_datasets=8, df=7,
                               family_n=4, family_confidence=".9875", family_quantile=".99375",
                               status="exploratory_four_estimate_family", mean_pp=str(mean),
                               ci95_lo_pp=str(mean-Decimal(".5")), ci95_hi_pp=str(mean+Decimal(".5")),
                               family_lo_pp=str(mean-Decimal(".75")), family_hi_pp=str(mean+Decimal(".75"))))
            for d, ds in enumerate(datasets):
                effects.append(dict(dataset=ds, algorithm=algo, learner=learner, estimand=estimand,
                                    budget=4000, runs=50, value_pp=str(mean+Decimal(d)/10)))
        for left, right in (("algorithm", "same_size_rs"), ("algorithm", "ordinary_rs"), ("ordinary_rs", "same_size_rs")):
            for f, field in enumerate(("F", "T", "B")):
                mean = Decimal("2.3456789")+c+Decimal(f)/10
                paired.append(dict(algorithm=algo, learner=learner, left=left, reference=right, field=field,
                                   budget=4000, n_datasets=8, df=7, status="descriptive", mean_pp=str(mean),
                                   ci95_lo_pp=str(mean-Decimal(".3")), ci95_hi_pp=str(mean+Decimal(".3"))))
    for name in ANALYSIS_OUTPUTS:
        (directory / name).write_text("Synthetic display fixture only.\n", encoding="utf-8")
    _write_csv(directory / "family_summary.csv", family)
    _write_csv(directory / "dataset_effects.csv", effects)
    _write_csv(directory / "paired_advantages.csv", paired)
    receipt = dict(suite="X12m", jobs=800, checkpoints=800, family_n=4, budget=4000,
                   n_inference_units=8, df=7, family_confidence=.9875, family_quantile=.99375,
                   no_partial_results=True, configs=[list(c) for c in CONFIGS], datasets=datasets,
                   status="exploratory_known_eight_datasets", inference_unit="dataset", dataset_weighting="equal",
                   source_fingerprint="a"*64, freeze_sha256="b"*64,
                   outputs={name:_sha((directory / name).read_bytes()) for name in ANALYSIS_OUTPUTS})
    (directory / "validation.json").write_text(json.dumps(receipt, sort_keys=True, indent=2)+"\n", encoding="utf-8")
    return receipt


def selftest(passdir):
    """Run synthetic display/export/rejection checks, retaining all files in passdir."""
    passdir = Path(passdir).resolve()
    passdir.mkdir(parents=True, exist_ok=True)
    case = Path(tempfile.mkdtemp(prefix="x12m_display_synthetic_", dir=str(passdir)))
    source, target = case / "summary_input", case / "generated"
    receipt = _synthetic_source(source)
    export = export_display(source, target)
    family = (target / "tab_x12m_family.tex").read_text(encoding="utf-8")
    datasets = (target / "tab_x12m_datasets.tex").read_text(encoding="utf-8")
    components = (target / "tab_x12m_components.tex").read_text(encoding="utf-8")
    numbers = (target / "numbers_x12m.tex").read_text(encoding="utf-8")
    checks = {}
    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        checks[name] = True
    check("four_new_files", set(p.name for p in target.iterdir()) == set(OUTPUT_NAMES))
    check("BA_points_not_multiplied", "1.23" in family and "123.46" not in family)
    check("negative_macro_is_math_safe", r"\xTwelveGaRidgeDMean}{\ensuremath{-}0.03}" in numbers)
    check("four_family_rows", sum(" & $S$ & " in line or " & $D$ & " in line for line in family.splitlines()) == 4)
    check("eight_dataset_rows", sum(line.startswith("synthetic") for line in datasets.splitlines()) == 8)
    check("dataset_LaTeX_escaping", r"synthetic\_1\&percent\%" in datasets)
    check("four_component_rows", sum(" & Ordinary & " in line or " & Same-size & " in line for line in components.splitlines()) == 4)
    check("booktabs_all_tables", all(r"\toprule" in text and r"\bottomrule" in text for text in (family, datasets, components)))
    try:
        export_display(source, target)
    except FileExistsError:
        checks["existing_outputs_refused"] = True
    else:
        raise AssertionError("Existing output was overwritten")
    tampered = source / "execution.csv"
    original = tampered.read_bytes()
    tampered.write_text("tampered\n", encoding="utf-8")
    rejected = case / "must_not_exist"
    try:
        export_display(source, rejected)
    except RuntimeError:
        check("any_manifest_hash_failure_blocks_export", not rejected.exists())
    else:
        raise AssertionError("Tampered unrelated analysis output was accepted")
    tampered.write_bytes(original)
    receipt["jobs"] = 799
    (source / "validation.json").write_text(json.dumps(receipt), encoding="utf-8")
    try:
        export_display(source, rejected)
    except RuntimeError:
        check("partial_suite_blocks_export", not rejected.exists())
    else:
        raise AssertionError("Partial suite was accepted")
    receipt["jobs"] = 800
    receipt["family_n"] = 3
    (source / "validation.json").write_text(json.dumps(receipt), encoding="utf-8")
    try:
        export_display(source, rejected)
    except RuntimeError:
        check("wrong_family_size_blocks_export", not rejected.exists())
    else:
        raise AssertionError("Wrong family size was accepted")
    receipt["family_n"] = 4
    (source / "validation.json").write_text(json.dumps(receipt, sort_keys=True, indent=2)+"\n", encoding="utf-8")
    report = dict(status="synthetic_display_selftest_passed", checks=checks, fit_calls=0,
                  real_results_read=False, fixture_directory=str(case), export=export)
    (case / "selftest_report.json").write_text(json.dumps(report, sort_keys=True, indent=2)+"\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=SOURCE)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT)
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--passdir", type=Path, help="Retained synthetic selftest artifacts; required with --selftest")
    args = parser.parse_args()
    if args.selftest:
        if args.passdir is None:
            parser.error("--selftest requires --passdir")
        result = selftest(args.passdir)
    else:
        if args.passdir is not None:
            parser.error("--passdir is only used with --selftest")
        result = export_display(args.source_dir, args.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
