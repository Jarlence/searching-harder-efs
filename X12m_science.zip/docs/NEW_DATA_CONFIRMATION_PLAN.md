# X11c: prospectively specified replication on eight new benchmark sources

Protocol decision date: 14 October 2026 (Asia/Shanghai). Machine access,
freeze, archive and execution records use UTC. Status at preparation:
**qualified data and specified design; not yet frozen or publicly registered**.
This document does not by itself authorize a performance run. Execution requires
the immutable machine freeze and a verified public archive receipt described below.

## Purpose and scope

This study tests three effects identified in the original EFS study and its
X10s strict-inner-scaling follow-up on eight source collections not used in the
project's recorded earlier experiments, analyses or parameter selection. It is a
same-team, prospectively specified replication on new benchmark samples. Its
purpose is to examine external validity across additional numerical benchmark
representations; it is not independent-team reproduction, proof that nested CV
is unbiased, a new optimization algorithm or a test of all EFS implementations.

The new observations will be analysed separately from the original thirteen
datasets and from X10s. No pooled old/new analysis will replace the three new-data
primary tests. Strict preprocessing on previously analysed data and replication
on different data address different questions; neither guarantees the other.

The scope is the frozen search implementations, two frozen learners, ordinary
request-matched random search and the specified finite matrices. The sources are
not a probability sample of the complete EFS domain. Text and digit tasks use
published fixed numerical representations rather than a newly learned raw-text
or image pipeline. Row-stratified evaluation targets new rows from these fixed
benchmark mixtures, not necessarily new users, writers, devices, simulators,
chemical scaffolds or future time periods.

## Fixed source collection and eligibility

The collection contains exactly the following eight tasks, listed in the order
used by the registry and job manifest. Counts below are the completed
outcome-free acquisition and structural audit, not model-performance results.
Here n is the final cohort size, p includes all published predictor columns
retained by the adapter, and minority is the smaller final class count.

|Frozen task|Official UCI source|Public labelled n before cohort construction|Final n|p|Minority|Representation|
|---|---|---:|---:|---:|---:|---|
|nc_climate|252: Climate Model Simulation Crashes|540|540|18|46|18 simulation parameters; study and simulation IDs excluded|
|nc_credit|144: Statlog German Credit|1,000|1,000|24|300|Official german.data-numeric version|
|nc_dbworld|219: DBWorld e-mails|64|62|4,702|28|Official unstemmed email-body binary bag-of-words matrix|
|nc_dexter|168: Dexter|600|600|20,000|300|Official labelled train followed by labelled validation; sparse input losslessly densified|
|nc_gisette|170: Gisette|7,000|1,200|5,000|600|Official labelled train followed by labelled validation; fixed cohort sample|
|nc_ionosphere|52: Ionosphere|351|350|34|125|Official numerical radar-return predictors, including the constant column|
|nc_qsar|254: QSAR biodegradation|1,055|1,052|41|354|Official fixed molecular descriptors|
|nc_spambase|94: Spambase|4,601|1,200|57|479|Official numerical email predictors; fixed cohort sample|

All eight official repository pages specify CC BY 4.0. Raw download URLs,
download times, raw archive hashes, processed hashes, column descriptions and
selected source-row indices are recorded in
`data/new_confirmation/registry.json`, the individual cards and the access
records. The official attribution pages and downloads are:

|Task|Official page|Official archive|
|---|---|---|
|nc_climate|https://archive.ics.uci.edu/dataset/252/climate+model+simulation+crashes|https://archive.ics.uci.edu/static/public/252/climate+model+simulation+crashes.zip|
|nc_credit|https://archive.ics.uci.edu/dataset/144/statlog+german+credit+data|https://archive.ics.uci.edu/static/public/144/statlog+german+credit+data.zip|
|nc_dbworld|https://archive.ics.uci.edu/dataset/219/dbworld+e+mails|https://archive.ics.uci.edu/static/public/219/dbworld+e+mails.zip|
|nc_dexter|https://archive.ics.uci.edu/dataset/168/dexter|https://archive.ics.uci.edu/static/public/168/dexter.zip|
|nc_gisette|https://archive.ics.uci.edu/dataset/170/gisette|https://archive.ics.uci.edu/static/public/170/gisette.zip|
|nc_ionosphere|https://archive.ics.uci.edu/dataset/52/ionosphere|https://archive.ics.uci.edu/static/public/52/ionosphere.zip|
|nc_qsar|https://archive.ics.uci.edu/dataset/254/qsar+biodegradation|https://archive.ics.uci.edu/static/public/254/qsar+biodegradation.zip|
|nc_spambase|https://archive.ics.uci.edu/dataset/94/spambase|https://archive.ics.uci.edu/static/public/94/spambase.zip|

Eligibility was decided before any new-study learner evaluation: non-biomedical
binary classification, fixed finite numerical predictors, at least 50 final
rows, at least 16 predictor columns and at least 25 final rows in each class.
The dimension bound avoids trivially exhausted nonempty-mask spaces at the
250-request starting checkpoint. There is no imputation, learned vocabulary,
additional supervised filter, category re-encoding or task binarisation.
Unlabelled challenge test sets are excluded. Source IDs are not predictors.

This is a purposively selected collection meeting representation and resource
criteria, not a claim that every non-biomedical task is eligible. Sonar was not
included because repeated returns from the same physical entities are not a
drop-in row-independent task; SECOM was not included because missing values and
temporal provenance require a different preprocessing/evaluation design. No
reserve source exists in this protocol. No task may be added or replaced after
performance generation begins, including for slow computation, weak effect or
unfavourable uncertainty. A source failure is reported rather than substituted.

The project source review found no overlap with the recorded earlier thirteen
main datasets or Parkinson auxiliary data. Dexter and Gisette share the NIPS
2003 challenge format but originate from different Reuters documents and MNIST
images; they are not two variants of the same observations. This review cannot
establish any author's complete lifetime non-exposure to public benchmarks.

## Deterministic cohort construction

`extras/confirmation_data.py` is the authoritative parser and cohort constructor.
It operates before model evaluation. Scientific search/learner source remains
unchanged. The processing sequence is fixed as follows.

1. Parse only the official file and version listed in the registry. For Dexter
   and Gisette concatenate train rows followed by validation rows, with their
   matching public labels. Sparse Dexter indices are one-based and are expanded
   without learning or changing feature values. Reject malformed or nonfinite
   matrices and nonbinary labels.
2. Store the numerical matrix as contiguous float64. Canonicalize negative zero
   to zero. Keep all published numerical predictor columns, including constant
   columns; only the two prespecified climate ID columns are excluded. No
   whole-cohort constant-column filtering or feature screening is performed.
3. Identify exactly equal float64 predictor vectors X, in original source order.
   Retain the first source row of each X-equivalence class, irrespective of its
   label. The retention decision uses predictors and source order, not y. Record
   removed-row counts, conflicting-label group counts and first source indices,
   and save final retained source-row identities; the preserved raw files and
   deterministic adapter permit reconstruction of every full equivalence group.
   This defines a feature-unique cohort; it does not establish that every equal
   feature vector is a duplicate physical email or measurement.
4. If the feature-unique cohort exceeds 1,200 rows, sample exactly 1,200 rows by
   the fixed stratified rule below. Otherwise retain all feature-unique rows.
   Sampling precedes all model fitting and performance generation.
5. Preserve selected rows in ascending original source order. Save
   `source_indices` in the processed matrix and card, with the unchanged raw
   archive available for reconstruction. Encode the smaller final class as 1;
   if the classes tie, the second sorted original label is 1. Record this mapping.

The raw audit found three removed feature-vector repetitions in QSAR, one in
Ionosphere, two in DBWorld and 394 in Spambase. DBWorld has one conflicting-label
X-group comprising two source rows; Spambase has three such groups comprising
six rows. These groups are not dropped based on labels, relabelled, averaged or
resolved using a model. First-row retention follows the same rule for all tasks.
The resulting cohort and its limitations will be reported, rather than described
as deletion of identical labelled observations.

The subsampling salt is exactly `X11c-fixed-cohort-20261014-v1`. For task name d,
compute SHA-256 of the UTF-8 string `salt + '|' + d`, take the first 16 hexadecimal
digits as an integer and pass that integer to NumPy `default_rng`. For sorted
original labels with feature-unique counts n_j, allocate floor(1200*n_j/n) rows
to each class, then assign remaining rows to the largest fractional remainders;
ties retain sorted-label order. Shuffle each class's source-ordered candidate
indices with this generator, take the allocated number without replacement and
sort the selected indices before saving. The NumPy version is frozen. Exactly
Spambase and Gisette require the cap; the other tasks are not subsampled.

The 1,200-row cap defines the new study's finite benchmark target and bounds the
5-NN calculation. It is not an evaluation of the complete labelled Gisette or
Spambase collection. The cap, seed, class allocation and row identities will
not change after scores exist. Keeping all official constant columns differs
from the original dataset loader's whole-cohort constant filtering. It avoids
whole-cohort feature selection in this study and leaves the number of predictors
used by the frozen initialization and size penalty equal to the declared p.
The inner/outer scaler handles zero training-fold variance using its existing
unit-denominator rule. This representation decision is not algorithm retuning.

## Source-specific interpretation boundaries

DBWorld's publisher constructed a binary vocabulary from its full collection.
Strict fold-local standardization here does not undo that pre-existing feature
representation or establish end-to-end raw-email preprocessing isolation.
Dexter includes artificial probe features, and its official design report notes
that some normalization details of the initial representation were unspecified.
Gisette includes higher-order pixel features and artificial probes. Neither task
is presented as an unmodified natural feature distribution.

Climate comprises three Latin-hypercube ensembles from one simulation model.
The study IDs are excluded, but pooled row-stratified CV does not test transfer
to another simulator or an entirely new ensemble. Ionosphere lacks usable
event/time group IDs in its public matrix. Gisette lacks writer IDs. DBWorld and
Spambase lack complete thread/user IDs, and exact-vector uniqueness cannot
exclude near duplicates or latent grouping. The official Spambase description
warns about personalized ham indicators. QSAR fixed descriptors do not identify
independent chemical scaffolds. These limitations constrain interpretation;
they are not removed by having eight different dataset names.

Spambase's current landing page reports missing values, whereas its original
documentation reports none. Structural parsing found all published numerical
values finite. The study uses the hash-bound finite raw file, records this
documentation discrepancy and performs no missing-value replacement.

## Frozen searches, learners and evaluation

The scientific computation reuses `extras/ex_suites6.py:strict_core` and the
existing `src/efsbench` implementation frozen for X10s. A new wrapper supplies
the new matrices and fixed job specifications, without changing the scientific
core, old registries, old processed data, R22 freeze or old job files. Freeze
verification covers every imported scientific source and the new adapter,
runner, statistical script, tests and dependency versions.

Algorithms are GA, sparsity-anchored BPSO, binary DE, NSGA-II and ordinary random
search (RS). Learners are the existing class-balanced weighted ridge classifier
(lambda=1) and Euclidean 5-NN (k=5), with no new hyperparameter tuning.

|Component|Fixed existing implementation|
|---|---|
|GA|Population 50; uniform crossover probability 0.9; tournament size 3; existing Poisson bit-flip mutation and elitist survival|
|BPSO|Population 30; inertia 0.7; attraction coefficients 1.5/1.5; velocity bound 6; existing sparsity-anchor mechanism|
|BDE|Population 50; XOR-based binary DE/rand/1/bin; mutation probability 0.5 on difference bits; crossover 0.5|
|NSGA-II|Population 50; crossover 0.9; existing mutation, nondominated sorting and crowding; objectives inner error and feature count|
|Initial evolutionary masks|Bit probability min(0.5,20/p), with the existing nonempty-mask repair|
|Scalar objective|0.99*(1-inner BA)+0.01*k/p; same weighted-sum incumbent for GA, BPSO, BDE and RS|
|Cardinality repair|Existing random in-place cap at 100 selected columns, using the unchanged repair generator|
|NSGA-II report|Existing error-first incumbent, fewer columns breaking equal-error ties; this evaluates a selected solution, not front quality|
|Ordinary RS|Uniform integer k from 1 through min(40,p), then a uniform mask of size k; ordinary request accounting|

For each dataset use ten repetitions of stratified five-fold outer CV and five
stratified inner folds. Every dataset receives both learners and all five
searches in every repetition and fold. Checkpoints 250, 1,000 and 4,000 are
observations of one uninterrupted 4,000-request trajectory, not three
independently initialized searches. Wrapper cache hits remain charged as
requests; actual distinct masks and selected feature counts are recorded.

Feature means and standard deviations are fit only to each inner training
fold, and applied to that fold's validation rows. The selected incumbent's
outer prediction fits scaling on the outer training sample only. Search and
incumbent selection finish before any outer test values are calculated.
No outer test observations or scores select a mask, budget or hyperparameter.

Outer partitions use the existing `ST.outer_split(y,ds,rep,fold)`, with random
keys `('outer',ds,rep)`. All searches and learners share these outer partitions.
The inner key is `('inner',ds,learner,rep,fold,None,False,False)`; corresponding
searches and RS share inner partitions within each learner. The algorithm key
is `('algo',ds,algo,learner,rep,fold,None,0,False,False)`. Existing key-to-seed
hashing and repair randomness remain unchanged. Save all outer indices and
inner indices relative to the outer training sample, together with split hashes
and source indices, so the pairing can be verified.

The exact factorial design is 8 datasets * 5 searches * 2 learners * 10 repeats
* 5 folds = **4,000 search jobs**, **12,000 checkpoint records** and **16,000,000
charged wrapper requests**. Repeated folds do not increase the independent
inferential sample size beyond eight datasets. There is no learner exclusion,
repeat reduction, seed selection, larger budget or alternative random baseline
in the new primary experiment.

## Three primary estimands

For dataset d, algorithm a, learner l, outer run r and budget b, let F denote
the selected incumbent's inner-CV balanced accuracy and T its outer-test
balanced accuracy. B = F-T. Scores are first computed on the zero-to-one scale;
reported effects are multiplied by 100 to give BA percentage points.

Every difference is formed within the matching outer run before averaging.
Each dataset contributes exactly one value for each contrast, then the eight
dataset values receive equal weights.

1. **C1: budget-gap growth.** Within each dataset, average
   B(a,l,r,4000)-B(a,l,r,250) across all five algorithms, both learners and
   all 50 outer runs. This tests the mean budget effect of the ten tested
   search/learner cells, including RS. It does not isolate evolutionary
   operators or require every individual algorithm to have a positive effect.
2. **C2: GA-ridge relative-advantage discrepancy.** Within each dataset, average
   B(GA,ridge,r,4000)-B(RS,ridge,r,4000) across the 50 paired outer runs.
   Equivalently, subtract the paired outer GA-RS advantage from the paired
   inner GA-RS advantage, using full-precision values.
3. **C3: NSGA-II-5-NN relative-advantage discrepancy.** Within each dataset,
   average B(NSGA-II,5-NN,r,4000)-B(RS,5-NN,r,4000) across the same 50 paired
   runs. It uses the frozen selected-solution rule.

C2 and C3 are relative to the fixed ordinary request-matched RS. They do not
test same-size RS, RS100, equal-distinct-mask RS or causal operator contributions.
No contrast is obtained by subtracting rounded overall means or unrelated
interval endpoints. No maximal result among additional configurations replaces
these three prespecified contrasts.

## Inference, decisions and secondary reporting

The primary family contains exactly C1-C3. For each contrast report all eight
dataset values, the equal-dataset-weight mean, the sample standard deviation
and the Student-t mean interval with seven degrees of freedom. Report an
ordinary two-sided 95% interval and the Bonferroni family interval with
individual confidence 1-0.05/3 = **98.333333%**. The latter uses the t critical
value at 1-0.05/(2*3), not an uncorrected or one-sided threshold. Intervals
describe uncertainty under the dataset-level t model on this small selected
collection; they do not turn purposively chosen tasks into a random sample of
the field.

A prespecified positive effect is supported only if its family interval's
lower bound exceeds zero. Report each contrast separately. If all three meet
this rule, the three positive effects are supported on this new collection.
If only some do, report partial replication and the uncertain/negative results
with the same prominence. Direction agreement alone is not confirmation. A
zero-containing interval is inconclusive, not evidence of absence or equivalence.
Different significance statuses between the old and new studies are not proof
that their effects differ.

Do not add an observed-power calculation, equivalence margin, TOST, mixed model,
new classifier, rank bootstrap, new p-value family or outcome-dependent test.
The replication concerns the stated positive effects, without a retrospectively
selected minimum magnitude. Dataset count, interval family and endpoint choice
remain fixed regardless of precision or statistical support.

Secondary descriptive outputs include F, T and B at all three checkpoints,
paired intermediate budget increments, all eight evolutionary-algorithm/learner
RS discrepancies, selected feature counts, distinct masks and timing. C2 and C3
retain primary status; other algorithm contrasts do not gain it after inspection.
Plot individual dataset effects and describe heterogeneity. Relationships to
n, p, p/n and class imbalance are exploratory, even if a primary test fails.
With only eight tasks, these associations cannot establish independent causal
moderators. No favourable subgroup is substituted for the full collection.

Original and X10s estimates may be displayed alongside the new results with
their correct protocol and multiplicity labels, but they remain separate.
The previously analysed data will not be combined with new tasks to increase
the new study's sample size or declare confirmation. If effects weaken, vanish
or reverse, revise the manuscript's claims rather than expanding the collection.

## Chronology, freeze and public archive gate

The initial design discussions and draft documents preceded this formal
protocol. `docs/NEW_DATA_CONFIRMATION_PLAN_DRAFT.md` and
`docs/CONFIRMATORY_PROTOCOL_DRAFT.md` are superseded design drafts, not registered
protocols and not execution specifications. This document governs X11c once
it is bound to the immutable freeze and the published archive receipt.

Before preparation, the team knew the original results and X10s results; C2
and C3 were selected from those earlier findings. Candidate qualification used
official metadata, provenance, finite-value checks, dimensions, class counts,
source duplicates and resource constraints. Some official descriptions include
historical published model accuracies. Such descriptions were visible during
source review. No claim is made that all authors were unaware of every historical
performance number on these public sources. No new-study performance outcome
has been generated in the preparation stage, and no historical accuracy was
used to choose the final tasks or tune the new computation.

Raw download/access times and processed-cohort creation times are recorded
truthfully. The datasets were downloaded and structurally inspected before
public archival; the protocol will not be backdated or described as registered
before data access. A public timestamp establishes when specified content was
available, not proof that no undocumented private analysis could ever have
occurred.

Before the first new-data learner evaluation:

1. Complete only structural checks and implementation tests using synthetic
   fixtures or already analysed old data. Do not use new data for a performance
   pilot, runtime benchmark that fits a learner, parameter choice or debugging
   of score behaviour.
2. Create `docs/NEW_DATA_CONFIRMATION_FREEZE.json`, containing this protocol's
   hash, all scientific/new-wrapper/analysis/test source hashes, fixed package
   versions, the source and processed dataset/card/access/registry hashes and
   every one of the 4,000 job specifications. Bind the complete data provenance
   and final source-row identities. Verify that new outcome directories are
   empty. Never replace an existing freeze silently.
3. Build the immutable archive
   `submission/asc/confirmation/X11c_preregistration_<freezehash-first12>.zip`.
   It contains the freeze, protocol, source and tests, locked dependencies,
   all eight official raw archives, processed matrices, cards, access records,
   registry, README and a member manifest using paths relative to the project
   root. Prior R22 frozen sources may be included as dependencies; prior job
   outcomes are not included in this registration bundle.
4. Publish the exact bundle in a public OSF registered record or a published
   Zenodo record before running new-data performance jobs. A private draft,
   local ZIP, local commit or reserved unpublished DOI does not pass this gate.
5. Save `docs/NEW_DATA_CONFIRMATION_ARCHIVE_RECEIPT.json` with the verified
   public record URL, publication/creation timestamp and exact publicly
   retrievable bundle hash. Verify archive bytes against the frozen local
   bundle and confirm the public timestamp precedes the first performance run.

Only verified freeze plus verified public archive receipt makes the experiment
ready to execute. Until then its status remains **prepared, not registered**.
The runtime checks the gate and source/data/environment identities before a
performance job, including on resume. No informal instruction to start overrides
the study's requirement that prospectively claimed confirmation be timestamped
before new outcomes.

## Deviations, execution and stopping

Before any performance outcome, changes necessary for access, parsing or
implementation correctness must be documented, reviewed and included in a new
version of the plan and freeze. If a version has already been published, preserve
it and publish a dated amendment binding replacement hashes before starting.
Never erase the earlier chronology. Prospective dataset replacement is not part
of this fixed-eight protocol; a failure may require a new separately specified
design rather than an undocumented substitution.

Once outcomes exist, preserve the original freeze and failed/successful records.
Record technical defects and repairs in a dated deviation log. If a repair
changes scientific computation, retain the original archive, identify all
affected jobs, document the revised implementation and rerun the affected fixed
coverage; disclose the departure from the prospectively archived version.
Inspect errors to repair implementation, not effect signs to change methods.
Do not drop slow tasks, difficult labels or disappointing algorithms. Unresolved
incomplete coverage is reported as incomplete; it cannot silently become a
seven-dataset primary test.

Use the project's locked scientific environment, with one BLAS thread per
worker. Concurrency and scheduling may change only for machine resources,
without altering coverage, seeds, checkpoints or analysis rules. Save each job
atomically, record UTC start/end times and separate errors, and verify the
selected mask, request count, distinct count, split hashes and provenance on
resume. Actual computation time is descriptive and not an inclusion criterion.

Analysis begins only after the exact 4,000-job coverage and all 12,000 checkpoint
records pass integrity, pairing and freeze checks. Stop at completion of the
fixed job list. Report every primary contrast and dataset, regardless of sign,
interval width or support for the manuscript. Do not collect additional tasks
or repeats until significance appears.

The private blinded audit key and human verification sheet are outside the
study. They are never read, hashed or included in any source, data, archive or
manifest enumeration. The established original/R22 code, data and job records
are preserved without modification.
