# X12m: targeted strict-protocol same-size random-reference sensitivity

## Status and question

This is an exploratory follow-up on the eight completed X11c data sets. Their
algorithm and ordinary-RS outcomes, including C1--C3, were already inspected.
This document fixes the new reference execution and its analysis before any
X12m outcome. It is a local specification, not independent confirmation or a
claim of publicly verified preregistration. No OSF operation is part of it.

Question: how does conditioning random search on the final feature count
selected by the compared algorithm change the paired advantage discrepancy?
This supplements, and does not alter, the original three-contrast validation.

## Fixed execution

- Sources: the exact eight processed X11c matrices, with their frozen row
  cohorts, raw-source provenance and feature representations unchanged.
- Configurations: GA with ridge; NSGA-II with 5-NN. These were selected from
  earlier findings, not independently of observed performance.
- Coverage: eight data sets x two configurations x ten repeats x five outer
  folds = 800 new conditional-RS jobs. No additional algorithm run is needed.
- Budget: exactly 4,000 wrapper requests per job, including cache hits. Record
  the distinct-mask count but do not continue to a distinct-mask target.
- Each job receives only the final feature count k from its source algorithm's
  4,000-request inner-selected incumbent. Every random candidate has exactly
  that k, uniformly sampled without replacement within a subset; subsets can
  repeat across requests. The learned k is not chosen from outer performance.
- k must lie in 1..min(p,100); reject invalid input rather than clamp. k=p is a
  valid case with one distinct candidate despite 4,000 charged requests.
- Reuse the exact outer rows, learner-specific inner folds, ridge/5-NN
  settings, strict inner-training-fold scaling and CUDA float64 backend of the
  completed X11c GPU collection. Use no CPU learner fallback or CPU records.
- Select the smallest inner error, retaining the first encountered tie. At
  fixed k the preserved scalar objective and lexicographic error rule order
  candidates identically. Final outer fitting/scoring occurs after search.
- Sampling seed key: (X12m, conditional_fixed_final_k_v1, dataset, source
  algorithm, learner, repeat, fold, 4000, k), using the existing SHA-256 seed
  helper. This is a new random stream rather than a replay of ordinary RS.
- Fixed deterministic job order: data-set order inherited from X11c, then
  GA-ridge / NSGA-II-knn, then repeat and fold. One GPU execution process;
  elapsed time is a diagnostic, not a comparative performance endpoint.

This reference conditions on an algorithm-selected outcome. It does not match
the trajectory's full cardinality distribution or the number of distinct
candidates, and does not identify a pure evolutionary-operator contribution.
It is a different conditional comparator, not an intrinsically fairer baseline.

## Frozen inputs and protection

Freeze the parent GPU specification, inherited source/data hashes, new source
and analysis/test files, runtime/device, 800 job specifications and learned k
values. Freeze SHA-256 and pairing information for exactly 1,600 old records:
one source algorithm and one ordinary RS record per new job. Those records
remain read-only. Preserve the old three-estimate and nine-estimate families,
all old job files and both frozen research ZIPs.

## Estimands and direct paired comparison

Let F be inner fitness BA and T be outer BA, B=F-T. Let a be the source
algorithm, R ordinary RS, and K the new conditional same-size RS. Form these
within the same outer run before averaging:

    O = (F_a-F_R) - (T_a-T_R) = B_a-B_R
    S = (F_a-F_K) - (T_a-T_K) = B_a-B_K
    D = S-O = B_R-B_K

O is the already measured ordinary-reference discrepancy. S is the discrepancy
under the conditional reference. D directly measures the change of reference;
the algorithm term cancels. Check these identities separately from any
significance interpretation, and retain both F and T components.

For each data set and configuration average all 50 paired runs. Give the eight
data sets equal weight, with n=8 and df=7. Runs and folds are repeated
measurements, not 800 independent inferential units. Report every data-set
effect and the separate inner advantage, outer advantage and discrepancy.

The fixed four-estimate family consists of S and D for each of the two
configurations. Report ordinary two-sided 95% Student-t intervals and
Bonferroni intervals of individual confidence 1-.05/4=.9875, using critical
t quantile .99375 at df=7. The simultaneous-coverage statement relies on the
marginal t-interval assumptions. Descriptive component/outer-advantage
intervals remain ordinary 95% and do not join a new confirmatory claim.

A family interval wholly above/below zero supports that signed effect under
this follow-up criterion; an interval containing zero leaves its direction
unresolved. Do not compare two significance decisions to infer a difference.
Neither a zero-spanning D interval nor two positive S/O intervals proves
equivalence or reference invariance. A positive S does not establish an outer
predictive disadvantage, a rank reversal or a causal operator effect.

## Stopping, failure and reporting

Stop after the exact 800 valid jobs, regardless of signs or interval widths.
Do not add seeds, datasets, configurations or budgets in response to results.
Record every failed attempt and stop execution on a job error; no silent
fallback, exclusion or automatic retry. Resume only by validating completed
records against the identical frozen inputs. Any necessary code amendment
after freeze must be separately versioned and disclosed.

Full coverage and source/split/seed/backend integrity must pass before any
statistical summary is exported. Synthetic fixtures, before freeze, check
fixed-k sampling, requests vs distinct counts, deterministic tie/replay,
inner training-only scaler statistics, outer-test isolation, GPU operation
counters, pairing, algorithm cancellation, equal data-set weighting, interval
family constants, malformed/incomplete coverage, and zero-variance handling.

Report ordinary and conditional reference results side by side and interpret
the direct D estimate and interval. Integrate results as an exploratory
reference-sensitivity follow-up, separate from X11c C1--C3. Retain uncertain
and opposite-direction results in the manuscript and research materials.
