# R22: core-budget sensitivity to inner-fold standardisation

Decision date: 2026-10-13 (Asia/Shanghai). Machine records use UTC.

## Purpose and status

The author has authorised new experiments that can strengthen the ASOC submission.
This follow-up addresses the main protocol's shared inner-fold scaling. It is a
sensitivity extension selected after the main results and the three-data-set X1
results were inspected. Reusing the same datasets does not constitute an independent
confirmation study, and a local hash is not external preregistration.

## Fixed design

Run suite X10s on every existing E1h (dataset, algorithm, learner, repetition,
outer fold) configuration: 5,350 jobs, with checkpoints 250, 1,000 and 4,000
wrapper requests, giving 16,050 checkpoint records. Use the 13 original datasets,
five original search implementations and the original learner coverage (ridge:
13 datasets; 5-NN: 11). Preserve the original repeat reductions, outer splits,
inner folds, algorithm and repair seeds, objective functions, 100-feature cap,
ordinary RS size distribution and incumbent selection rules. There is no new
hyperparameter tuning or algorithm selection.

The only planned procedural change is to fit feature means and standard deviations
on each inner training fold separately. Final outer prediction continues to fit
scaling on the outer training sample. Outer-test data and labels cannot influence
the search. Full outer and inner fold indices are recorded for each new job.

The implementation may standardise selected columns lazily to reduce memory;
its scores must agree exactly with the existing X1 fold-scaled wrapper in the
implementation checks. Checkpoints are observational and draw no random numbers.
Existing X1 records with overlapping keys are used as a replay consistency check,
not counted as independent observations. No older job or result is overwritten.

## Fixed estimands and analysis

F is the selected incumbent's inner-CV balanced accuracy, T is its outer-test
balanced accuracy, and B = F - T. All differences are first formed within matching
runs. Runs are averaged inside an algorithm/learner cell; cells are averaged
within each dataset; datasets then receive equal weights.

The focal family has nine estimates under the inner-fold-scaling protocol:

1. Overall budget-gap increment B(4000) - B(250), averaged over available
   algorithm/learner cells within each of the 13 datasets.
2. Eight algorithm-by-learner advantage discrepancies at 4,000 requests:
   (F_algorithm - F_RS) - (T_algorithm - T_RS), for GA, BPSO, BDE and NSGA-II
   with ridge and 5-NN. Ridge uses 13 datasets and 5-NN uses 11.

Report every focal estimate, its dataset values, an unadjusted 95% Student-t
interval and a Bonferroni simultaneous interval for the nine-estimate family
(individual confidence 1 - 0.05/9). These intervals describe uncertainty across
this small, selected benchmark collection under the t model; the datasets are
not a probability sample of the entire EFS domain. No new p-value family,
equivalence margin, observed-power calculation or rank-stability test is added.
Plot the dataset values so heterogeneity and influential tasks remain visible.

Secondary descriptive outputs: F, T and B at all three budgets; their paired
increments for 250-to-1000, 1000-to-4000 and 250-to-4000; all eight paired
algorithm-RS outer and inner advantages; paired changes relative to the original
shared-scaling procedure, using identical keys; selected feature counts, actual
distinct masks and timing. Secondary intervals, if displayed, are unadjusted and
are labelled descriptive. There is no subgroup-driven selection of conclusions.

Do not interpret a nonsignificant or small change as equivalence. Re-fitting
preprocessing can change search trajectories and selected masks, so the comparison
is between complete procedures, not a fixed-mask causal decomposition. This study
does not evaluate strict scaling at 16,000 or longer budgets, different RS
definitions or non-biomedical confirmation datasets.

## Execution, provenance and stopping

Before the new suite starts, save an immutable local freeze containing this plan,
the suite/driver/analysis/test source hashes, locked package versions, processed
dataset hashes, the 5,350 original comparator-file hashes and all planned job
specifications. Source verification must succeed on resume. Actual UTC creation
times are retained. Any subsequent change requires a written deviation and a new
version; no silent replacement of the freeze is allowed.

Use the project's locked Python 3.8 scientific environment. Cap BLAS threads at
one per worker and select concurrency from available memory. Scheduling and
concurrency may change for resource reasons without changing jobs or statistical
rules. Save each successful job atomically; validate code, plan, comparator,
checkpoint and selected-mask fields on resume. Save errors separately. Errors
are repaired by inspecting the implementation, never by dropping difficult data.

Stop after the fixed job list completes. Analyse only after complete coverage
and integrity checks pass. Report results regardless of sign or whether they
support the previous manuscript. If core results materially change, revise the
claims rather than adding experiments until favourable results reappear.

## Excluded files

The blinded audit key and human verification sheet are never opened, hashed or
included in this work. This experiment uses only the established numeric datasets,
E1h comparators, X1 replay records and the explicitly enumerated source files.
