# X11c local execution amendment

## Authority and timing

The author instructed: "OSF不是必须预注册，不注册也不影响论文，停止注册，开始实验".
This amendment implements that decision before the first X11c performance job.
The local execution freeze records the actual UTC creation time. No retrospective
public-registration claim is made. Further OSF registration and upload operations
are stopped. The earlier uploaded package and submitted registration remain part
of the chronology; this amendment neither deletes nor rewrites that history.

## Execution condition

Verified local immutable source, data, environment and design provenance replaces
the verified public archive receipt as the condition for execution. This supersedes
the public-archive execution requirement in the parent plan. All scientific
conditions in `docs/NEW_DATA_CONFIRMATION_PLAN.md` remain in force. The parent
freeze and its archive are preserved byte-for-byte. Separate local entry points
and a child freeze record the changed execution condition explicitly. No public
archive receipt is fabricated or used to authorize this local route.

The execution mode is `locally_frozen_not_publicly_preregistered`. The study is
described as a prospectively specified, locally frozen same-team validation on
additional benchmark samples. Local hashes and machine timestamps permit content
and internal chronology checks; they are not third-party proof of when a private
decision occurred. A later public deposit records its actual publication time.

## Unchanged scientific design

The eight datasets and source-row identities, predictor representations, two
learners, five searches, all hyperparameters, seed keys, folds, objectives,
cardinality repair, selected-solution rule, ordinary request-matched RS and passive
250/1000/4000-request checkpoints remain unchanged. The fixed design has 4,000
jobs and 12,000 checkpoints. The local computation function is an exact copy of
the original function; its dependencies point to the unchanged strict core.
Results are written separately to `results/jobs_extra/X11c_local`.

The original thirty source and thirty-three data/provenance files remain bound
to the parent freeze. The child additionally binds this amendment, the local
entry points, tests, outcome-free test report and the candidate-record summary.
Every performance record binds both freezes, the child source fingerprint,
actual UTC start/end times and the explicit local execution mode.

## Estimands and decisions

Let F be selected inner BA, T outer BA and B=F-T. Form differences inside matching
outer runs before averaging; datasets receive equal weight.

* C1 is B(4000)-B(250), averaged within each dataset over all five searches,
  both learners and fifty outer runs. It includes RS.
* C2 is B(GA,ridge,4000)-B(RS,ridge,4000), paired over fifty outer runs.
* C3 is B(NSGA-II,5-NN,4000)-B(RS,5-NN,4000), paired over fifty outer runs.

The inferential unit remains eight datasets, with Student-t df=7. Report all
dataset effects, equal-weight means, ordinary two-sided 95% intervals and the
fixed three-item Bonferroni intervals, each with confidence 98.333333%. A positive
effect is supported only when its family interval lower endpoint exceeds zero.
An interval spanning zero remains inconclusive; direction agreement does not
replace the criterion. A family upper endpoint below zero supports an opposite
effect. Report the three decisions separately and retain partial or absent support.

The unchanged analysis functions report internal advantages, outer performance
differences and their discrepancy as separate F, T and B components. A positive
B discrepancy does not determine the sign of the outer difference and does not
establish a rank reversal. No new rank test or inferred rank-reversal claim is
introduced. Secondary outputs retain descriptive status.

## Selection and prior exposure

`docs/NEW_DATA_CONFIRMATION_CANDIDATE_RECORD.csv` summarizes the eight included
and two excluded sources documented in the parent plan. It was assembled from
that preserved plan before performance execution. It is not a reconstructed
complete search of UCI/OpenML and does not assert that every possible candidate
was considered. Selection uses the prespecified task, representation and resource
criteria. No dataset is replaced, added or dropped on the basis of performance.

The team knew the old benchmark and X10s results, which motivated C2 and C3.
Official dataset pages viewed during qualification could contain historical
published accuracies. These sources were not used in this project's recorded
earlier performance experiments, analyses or tuning. No assertion of complete
lifetime non-exposure by every author is made. The parent protocol's specific
representation, grouping, duplicate and fixed-cohort boundaries remain applicable.

## Analysis and stopping

The complete 4,000-job, 12,000-checkpoint coverage must pass provenance, split,
pairing and numerical validation before any effect summary is emitted. Original
and X10s outcomes are not pooled with the new collection. No partial-effect
analysis, significance-driven expansion, task replacement, additional classifier,
new statistical family or parameter retuning is authorized. Runtime and count
monitoring support execution only. Failed records are preserved and technical
repairs require an explicit dated record.

Stop at completion of the fixed design, report all three contrasts and their
components, and revise manuscript claims to match the actual evidence. Completing
a rigorous validation does not itself establish novelty or acceptance at ASOC.
Final public deposit and submission preparation follow the author's later
instructions; they are not prerequisites of this amended local execution route.
