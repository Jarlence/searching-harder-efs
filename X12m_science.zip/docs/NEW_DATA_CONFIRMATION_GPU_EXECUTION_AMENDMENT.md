# X11c CUDA execution amendment

## Reason and chronology

The author requested: "evolve的环境配的是gpu，别用cpu". The evolve environment
has PyTorch 2.0.1+cu118 and an available RTX 4060 Laptop CUDA device. The earlier
NumPy learner implementation did not dispatch computation to that device.
Its runner and identified workers were stopped. All 684 completed CPU records
are preserved in their original directory. No primary effect analysis was
performed on this incomplete CPU collection.

The original design and C1-C3 analysis were locally frozen before the first
CPU job. This technical backend amendment and its new source are frozen before
the first GPU benchmark job, after those CPU records already existed. The new
version is not described as a first freeze preceding all new-data outcomes.
The change follows a hardware instruction, not observed effect sizes. The
earlier local-execution amendment remains in force: no new registration or
upload is performed and no verified public preregistration is claimed.

## GPU numerical contract

The learning computations use CUDA float64. Ridge retains the original
class-balanced weights, weighted centering, lambda=1, primal/dual switch and
zero score threshold. The same squared-Euclidean expression and nonnegative
clamp are used for 5-NN distances. TF32 is disabled and deterministic CUDA
algorithms are required, with CUBLAS_WORKSPACE_CONFIG=:4096:8.

NumPy search, random generators, repairs, fold construction and checkpoint
accounting remain unchanged. Training-only scaler mean/std statistics retain
their original NumPy rules; inner feature transformations run on CUDA. The
outer scaler retains its original outer-training-only implementation. NumPy
argpartition selects the nearest neighbours from the GPU distance matrix to
retain the original ordering convention, including its unspecified tie order.
Metrics, control flow and file operations remain on CPU. This is CUDA learner
acceleration, not a claim that no CPU instruction is executed.

CUDA reductions and solvers need not match NumPy bit-for-bit. Small differences
near class thresholds or neighbour-distance ties can change predictions and
adaptive search paths. Synthetic checks assess both ridge branches, class
weights, strict scaling, repeated-coordinate ties, predictions, full short
searches and repeated GPU replay. These checks do not prove every real-data
path is identical. No CPU learner fallback is allowed when CUDA is unavailable.
No float32 substitution or hyperparameter change is introduced.

## Frozen inputs and complete GPU coverage

The previous thirty original source files, seven local-execution files and
thirty-three data/provenance files remain unchanged. The new child freeze binds
the GPU backend, entry points, tests, test report, this amendment, stable CUDA
runtime metadata and the preceding local freeze. Every GPU record identifies
its backend, float64 mode and actual CUDA learner/scaling operation counts.

The complete 4,000-job design is rerun through the GPU version into
`results/jobs_extra/X11c_gpu`. The 684 CPU records do not fill any GPU coverage.
Eight sources, source-row identities, five searches, two learners, seeds,
250/1000/4000 checkpoints and all search parameters remain fixed. One GPU
execution process avoids competing CUDA contexts; this resource choice does
not change the experimental design. No speedup is asserted in advance.

C1-C3, within-run pairing, equal dataset weights, df=7, ordinary 95% intervals,
three-estimate Bonferroni intervals and positive-lower-bound decisions are
unchanged. All 4,000 GPU records and 12,000 checkpoints must validate before
the unchanged aggregation functions emit effects. Old, X10s and interrupted
CPU results are excluded from the GPU primary analysis. Stop at complete
fixed coverage regardless of effect direction or interval width.
