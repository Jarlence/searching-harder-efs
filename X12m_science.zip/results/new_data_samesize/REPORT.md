# X12m same-size RS exploratory follow-up

This is an exploratory follow-up on eight known datasets whose existing GPU algorithm and ordinary RS outcomes were already available. It is not independent confirmation or publicly verified preregistration.

F=1-inner_err, T=test_ba, B=F-T. Each configuration uses 4000 requests. Same-size RS uses the source algorithm's selected feature count on the same inner/outer split.
S=(F_algorithm-F_same_RS)-(T_algorithm-T_same_RS)=B_algorithm-B_same_RS.
O=(F_algorithm-F_ordinary_RS)-(T_algorithm-T_ordinary_RS)=B_algorithm-B_ordinary_RS is the descriptive ordinary-reference baseline.
D=S-O=B_ordinary_RS-B_same_RS. The algorithm cancels exactly; D is not a second algorithm effect.

The four-estimate family is S and D for GA-ridge and NSGA-II-5-NN at budget 4000. Each dataset first averages its 50 paired repeat/fold runs; all eight dataset means then receive equal weight. Inference uses n=8 and df=7, never n=800.
Ordinary intervals use t(.975,7). Bonferroni family intervals have individual confidence 98.75%, using t(.99375,7), for a four-estimate 95% family. Repeated folds are not independent inferential units.

| Contrast | Mean (BA pp) | Ordinary 95% CI | Four-estimate family CI |
|---|---:|---|---|
| S_ga_ridge | 2.6154 | [0.0635, 5.1673] | [-0.9840, 6.2148] |
| D_ga_ridge | -0.7784 | [-1.5215, -0.0353] | [-1.8266, 0.2697] |
| S_nsga2_knn | 2.9944 | [0.0929, 5.8960] | [-1.0982, 7.0870] |
| D_nsga2_knn | 0.5636 | [-0.9020, 2.0292] | [-1.5036, 2.6308] |

The ordinary-reference baseline and its F/T/B advantages, all three roles' F/T/B levels, and paired component advantages are descriptive and carry ordinary 95% intervals only. They are outside the four-estimate family.
No p-values, equivalence tests or comparisons of significance statuses are made. An interval containing zero does not establish absence or equivalence. Compare S and O through the paired D estimate, not through whether their separate intervals cross zero.
Dataset-level t intervals assume the eight dataset means supply an adequate independent unit approximation. This small, selected, known collection limits generalization; the report does not claim representative sampling of feature-selection tasks.
F-T includes training-size and sampling differences. Positive B or S does not determine the sign of the outer-performance advantage or establish a causal search effect or a rank reversal.

Coverage: 800 complete new same-size jobs; eight datasets; two configurations; ten repeats x five folds; budget 4000. Frozen existing comparator rows are reused verbatim; no existing algorithm or ordinary RS outcomes are refitted or pooled as extra datasets.
Every new record passed frozen source/comparator/GPU/split provenance checks, complete inner and outer OOF checks, and the D cancellation identity. No partial analysis was published.
