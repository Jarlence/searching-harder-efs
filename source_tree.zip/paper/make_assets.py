"""Generate every number, table and figure used by paper/main.tex directly from the result tables (no hand transcription).
    python paper/make_assets.py          -> paper/generated/numbers.tex, paper/generated/tab_*.tex, paper/figures/*.pdf
Run with the `evolve` env (pandas / numpy)."""
import glob
import json
import os
import shutil
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
T = os.path.join(ROOT, "results", "tables")
GEN = os.path.join(HERE, "generated")
FIGD = os.path.join(HERE, "figures")
os.makedirs(GEN, exist_ok=True); os.makedirs(FIGD, exist_ok=True)
sys.path.insert(0, os.path.join(ROOT, "analysis")); sys.path.insert(0, os.path.join(ROOT, "experiments")); sys.path.insert(0, os.path.join(ROOT, "src"))


def rd(name):
    return pd.read_csv(os.path.join(T, name))


M = {}                                                   # macro name -> LaTeX text
NEG = r"\ensuremath{-}"


def num(x, nd=1, pts=True, sign=False):
    """x in BA units -> 'points' string (x100) with a typographic minus."""
    v = 100.0 * x if pts else x
    s = ("%." + str(nd) + "f") % abs(v)
    if v < 0 and float(s) != 0.0:
        return NEG + s
    return ("+" if sign else "") + s


def pv(p):
    if p is None or (isinstance(p, float) and np.isnan(p)):
        return "--"
    return r"$<\!0.001$" if p < 0.001 else "%.3f" % p


def put(name, value):
    assert name.isalpha(), name
    M[name] = str(value)


def cap(s):
    return s[0].upper() + s[1:]


ALGO = {"ga": "Ga", "bpso": "Bpso", "bde": "Bde", "nsga2": "Nsgatwo", "rs": "Rs"}
ALGO_NAME = {"ga": "GA", "bpso": "BPSO", "bde": "BDE", "nsga2": "NSGA-II", "rs": "RS", "anova": "ANOVA", "rf": "RF", "all": "All features", "l1": r"L$_1$-LR"}
LRN = {"ridge": "Ridge", "knn": "Knn"}
BASEK = {"anova": "Anova", "rf": "Rf", "all": "All", "l1": "Lone"}
FLAWK = {"B": "B", "A": "A", "Afit": "Afit", "D": "D", "Dties": "Dties", "Dold": "Dold", "E3": "Ethree", "E5": "Efive", "E10": "Eten", "E20": "Etwenty", "G": "G", "G2": "Gtwo"}

# ------------------------------------------------------------------------------------------------ scale
import load as LD  # noqa: E402
tabs = LD.load_all(use_cache=True)
secs = tabs["secs"]
n_main = int((secs.suite.isin(["E1h", "E1f", "Ep_h", "Ep_f", "E2b", "E3m", "E4s", "E5so", "E5si", "E6u", "E6uf", "E7l"])).sum())
n_extra = 0; n_rev = 0
for d in glob.glob(os.path.join(ROOT, "results", "jobs_extra", "*")):
    cnt_ = len(glob.glob(os.path.join(d, "*.json")))
    if os.path.basename(d) in ("X8p", "X6d", "X5m", "X7d", "X9s", "X6r"):          # studies added after the external review of the first draft (docs/DEVIATIONS.md #7-#9)
        n_rev += cnt_
    else:
        n_extra += cnt_
cpu_main = float(secs.seconds.sum())
extra_cpu = 0.0
for f in glob.glob(os.path.join(ROOT, "results", "jobs_extra", "*", "*.json")):
    extra_cpu += json.load(open(f))["seconds"]
put("NJobsMain", "{:,}".format(n_main).replace(",", "{,}")); put("NJobsExtra", "{:,}".format(n_extra).replace(",", "{,}"))
put("NDatasets", 13)
put("NJobsRev", "{:,}".format(n_rev).replace(",", "{,}"))
put("NJobsTotal", "{:,}".format(n_main + n_extra + n_rev).replace(",", "{,}"))
put("CpuHours", "%d" % round((cpu_main + extra_cpu) / 3600.0))
cards = {c["name"]: c for c in json.load(open(os.path.join(ROOT, "data", "data_cards.json"), encoding="utf-8"))}

# ------------------------------------------------------------------------------------------------ H1 / H2 / H3 / H4
h1 = rd("H1_inflation.csv")
for fl, key in FLAWK.items():
    r = h1[(h1.breakdown == "all") & (h1.flaw == fl)]
    if len(r):
        r = r.iloc[0]
        put("gap" + key, num(r["mean"])); put("gap" + key + "lo", num(r.lo)); put("gap" + key + "hi", num(r.hi))
        put("gap" + key + "n", int(r.n_pos)); put("gap" + key + "nds", int(r.n_ds))
        put("gap" + key + "p", pv(r.p_holm if not np.isnan(r.p_holm) else r.p_wilcoxon))
for fl in ("B", "A", "D"):
    for cp, c in ((250, "a"), (1000, "b"), (4000, "c"), (16000, "d")):
        r = h1[(h1.breakdown == "cp=%d" % cp) & (h1.flaw == fl)].iloc[0]
        put("gap%scp%s" % (fl, c), num(r["mean"])); put("gap%scp%slo" % (fl, c), num(r.lo)); put("gap%scp%shi" % (fl, c), num(r.hi))
for lr in ("ridge", "knn"):
    for fl in ("B", "A", "D"):
        r = h1[(h1.breakdown == "learner=" + lr) & (h1.flaw == fl)].iloc[0]
        put("gap%s%s" % (fl, LRN[lr]), num(r["mean"]))
for a in ("ga", "bpso", "bde", "nsga2", "rs"):
    r = h1[(h1.breakdown == "algo=" + a) & (h1.flaw == "B")].iloc[0]
    put("gapB%s" % ALGO[a], num(r["mean"]))
h2 = rd("H2_summary.csv").set_index("flaw")
for fl in ("B", "A", "Afit", "D"):
    r = h2.loc[fl]
    k = {"B": "B", "A": "A", "Afit": "Afit", "D": "D"}[fl]
    put("hTwo%sPos" % k, int(r.n_rho_pos)); put("hTwo%sCells" % k, int(r.n_cells)); put("hTwo%sShare" % k, "%.0f" % (100 * r.share_pos))
    put("hTwo%sLo" % k, "%.0f" % (100 * r.cp_lo)); put("hTwo%sHi" % k, "%.0f" % (100 * r.cp_hi)); put("hTwo%sEqOne" % k, int(r.n_rho_eq1)); put("hTwo%sNeg" % k, int(r.n_rho_neg))
    put("hTwo%sDsShare" % k, "%.0f" % (100 * r.share_ds_mean)); put("hTwo%sDsLo" % k, "%.0f" % (100 * r.share_ds_lo)); put("hTwo%sDsHi" % k, "%.0f" % (100 * r.share_ds_hi))
    put("hTwo%sDsGe" % k, int(r.n_ds_ge75)); put("hTwo%sDsN" % k, int(r.n_ds))
h3 = rd("H3_pn.csv")
for fl in ("B", "A"):
    for x, key in (("log_p_over_n", "pn"), ("log_n", "n")):
        r = h3[(h3.flaw == fl) & (h3.learner == "all") & (h3.x == x)].iloc[0]
        put("hThree%s%sTau" % (fl, key.upper() if key == "n" else "Pn"), "%.2f" % r.kendall_tau)
        put("hThree%s%sP" % (fl, key.upper() if key == "n" else "Pn"), pv(r.p_tau))
h4 = rd("H4_permutation.csv").set_index("report")
put("permHonest", num(h4.loc["honest_test_BA", "mean_minus_half"], 2)); put("permHonestlo", num(h4.loc["honest_test_BA", "lo"], 2)); put("permHonesthi", num(h4.loc["honest_test_BA", "hi"], 2))
put("permFit", num(h4.loc["fitness_as_report(B)", "mean_minus_half"])); put("permFitPct", "%.1f" % (100 * (0.5 + h4.loc["fitness_as_report(B)", "mean_minus_half"])))
put("permA", num(h4.loc["select_on_all+reCV(A)", "mean_minus_half"])); put("permAPct", "%.1f" % (100 * (0.5 + h4.loc["select_on_all+reCV(A)", "mean_minus_half"])))
put("permAfit", num(h4.loc["select_on_all+fitness(Afit)", "mean_minus_half"]))
put("permMaxDs", num(h4.loc["honest_test_BA", "max_abs_ds"]))

# ------------------------------------------------------------------------------------------------ budget effects on honest BA
q2 = rd("Q2b_honest_vs_budget.csv")
for lo, hi, key in ((250, 4000, "lo"), (4000, 16000, "hi")):
    for oc, ok in (("test_ba", "Ba"), ("fit", "Fit"), ("gap_B", "Gap"), ("k", "K")):
        r = q2[(q2.cp_lo == lo) & (q2.cp_hi == hi) & (q2.breakdown == "all") & (q2.outcome == oc)].iloc[0]
        nd = 2 if (key, ok) == ("hi", "Ba") else 1            # the interval of the 4000 -> 16000 honest change straddles 0 by a hair: show two decimals
        put("qb%s%s" % (key, ok), num(r.mean_diff, nd, pts=(oc != "k"))); put("qb%s%slo" % (key, ok), num(r.lo, nd, pts=(oc != "k"))); put("qb%s%shi" % (key, ok), num(r.hi, nd, pts=(oc != "k")))
        put("qb%s%sPos" % (key, ok), int(r.n_pos)); put("qb%s%sNds" % (key, ok), int(r.n_ds))
for (_lo_, _hi_), _k_ in (((250, 1000), "One"), ((1000, 4000), "Two")):          # honest BA gain per budget step
    _r = q2[(q2.cp_lo == _lo_) & (q2.cp_hi == _hi_) & (q2.breakdown == "all") & (q2.outcome == "test_ba")].iloc[0]
    put("qb%sBa" % _k_, num(_r.mean_diff))
hm = rd("E1h_honest_means.csv")
hm["gap"] = hm.fit_ba - hm.test_ba
for cp, c in ((250, "a"), (1000, "b"), (4000, "c")):
    g = hm[hm.cp == cp]
    put("meanFit%s" % c, "%.3f" % g.fit_ba.mean()); put("meanHonest%s" % c, "%.3f" % g.test_ba.mean())

# ------------------------------------------------------------------------------------------------ Q5
q5 = rd("Q5_across_datasets.csv"); q5 = q5[q5.cp == 4000]
for lr in ("ridge", "knn"):
    for a in ("ga", "bpso", "bde", "nsga2"):
        r = q5[(q5.learner == lr) & (q5.a == a) & (q5.b == "rs")].iloc[0]
        k = "rs" + LRN[lr] + ALGO[a]
        put(k, num(r.mean_diff)); put(k + "lo", num(r.lo)); put(k + "hi", num(r.hi)); put(k + "p", pv(r.p_holm_prereg)); put(k + "pn", int(r.n_pos)); put(k + "nds", int(r.n_ds))
    for a in ("ga", "bpso", "bde", "nsga2", "rs"):
        for b in ("anova", "rf", "all", "l1"):
            r = q5[(q5.learner == lr) & (q5.a == a) & (q5.b == b)].iloc[0]
            put("bl%s%s%s" % (LRN[lr], ALGO[a], BASEK[b]), num(r.mean_diff))
mean_rows = rd("Q5_mean_ba.csv"); mean_rows = mean_rows[mean_rows.cp == 4000]
cmp_ = json.load(open(os.path.join(T, "compare_summary.json"), encoding="utf-8"))
for lr in ("ridge", "knn"):
    fr = cmp_["friedman_cp4000_" + lr]
    put("fried%sChi" % LRN[lr], "%.1f" % fr["chi2"]); put("fried%sN" % LRN[lr], fr["n_ds"])
    for m, v in fr["mean_rank"].items():
        put("rank%s%s" % (LRN[lr], ALGO[m] if m in ALGO else BASEK[m]), "%.2f" % v)
wc = rd("Q5_within_counts.csv"); wc = wc[wc.cp == 4000]
r = wc[(wc.learner == "ridge") & (wc.a == "ga") & (wc.b == "all")].iloc[0]
put("gaAllWorseRidge", int(r.a_lower_mean)); put("gaAllNdsRidge", int(r.n_ds))
fam = rd("Q5_by_family.csv"); fam = fam[(fam.cp == 4000) & (fam.family == "HD")]
for a in ("ga", "nsga2", "bde", "bpso", "rs"):
    for b in ("anova", "rf", "all", "l1"):
        r = fam[(fam.learner == "ridge") & (fam.a == a) & (fam.b == b)].iloc[0]
        put("hd%s%sRidgeNpos" % (ALGO[a], BASEK[b]), int(r.n_pos)); put("hd%s%sRidgeNds" % (ALGO[a], BASEK[b]), int(r.n_ds))
q5b = rd("Q5b_advantage_inflation.csv"); q5b = q5b[q5b.cp == 4000]
for lr in ("ridge", "knn"):
    for a in ("ga", "bpso", "bde", "nsga2"):
        r = q5b[(q5b.learner == lr) & (q5b.algo == a)].iloc[0]
        k = "adv" + LRN[lr] + ALGO[a]
        put(k + "Rep", num(r["rep"])); put(k + "True", num(r["true"])); put(k + "Ratio", "%.1f" % (r["rep"] / r["true"]) if abs(r["true"]) > 1e-9 else "--")
        put(k + "Infl", num(r["infl"], 2)); put(k + "Infllo", num(r.infl_lo, 2)); put(k + "Inflhi", num(r.infl_hi, 2))
rk = rd("Q5b_rank_by_criterion.csv"); rk = rk[rk.cp == 4000]
put("tauRidge", "%.2f" % rk[rk.learner == "ridge"].kendall_tau_between_rankings.iloc[0]); put("tauKnn", "%.2f" % rk[rk.learner == "knn"].kendall_tau_between_rankings.iloc[0])
put("advRepMin", num(q5b["rep"].min())); put("advRepMax", num(q5b["rep"].max())); put("advTrueMin", num(q5b["true"].min())); put("advTrueMax", num(q5b["true"].max()))
rsmin = q5[(q5.b == "rs") & (q5.a != "rs")].mean_diff
put("rsAdvMin", num(rsmin.min())); put("rsAdvMax", num(rsmin.max()))
x5 = rd("X5s_vs_rs100.csv")
for lr in ("ridge", "knn"):
    for cp, c in ((1000, "One"), (4000, "Four")):
        for a in ("ga", "bpso", "bde", "nsga2"):
            r = x5[(x5.learner == lr) & (x5.cp == cp) & (x5.algo == a)].iloc[0]
            k = "rsh%s%s%s" % (LRN[lr], c, ALGO[a])
            put(k, num(r.mean_diff_vs_rs100)); put(k + "lo", num(r.lo)); put(k + "hi", num(r.hi)); put(k + "p", pv(r.p_holm))
xk = rd("X5s_k.csv")
put("rshK", "%.0f" % xk.k.mean())

# ------------------------------------------------------------------------------------------------ unit leakage, SMOTE, long budget, robustness
u = rd("E6u_record_vs_subject.csv"); u = u[(u.outcome == "ba") & (~u.inner_group)]
ur = u[u.learner == "ridge"]; uk = u[u.learner == "knn"]
put("parkRidgeMin", num(ur.mean_record_minus_subject.min())); put("parkRidgeMax", num(ur.mean_record_minus_subject.max()))
put("parkKnnMin", num(uk.mean_record_minus_subject.min())); put("parkKnnMax", num(uk.mean_record_minus_subject.max()))
r = u[(u.algo == "ga") & (u.learner == "ridge") & (u.cp == 4000)].iloc[0]
put("parkGaRidge", num(r.mean_record_minus_subject)); put("parkGaRidgeSd", num(r.sd)); put("parkGaRidgeNpos", int(r.n_pos)); put("parkGaRidgeN", int(r.n_rep))
ib = rd("E6u_inner_group_benefit.csv")
put("parkInnerMax", num(ib.mean_groupinner_minus_recordinner.abs().max()))
x3 = rd("X3u_pooled_by_sigma.csv"); x3 = x3[x3.contrast.str.startswith("record")]
for s, k in ((0.0, "Zero"), (0.5, "Half"), (1.0, "One"), (2.0, "Two")):
    r = x3[x3.sig_f == s].iloc[0]
    put("synth" + k, num(r.mean_diff)); put("synth%slo" % k, num(r.lo)); put("synth%shi" % k, num(r.hi))
so = rd("E5so_summary.csv")
for lr in ("ridge", "knn"):
    for oc, k in (("ba", "Ba"), ("auc", "Auc"), ("mcc", "Mcc"), ("f1", "Fone"), ("acc", "Acc")):
        r = so[(so.learner == lr) & (so.outcome == oc)].iloc[0]
        put("smo%s%s" % (LRN[lr], k), num(r["mean"])); put("smo%s%slo" % (LRN[lr], k), num(r.lo)); put("smo%s%shi" % (LRN[lr], k), num(r.hi)); put("smo%s%sNpos" % (LRN[lr], k), int(r.n_pos))
si = rd("E5si_summary.csv")
sidb = si[si.outcome == "d_test_ba"]
put("smiTestMax", num(sidb["mean"].abs().max()))
sig = si[si.outcome == "d_gapB"]
put("smiFitMax", num(sig["mean"].max())); put("smiFitMin", num(sig["mean"].min()))
r = sig[(sig.learner == "ridge") & (sig.cp == 250)].iloc[0]
put("smiRidgeLowFit", num(r["mean"])); put("smiRidgeLowFitlo", num(r.lo)); put("smiRidgeLowFithi", num(r.hi))
lp = rd("E7l_pooled.csv").set_index("algo")
for a in ("all", "ga", "nsga2", "rs"):
    k = {"all": "All", "ga": "Ga", "nsga2": "Nsgatwo", "rs": "Rs"}[a]
    put("long%sBa" % k, num(lp.loc[a, "d_test_ba"])); put("long%sBamin" % k, num(lp.loc[a, "d_test_ba_min"])); put("long%sBamax" % k, num(lp.loc[a, "d_test_ba_max"]))
    put("long%sFit" % k, num(lp.loc[a, "d_fit"])); put("long%sFitmin" % k, num(lp.loc[a, "d_fit_min"])); put("long%sFitmax" % k, num(lp.loc[a, "d_fit_max"]))
lb = rd("E7l_by_budget.csv")
put("longFitCeil", "%.3f" % lb[lb.cp == 4000].fit.mean())
x1 = rd("X1s_paired.csv")
_x1ds = x1.groupby("ds").d_ba.mean()                                   # one value per data set (three data sets): descriptive, no interval
put("scalerBa", num(_x1ds.mean(), 1, sign=True)); put("scalerBamin", num(_x1ds.min(), 1, sign=True)); put("scalerBamax", num(_x1ds.max(), 1, sign=True))
put("scalerNds", len(_x1ds)); put("scalerN", len(x1))
x4 = rd("X4r_landscape.csv")
for perm, k in ((0, "Perm"), (-1, "True")):
    g = x4[x4.perm == perm]
    o, p_ = g.gap_obs.to_numpy(), g.gap_pred_normal.to_numpy()
    put("land%sRsq" % k, "%.2f" % (1 - ((o - p_) ** 2).sum() / ((o - o.mean()) ** 2).sum())); put("land%sMae" % k, num(np.abs(o - p_).mean())); put("land%sCells" % k, len(g))
g = x4[(x4.perm == 0) & (x4.B == 16000)]
put("landPermMaxInn", "%.3f" % g.max_inn.mean()); put("landPermTest", "%.3f" % g.tst_at_max.mean())
q6 = rd("Q6_metric_summary.csv"); q6 = q6[q6.cp == 4000]
put("metricMaxP", pv(q6[q6.outcome.isin(["ba", "auc"])].p_holm.min()))
r = q6[(q6.learner == "knn") & (q6.algo == "ga") & (q6.fitness_metric == "acc") & (q6.outcome == "k")].iloc[0]
put("metricKnnAccK", "%.1f" % abs(r.mean_diff_vs_BA_fitness)); put("metricKnnAccKp", pv(r.p_holm))

# ------------------------------------------------------------------------------------------------ audit numbers (re-derived from the coding files)
sys.path.insert(0, os.path.join(ROOT, "audit"))
import codes  # noqa: E402
cod = codes.load("v1.1")                                 # first pass + the F1 corrections of the full-text recall check
cod_v1 = {c["pmcid"]: c for c in codes.load("v1")}
ext = {}
for l in open(os.path.join(ROOT, "audit", "extracts.jsonl"), encoding="utf-8"):
    r = json.loads(l); ext[r["pmcid"]] = r
inc = [c for c in cod if c["incl"] == 1 and ext[c["pmcid"]]["flags"]["ec_terms"] >= 5 and ext[c["pmcid"]]["flags"]["fs_terms"] >= 3 and ext[c["pmcid"]].get("article_type") == "research-article"]
n = len(inc)
assert n == 211, n
put("NIncluded", n); put("NSampled", len(cod)); put("NFrame", 933)
anyP = [c for c in inc if any(c[f] == "P" for f in ("F1", "F2", "F3", "F5", "F6"))]
put("auditAnyP", len(anyP)); put("auditAnyPPct", "%.1f" % (100.0 * len(anyP) / n))
from collections import Counter
cnt = {f: Counter(c[f] for c in inc) for f in ("F1", "F2", "F3", "F4", "F5", "F6")}
put("auditFoneU", cnt["F1"]["U"]); put("auditFoneUPct", "%.1f" % (100.0 * cnt["F1"]["U"] / n)); put("auditFoneA", cnt["F1"]["A"]); put("auditFoneAPct", "%.1f" % (100.0 * cnt["F1"]["A"] / n))
put("auditFoneP", cnt["F1"]["P"])
res_used = [c for c in inc if c["F2"] != "N"]
put("auditResUsed", len(res_used)); put("auditResStated", sum(1 for c in res_used if c["F2"] in "PA")); put("auditResP", sum(1 for c in res_used if c["F2"] == "P")); put("auditResA", sum(1 for c in res_used if c["F2"] == "A"))
fl = lambda k: sum(1 for c in inc if ext[c["pmcid"]]["flags"][k] > 0)
put("auditNested", fl("nested")); put("auditNestedPct", "%.1f" % (100.0 * fl("nested") / n)); put("auditCode", fl("code")); put("auditCodePct", "%.1f" % (100.0 * fl("code") / n))
put("auditStats", fl("stats_test")); put("auditStatsPct", "%.1f" % (100.0 * fl("stats_test") / n)); put("auditLeakWord", fl("leak_claim")); put("auditLeakWordPct", "%.1f" % (100.0 * fl("leak_claim") / n))
for g, (a, b) in {"One": (2021, 2022), "Two": (2023, 2024), "Three": (2025, 2026)}.items():
    sub = [c for c in inc if a <= ext[c["pmcid"]]["year"] <= b]
    put("auditYear%sN" % g, len(sub)); put("auditYear%sA" % g, "%.1f" % (100.0 * sum(1 for c in sub if c["F1"] == "A") / len(sub)))
# first-pass counts and the recall check of the extraction (audit/RECALL_CHECK.md)
_u1 = [c["pmcid"] for c in inc if cod_v1[c["pmcid"]]["F1"] == "U"]
put("auditFoneUfirst", len(_u1)); put("auditFoneUfirstPct", "%.1f" % (100.0 * len(_u1) / n)); put("auditFoneCorrected", sum(1 for c in inc if c.get("F1_v1")))
_rc = {}
for _l in open(os.path.join(ROOT, "audit", "recall_check.jsonl"), encoding="utf-8"):
    _r = json.loads(_l); _rc[_r["pmcid"]] = _r
put("recNU", len(_u1)); put("recNew", sum(1 for q in _u1 if any(not x["seen"] for x in _rc[q]["cands"])))
put("recNewPct", "%.0f" % (100.0 * sum(1 for q in _u1 if any(not x["seen"] for x in _rc[q]["cands"])) / len(_u1)))
put("recShownMedian", int(np.median([sum(len(v) for v in ext[q]["extracts"].values()) for q in _u1])))
put("recParsedMedian", int(np.median([ext[q]["n_sentences"] for q in _u1])))
put("recNoFsWhen", sum(1 for q in _u1 if len(ext[q]["extracts"].get("fs_when", [])) == 0))
put("recNoAnyOrder", sum(1 for q in _u1 if all(len(ext[q]["extracts"].get(k, [])) == 0 for k in ("split", "fs_when", "nested", "resample"))))
_rb = [json.loads(_l) for _l in open(os.path.join(ROOT, "audit", "recall_broad.jsonl"), encoding="utf-8")]
put("recBroadAny", sum(1 for _r in _rb if _r.get("n", 0) > 0))
rel = open(os.path.join(ROOT, "audit", "RELIABILITY.md"), encoding="utf-8").read()
assert "35/40 = 88%" in rel and "| F1 | 35 | 35 | 100% |" in rel and "两者都能判定的 24 篇中一致 22 篇（92%），κ = 0.47" in rel, "RELIABILITY.md changed: update the reliability macros"
put("relN", 35); put("relFoneAgree", "100"); put("relIncl", "88"); put("relRuleN", 24); put("relRuleAgree", 22); put("relRuleKappa", "0.47")


# extra counts used in the text
put("advTrueZeroCells", int((q5b["true_lo"] <= 0).sum())); put("advCells", len(q5b))
put("advInflPosCells", int((q5b["infl_lo"] > 0).sum()))
put("advInflZeroCells", int(((q5b["infl_lo"] <= 0) & (q5b["infl_hi"] >= 0)).sum()))
put("rsAdvSigCells", int((q5[(q5.b == "rs") & (q5.a != "rs")].p_holm_prereg < 0.05).sum()))
# honest overall level and over-statement at B* = 4000 pooled over algorithms / learners
_g = hm[hm.cp == 4000]
put("overallFitFour", "%.3f" % _g.fit_ba.mean()); put("overallHonestFour", "%.3f" % _g.test_ba.mean())
# HD data sets: in how many of the 9 data sets is each EFS algorithm worse than ANOVA (ridge)?
put("hdWorseAnovaMin", min(9 - int(fam[(fam.learner == "ridge") & (fam.a == a) & (fam.b == "anova")].iloc[0].n_pos) for a in ("ga", "bpso", "bde", "nsga2")))
put("hdWorseAllMin", min(9 - int(fam[(fam.learner == "ridge") & (fam.a == a) & (fam.b == "all")].iloc[0].n_pos) for a in ("ga", "bpso", "bde", "nsga2")))
# synthetic: effective sizes
put("synthInst", int(rd("X3u_pooled_by_sigma.csv").n.iloc[0])); put("synthPairs", int(rd("X3u_pooled_by_sigma.csv").n_pairs.iloc[0]))


# data-set specific over-statements quoted in the text
_dg = rd("H1_by_dataset.csv"); _dg = _dg[_dg.breakdown == "all"]
for _ds in ("cns", "ovarian", "colon", "ozone", "gli"):
    put("dsGapB" + cap(_ds), num(_dg[(_dg.ds == _ds) & (_dg.flaw == "B")].iloc[0].gap))
# RS vs RS100 (size effect of the null) and k of the algorithms at 4000
_x = x5[(x5.algo == "rs")]
put("rsVsRsh", num(_x.mean_diff_vs_rs100.mean()))
for _a in ("ga", "bpso", "bde", "nsga2", "rs"):
    for _lr in ("ridge", "knn"):
        _g2 = hm[(hm.cp == 4000) & (hm.algo == _a) & (hm.learner == _lr)]
        put("kMean%s%s" % (ALGO[_a], LRN[_lr]), "%.0f" % _g2.k.mean())


import math
def _wilson(k, n_, z=1.96):
    pp = k / n_; d = 1 + z * z / n_; c = (pp + z * z / (2 * n_)) / d
    h = z * math.sqrt(pp * (1 - pp) / n_ + z * z / (4 * n_ * n_)) / d
    return max(0.0, c - h), min(1.0, c + h)
_lo, _hi = _wilson(len(anyP), n); put("auditAnyPLo", "%.0f" % (100 * _lo)); put("auditAnyPHi", "%.0f" % (100 * _hi))
_pa = cnt["F1"]["P"] + cnt["F1"]["A"]; _lo, _hi = _wilson(cnt["F1"]["P"], _pa)
put("auditFoneStated", _pa); put("auditFonePStatedPct", "%.0f" % (100.0 * cnt["F1"]["P"] / _pa)); put("auditFonePStatedLo", "%.0f" % (100 * _lo)); put("auditFonePStatedHi", "%.0f" % (100 * _hi))
put("NAuditFrameAfter", 925); put("NAuditCoderIncl", 234)


_H = tabs["honest"]; _H = _H[(_H.suite == "E1h") & (_H.algo == "bde")]
for _cp, _c in ((1000, "One"), (4000, "Four"), (16000, "Sixteen")):
    _g3 = _H[_H.cp == _cp]
    put("deCapShare" + _c, "%.0f" % (100.0 * (_g3.k >= 100).mean()))
put("landCorrMax", "%.2f" % x4[x4.perm == -1].pearson.max())


_kp = mean_rows[mean_rows.learner == "knn"].pivot_table(index="ds", columns="method", values="mean_ba")
put("knnAnovaMean", "%.1f" % (100 * _kp["anova"].mean())); put("knnRfMean", "%.1f" % (100 * _kp["rf"].mean()))
put("knnAnovaRfMaxDs", "%.1f" % (100 * (_kp["anova"] - _kp["rf"]).abs().max()))


# ------------------------------------------------------------------------------------------------ revision studies (docs/DEVIATIONS.md #7-#9)
# D: superseded definition and the replay
_E = tabs["honest"]; _E = _E[(_E.suite == "E1h") & (_E.algo == "nsga2")].copy()
_E["gap_old"] = [np.max(a) - b for a, b in zip(_E.front_test_ba, _E.test_ba)]
put("dOldN", "{:,}".format(len(_E)).replace(",", "{,}")); put("dOldNeg", int((_E.gap_old < -1e-12).sum())); put("dOldMin", num(_E.gap_old.min()))
put("dOldNegA", int(((_E.gap_old < -1e-12) & (_E.cp == 250)).sum()))
_inc = 0
for _, _r in _E.iterrows():
    if any((int(fk) == int(_r.k)) and abs(fe - _r.inner_err) < 1e-12 for fk, fe in zip(_r.front_k, _r.front_inner_err)):
        _inc += 1
put("dOldNotInFront", len(_E) - _inc)
_P = LD.load_pareto()
_m = _E.merge(_P, on=["ds", "learner", "rep", "fold", "cp"], how="left", suffixes=("", "_x8"))
assert not _m.d_merged.isna().any() and (_m.test_ba == _m.test_ba_x8).all() and (_m.inner_err == _m.inner_err_x8).all() and (_m.k == _m.k_x8).all()
_ck = json.load(open(os.path.join(T, "X8p_check.json")))
assert _ck["n_different"] == 0 and _ck["n_records"] == _ck["n_expected_records"] == len(_P), _ck
put("xEightN", "{:,}".format(len(_P)).replace(",", "{,}")); put("xEightNumbers", "{:,}".format(_ck["n_numbers"]).replace(",", "{,}"))
put("xEightJobs", "{:,}".format(len(glob.glob(os.path.join(LD.EXTRA, "X8p", "*.json")))).replace(",", "{,}"))
_ff = _P.groupby("cp").agg(front=("n_front", "mean"), tied=("n_tied", "mean"), calls=("calls", "mean"), distinct=("distinct", "mean"))
for _cp, _c in ((250, "a"), (1000, "b"), (4000, "c"), (16000, "d")):
    put("dFront" + _c, "%.1f" % _ff.loc[_cp, "front"]); put("dTied" + _c, "%.1f" % _ff.loc[_cp, "tied"])
put("dDistinctNsgaFour", "%.0f" % _ff.loc[4000, "distinct"])

# requests vs distinct masks (X7d)
_dg = rd("X7d_distinct_diag.csv"); _sg = rd("X7d_seconds_by_algo.csv").set_index("algo")
for _a in ("ga", "bpso", "bde", "nsga2", "rs"):
    for _cp, _c in ((1000, "One"), (4000, "Four"), (16000, "Sixteen")):
        _r = _dg[(_dg.algo == _a) & (_dg.cp == _cp)]
        if len(_r):
            put("acct%s%sDistinct" % (ALGO[_a], _c), "{:,}".format(int(round(_r.iloc[0].mean_distinct))).replace(",", "{,}")); put("acct%s%sHit" % (ALGO[_a], _c), "%.0f" % (100 * _r.iloc[0].mean_hit_rate))
    put("acct%sSeconds" % ALGO[_a], "%.0f" % _sg.loc[_a, "mean_seconds"])
put("acctRuns", int(_dg[(_dg.algo == "ga") & (_dg.cp == 4000)].iloc[0].n))

# equal distinct masks instead of equal requests (X6d)
_dm = rd("X6r_distinct_matched.csv")  # revision 2: BOTH the search and RS reach the distinct-candidate target
assert (_dm.loc[_dm.comparison.str.startswith("vs"), "comparator_mode"] == "distinct").all(), "X6r must use a distinct-candidate random-search comparator"
for _lr in ("ridge", "knn"):
    for _a in ("ga", "nsga2"):
        for _t, _c in ((1000, "One"), (4000, "Four")):
            _r1 = _dm[(_dm.learner == _lr) & (_dm.algo == _a) & (_dm.target == _t) & _dm.comparison.str.startswith("vs")].iloc[0]
            _r2 = _dm[(_dm.learner == _lr) & (_dm.algo == _a) & (_dm.target == _t) & _dm.comparison.str.startswith("same")].iloc[0]
            _k = "dm%s%s%s" % (LRN[_lr], ALGO[_a], _c)
            put(_k, num(_r1.mean_diff)); put(_k + "lo", num(_r1.lo)); put(_k + "hi", num(_r1.hi)); put(_k + "p", pv(_r1.p)); put(_k + "Req", num(_r1.req_mean_diff))
            put(_k + "Calls", "{:,}".format(int(round(_r1.mean_calls))).replace(",", "{,}")); put(_k + "Same", num(_r2.mean_diff, 1, sign=True)); put(_k + "SameP", pv(_r2.p))
put("dmMaxSame", num(_dm[_dm.comparison.str.startswith("same")].mean_diff.abs().max()))
_xr = pd.read_csv(os.path.join(T, "X6d_runs.csv"))  # unchanged GA / NSGA-II trajectories
for _a in ("ga", "nsga2"):
    _c4 = _xr[(_xr.algo == _a) & (_xr.target == 4000)]
    put("dmMedCalls" + ALGO[_a], "{:,}".format(int(round(_c4.calls.median()))).replace(",", "{,}"))
    put("dmSmallPCalls" + ALGO[_a], "{:,}".format(int(round(_c4[_c4.ds.isin(["kc3", "oil_spill"])].calls.mean()))).replace(",", "{,}"))
put("dmUnreached", int((~_xr.reached.astype(bool)).sum()))

# same-size random search (X5m)
_sk = rd("X5m_same_size_rs.csv"); _se = rd("X5m_size_effect_on_rs.csv")
for _lr in ("ridge", "knn"):
    for _a in ("ga", "bpso", "bde", "nsga2"):
        for _b, _c in ((1000, "One"), (4000, "Four")):
            _r = _sk[(_sk.learner == _lr) & (_sk.ref == _a) & (_sk.budget == _b)].iloc[0]
            _k = "sk%s%s%s" % (LRN[_lr], ALGO[_a], _c)
            put(_k, num(_r.mean_diff)); put(_k + "lo", num(_r.lo)); put(_k + "hi", num(_r.hi)); put(_k + "p", pv(_r.p_holm)); put(_k + "K", "%.0f" % _r.mean_k)
            put(_k + "Pos", int(_r.n_pos)); put(_k + "Nds", int(_r.n_ds)); put(_k + "Vs", num(_r.vs_rs_mean_diff))
            _r2 = _se[(_se.learner == _lr) & (_se.ref == _a) & (_se.budget == _b)].iloc[0]
            put("sz%s%s%s" % (LRN[_lr], ALGO[_a], _c), num(_r2.mean_diff))
_f = _sk[_sk.budget == 4000]
put("skFourMin", num(_f.mean_diff.min())); put("skFourMax", num(_f.mean_diff.max())); put("skFourSig", int((_f.p_holm < 0.05).sum())); put("skFourN", len(_f))
put("skFourPosMin", int(_f.n_pos.min()))

# SMOTE decomposition (X9s)
_sd = rd("X9s_decomposition.csv")
for _lr in ("ridge", "knn"):
    for _m_, _mk in (("ba", "Ba"), ("auc", "Auc"), ("mcc", "Mcc"), ("f1", "Fone"), ("acc", "Acc")):
        for _c_, _ck in (("total", "Total"), ("composition", "Comp"), ("leakage", "Leak")):
            _r = _sd[(_sd.learner == _lr) & (_sd.metric == _m_) & (_sd.component == _c_)].iloc[0]
            put("smoDec%s%s%s" % (LRN[_lr], _ck, _mk), num(_r["mean"])); put("smoDec%s%s%slo" % (LRN[_lr], _ck, _mk), num(_r.lo)); put("smoDec%s%s%shi" % (LRN[_lr], _ck, _mk), num(_r.hi))
_chk = json.load(open(os.path.join(T, "X9s_check.json"))); put("smoDecJobs", _chk["n_jobs"]); assert _chk["max_abs_diff_vs_E5so"] == 0.0

# ------------------------------------------------------------------------------------------------ write numbers.tex
with open(os.path.join(GEN, "numbers.tex"), "w", encoding="utf-8") as f:
    f.write("% generated by paper/make_assets.py -- do not edit\n")
    for k in sorted(M):
        f.write("\\newcommand{\\%s}{%s}\n" % (k, M[k]))
print("macros:", len(M))


# ------------------------------------------------------------------------------------------------ tables
def write(name, text):
    open(os.path.join(GEN, name), "w", encoding="utf-8").write(text)


def row(cells):
    return " & ".join(str(c) for c in cells) + r" \\"


# Table: data sets
HD = ["colon", "cns", "dlbcl", "leukemia", "prostate", "gli", "smk", "ovarian", "breast"]
IMB = ["oil_spill", "ozone", "speech", "kc3"]
import suites as ST  # noqa: E402
lines = [r"\begin{tabular}{llrrrrl}", r"\toprule", r"Data set & Type & $n$ & $p$ & Minority (\%) & Outer repeats$^{a}$ & Source \\", r"\midrule"]
for nm in HD + IMB + ["parkinson"]:
    c = cards[nm]
    typ = "high-dim., small $n$" if nm in HD else ("imbalanced" if nm in IMB else "repeated measures (%d subjects)" % c["n_groups"])
    if nm == "parkinson":
        rep = "10 / 4$^{b}$"
    elif nm in ST.NO_KNN:
        rep = "%d" % ST.nrep(nm, "ridge", 10)
    else:
        rr, rk = ST.nrep(nm, "ridge", 10), ST.nrep(nm, "knn", 10)
        rep = "%d" % rr if rr == rk else "%d / %d" % (rr, rk)
    src = c["source"].replace("OpenML ", "OpenML ").replace("_", r"\_")
    lines.append(row([nm.replace("_", r"\_"), typ, c["n"], c["p"], "%.1f" % (100 * c["minority_fraction"]), rep, src]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_datasets.tex", "\n".join(lines) + "\n")

# Table: H1
def h1row(label, fl, dagger=""):
    r = h1[(h1.breakdown == "all") & (h1.flaw == fl)].iloc[0]
    ph = r.p_holm if not np.isnan(r.p_holm) else np.nan
    return row([label, "%s [%s, %s]" % (num(r["mean"]), num(r.lo), num(r.hi)), "%d/%d" % (r.n_pos, r.n_ds), "%.2f" % r.delta, pv(r.p_wilcoxon), pv(ph) if not np.isnan(ph) else "--"])
lines = [r"\begin{tabularx}{\linewidth}{@{}>{\raggedright\arraybackslash}X >{\centering\arraybackslash}p{0.228\linewidth} >{\centering\arraybackslash}p{0.086\linewidth} >{\centering\arraybackslash}p{0.082\linewidth} >{\centering\arraybackslash}p{0.115\linewidth} >{\centering\arraybackslash}p{0.115\linewidth}@{}}", r"\toprule", r"Practice & BA inflation (points), mean [95\% CI] & Data sets $>0$ & Cliff's $\delta$ & Wilcoxon $p$ & Holm $p$ \\", r"\midrule",
         r"\multicolumn{6}{@{}l@{}}{\emph{Primary family: four tests specified in advance}} \\",
         h1row(r"B: search fitness", "B"), h1row(r"A: preselect, then CV", "A"),
         h1row(r"D: test-picked Pareto point", "D"), h1row(r"E$_5$: best of 5 seeds", "E5"), r"\midrule",
         r"\multicolumn{6}{@{}l@{}}{\emph{Descriptive / exploratory: outside the Holm family}} \\",
         h1row(r"A$'$: preselect, then fitness", "Afit"), h1row(r"E$_3$: best of 3 seeds", "E3"), h1row(r"E$_{10}$: best of 10 seeds", "E10"),
         h1row(r"E$_{20}$: best of 20 seeds", "E20"), h1row(r"G: best algorithm per outer run", "G"),
         h1row(r"G$_2$: best algorithm per data set", "G2"), r"\bottomrule", r"\end{tabularx}"]
write("tab_h1.tex", "\n".join(lines) + "\n")

# Table: budget dose-response
lines = [r"\begin{tabular}{rccc}", r"\toprule", r"Budget (requests) & B: fitness as report & A: select-then-split & D: Pareto by test \\", r"\midrule"]
for cp in (250, 1000, 4000, 16000):
    cells = []
    for fl in ("B", "A", "D"):
        r = h1[(h1.breakdown == "cp=%d" % cp) & (h1.flaw == fl)].iloc[0]
        cells.append("%s [%s, %s]" % (num(r["mean"]), num(r.lo), num(r.hi)))
    nds = int(h1[(h1.breakdown == "cp=%d" % cp) & (h1.flaw == "B")].iloc[0].n_ds)
    lines.append(row(["{:,}".format(cp).replace(",", r"\,") + (" ($%d$ data sets)" % nds if nds != 13 else ""), *cells]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_budget.tex", "\n".join(lines) + "\n")

# Table: honest performance overview (pooled over data sets) at B* = 4000 for both learners
oh = hm[hm.cp == 4000].groupby(["learner", "algo"]).agg(fit=("fit_ba", "mean"), test=("test_ba", "mean"), gap=("gap", "mean"), k=("k", "mean"), n=("ds", "nunique")).reset_index()
lines = [r"\begin{tabular}{llcccc}", r"\toprule", r"Learner & Algorithm & Reported fitness BA & Honest BA & Over-statement & Mean $k$ \\", r"\midrule"]
for lr in ("ridge", "knn"):
    for a in ("ga", "bpso", "bde", "nsga2", "rs"):
        r = oh[(oh.learner == lr) & (oh.algo == a)].iloc[0]
        lines.append(row([("ridge" if lr == "ridge" else "5-NN") if a == "ga" else "", ALGO_NAME[a], "%.3f" % r.fit, "%.3f" % r.test, "%.3f" % r.gap, "%.1f" % r.k]))
    if lr == "ridge":
        lines.append(r"\midrule")
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_overview.tex", "\n".join(lines) + "\n")

# Table: Q5 vs RS and baselines
q5all = rd("Q5_across_datasets.csv"); q5all = q5all[q5all.cp == 4000]
lines = [r"\begin{tabular}{llccccc}", r"\toprule", r"Learner & Algorithm & $-$ RS & $-$ ANOVA & $-$ RF & $-$ All feat. & $-$ L$_1$-LR \\", r"\midrule"]
for lr in ("ridge", "knn"):
    for a in ("ga", "bpso", "bde", "nsga2", "rs"):
        cells = []
        for b in ("rs", "anova", "rf", "all", "l1"):
            if a == "rs" and b == "rs":
                cells.append("--"); continue
            r = q5all[(q5all.learner == lr) & (q5all.a == a) & (q5all.b == b)].iloc[0]
            star = r"$^{*}$" if r.p_holm < 0.05 else ""
            cells.append("%s%s" % (num(r.mean_diff), star))
        lines.append(row([("ridge" if lr == "ridge" else "5-NN") if a == "ga" else "", ALGO_NAME[a], *cells]))
    fr = cmp_["friedman_cp4000_" + lr]["mean_rank"]
    lines.append(r"\multicolumn{7}{l}{\emph{Friedman mean ranks (lower is better):} " + ", ".join("%s %.1f" % (ALGO_NAME[m], v) for m, v in sorted(fr.items(), key=lambda kv: kv[1])) + r"} \\")
    if lr == "ridge":
        lines.append(r"\midrule")
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_q5.tex", "\n".join(lines) + "\n")

# Table: Q5 vs RS with CI and pre-registered Holm p
lines = [r"\begin{tabular}{llcccr}", r"\toprule", r"Learner & Algorithm & Honest BA gain over RS (points) [95\% CI] & Data sets $>0$ & $p$ (Wilcoxon) & $p$ (Holm, family of 8) \\", r"\midrule"]
for lr in ("ridge", "knn"):
    for a in ("ga", "bpso", "bde", "nsga2"):
        r = q5all[(q5all.learner == lr) & (q5all.a == a) & (q5all.b == "rs")].iloc[0]
        lines.append(row([("ridge" if lr == "ridge" else "5-NN") if a == "ga" else "", ALGO_NAME[a], "%s [%s, %s]" % (num(r.mean_diff), num(r.lo), num(r.hi)), "%d/%d" % (r.n_pos, r.n_ds), pv(r.p), pv(r.p_holm_prereg)]))
    if lr == "ridge":
        lines.append(r"\midrule")
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_q5rs.tex", "\n".join(lines) + "\n")

# Table: reported vs outer-test advantage and their paired difference
lines = [r"\begin{tabular}{llccc}", r"\toprule",
         r"Learner & Algorithm & \shortstack{Fitness\\advantage\\over RS} & \shortstack{Outer BA\\advantage\\over RS} & \shortstack{Paired inflation\\(fitness $-$ outer BA)} \\", r"\midrule"]
for lr in ("ridge", "knn"):
    for a in ("ga", "bpso", "bde", "nsga2"):
        r = q5b[(q5b.learner == lr) & (q5b.algo == a)].iloc[0]
        lines.append(row([("ridge" if lr == "ridge" else "5-NN") if a == "ga" else "", ALGO_NAME[a], "%s [%s, %s]" % (num(r["rep"]), num(r.rep_lo), num(r.rep_hi)),
                          "%s [%s, %s]" % (num(r["true"]), num(r.true_lo), num(r.true_hi)),
                          "%s [%s, %s]" % (num(r["infl"], 2), num(r.infl_lo, 2), num(r.infl_hi, 2))]))
    if lr == "ridge":
        lines.append(r"\midrule")
lines += [r"\bottomrule",
          r"\multicolumn{5}{p{\dimexpr\linewidth-2\tabcolsep\relax}}{\footnotesize Exploratory, unadjusted 95\% Student-$t$ intervals across data sets (ridge: $N=13$; 5-NN: $N=11$). Inflation is the within-run paired difference between fitness and outer-BA advantages, averaged within each data set before inference.} \\",
          r"\end{tabular}"]
write("tab_adv.tex", "\n".join(lines) + "\n")

# Table: SMOTE
lines = [r"\begin{tabular}{lcccc}", r"\toprule", r"Metric & Ridge: over-statement [95\% CI] & Data sets $>0$ & 5-NN: over-statement [95\% CI] & Data sets $>0$ \\", r"\midrule"]
for oc, nm in (("ba", "BA"), ("auc", "AUC"), ("mcc", "MCC"), ("f1", "F1"), ("acc", "Accuracy")):
    cells = []
    for lr in ("ridge", "knn"):
        r = so[(so.learner == lr) & (so.outcome == oc)].iloc[0]
        cells += ["%s [%s, %s]" % (num(r["mean"]), num(r.lo), num(r.hi)), "%d/%d" % (r.n_pos, r.n_ds)]
    lines.append(row([nm, *cells]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_smote.tex", "\n".join(lines) + "\n")

# Table: unit leakage (Parkinson, budget 4000) + synthetic
u4 = rd("E6u_record_vs_subject.csv"); u4 = u4[(u4.outcome == "ba") & (u4.cp == 4000)]
lines = [r"\begin{tabular}{llccrr}", r"\toprule", r"Learner & Algorithm & Inner folds & Records $-$ subjects (BA points) & $\pm$ SD & Repeats $>0$ \\", r"\midrule"]
for lr in ("ridge", "knn"):
    for a in ("ga", "nsga2", "rs"):
        for ig in (False, True):
            rr = u4[(u4.learner == lr) & (u4.algo == a) & (u4.inner_group == ig)]
            if len(rr):
                r = rr.iloc[0]
                lines.append(row([("ridge" if lr == "ridge" else "5-NN") if (a == "ga" and not ig) else "", ALGO_NAME[a] if not ig else "", "by subject" if ig else "by record", num(r.mean_record_minus_subject), num(r.sd), "%d/%d" % (r.n_pos, r.n_rep)]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_unit.tex", "\n".join(lines) + "\n")

# Table: audit
au = json.load(open(os.path.join(ROOT, "audit", "audit_summary.json"), encoding="utf-8"))["flaws"]
NAMES = {"F1": "F1 selection before splitting / shared data", "F2": "F2 resampling before splitting", "F3": "F3 solution chosen on test data", "F4": "F4 best run only",
         "F5": "F5 no independent hold-out (fitness = report)", "F6": "F6 unit leakage (repeated measures split by record)"}
lines = [r"\begin{tabular}{lrrrrr}", r"\toprule", r"Practice & Present (P) & Absent (A) & Not stated (U) & Not applicable (N) & P / (P+A) \\", r"\midrule"]
for fk in ("F1", "F2", "F3", "F4", "F5", "F6"):
    r = au[fk]
    pa = r["P"] + r["A"]
    frac = "%.0f\\%% (%d/%d)" % (100.0 * r["P"] / pa, r["P"], pa) if pa else "--"
    lines.append(row([NAMES[fk], r["P"], r["A"], r["U"], r["N"], frac]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_audit.tex", "\n".join(lines) + "\n")

# Table: robustness summary
x2 = rd("X2k_paired.csv")
x2p = x2.groupby(["inner_k", "outcome", "cp"]).mean_diff_vs_k5.mean().reset_index()
def x2v(ik, oc, cp):
    return num(x2p[(x2p.inner_k == ik) & (x2p.outcome == oc) & (x2p.cp == cp)].iloc[0].mean_diff_vs_k5)
lines = [r"\begin{tabularx}{\linewidth}{@{}>{\raggedright\arraybackslash}p{0.37\linewidth} >{\raggedright\arraybackslash}p{0.34\linewidth} >{\raggedright\arraybackslash}X@{}}", r"\toprule", r"Sensitivity analysis & Quantity & Result \\", r"\midrule",
         r"Inner-fold standardisation (X1; 3 data sets) & Honest BA change: mean (data-set range) & %s (%s to %s) \\" % (num(_x1ds.mean(), 1, sign=True), num(_x1ds.min(), 1, sign=True), num(_x1ds.max(), 1, sign=True)),
         r"3 vs 5 inner folds (X2); 4\,000 requests & Honest BA / reported--honest gap change & %s / %s \\" % (x2v(3, "test_ba", 4000), x2v(3, "gap_B", 4000)),
         r"10 vs 5 inner folds (X2); 4\,000 requests & Honest BA / reported--honest gap change & %s / %s \\" % (x2v(10, "test_ba", 4000), x2v(10, "gap_B", 4000)),
         r"Fitness: accuracy / G-mean / AUC (E3m) & Minimum Holm $p$ for honest BA or AUC & %s \\" % pv(q6[q6.outcome.isin(["ba", "auc"])].p_holm.min()),
         r"RS$_{100}$ (X5s): ridge; 4\,000 requests & GA / BDE / NSGA-II gain over RS$_{100}$ & %s / %s / %s \\" % tuple(num(x5[(x5.learner == "ridge") & (x5.cp == 4000) & (x5.algo == a)].iloc[0].mean_diff_vs_rs100) for a in ("ga", "bde", "nsga2")),
         r"RS$_{100}$ (X5s): 5-NN; 1\,000 requests & GA / BDE / NSGA-II gain over RS$_{100}$ & %s / %s / %s \\" % tuple(num(x5[(x5.learner == "knn") & (x5.cp == 1000) & (x5.algo == a)].iloc[0].mean_diff_vs_rs100) for a in ("ga", "bde", "nsga2")),
         r"Same-size RS (X5m): ridge; 4\,000 requests & GA / BDE / NSGA-II gain over RS & %s / %s / %s \\" % tuple(num(_sk[(_sk.learner == "ridge") & (_sk.budget == 4000) & (_sk.ref == a)].iloc[0].mean_diff) for a in ("ga", "bde", "nsga2")),
         r"Same-size RS (X5m): 5-NN; 4\,000 requests & GA / BDE / NSGA-II gain over RS & %s / %s / %s \\" % tuple(num(_sk[(_sk.learner == "knn") & (_sk.budget == 4000) & (_sk.ref == a)].iloc[0].mean_diff) for a in ("ga", "bde", "nsga2")),
         r"Distinct-mask matching (X6d + X6r): ridge; 4\,000 candidates & GA / NSGA-II gain over RS & %s / %s \\" % tuple(num(_dm[(_dm.learner == "ridge") & (_dm.algo == a) & (_dm.target == 4000) & _dm.comparison.str.startswith("vs")].iloc[0].mean_diff) for a in ("ga", "nsga2")),
         r"\bottomrule", r"\end{tabularx}"]
write("tab_robust.tex", "\n".join(lines) + "\n")

# Appendix tables: honest BA per data set and method at budget 4000
def per_ds(lr):
    mr = mean_rows[mean_rows.learner == lr].pivot_table(index="ds", columns="method", values="mean_ba")
    cols = ["ga", "bpso", "bde", "nsga2", "rs", "anova", "rf", "all", "l1"]
    lines = [r"\begin{tabular}{l" + "c" * len(cols) + "}", r"\toprule", "Data set & " + " & ".join(ALGO_NAME[c] for c in cols) + r" \\", r"\midrule"]
    for nm in HD + IMB:
        if nm in mr.index:
            vals = [mr.loc[nm, c] for c in cols]
            best = np.nanmax(vals)
            lines.append(row([nm.replace("_", r"\_")] + [(r"\textbf{%.3f}" % v if v == best else "%.3f" % v) for v in vals]))
    lines += [r"\midrule", row([r"\emph{mean}"] + ["%.3f" % mr[c].mean() for c in cols]), r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


write("tab_perds_ridge.tex", per_ds("ridge")); write("tab_perds_knn.tex", per_ds("knn"))
# Appendix: per data set over-statements
dsg = rd("H1_by_dataset.csv"); dsg = dsg[dsg.breakdown == "all"].pivot_table(index="ds", columns="flaw", values="gap")
order = sorted(dsg.index, key=lambda x: np.log(cards[x]["p"] / cards[x]["n"]))
lines = [r"\begin{tabular}{lrrrrrrr}", r"\toprule", r"Data set & $p/n$ & B & A & D & E$_5$ & G$_2$ & \\", r"\midrule"]
lines[2] = r"Data set & $p/n$ & B & A & D & E$_5$ & G$_2$ \\"
lines = [r"\begin{tabular}{lrrrrrr}"] + lines[1:]
for nm in order:
    lines.append(row([nm.replace("_", r"\_"), "%.2f" % (cards[nm]["p"] / cards[nm]["n"])] + [num(dsg.loc[nm, k]) for k in ("B", "A", "D", "E5", "G2")]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_perds_gap.tex", "\n".join(lines) + "\n")


# Table: requests vs distinct masks, cache-hit share, run time (X7d)
lines = [r"\begin{tabular}{lrrrr}", r"\toprule", r"Algorithm & \multicolumn{3}{c}{Distinct masks evaluated (cache-hit share) at \dots\ requests} & Run time (s)$^{a}$ \\", r"\cmidrule(lr){2-4}",
         r" & 1\,000 & 4\,000 & 16\,000 & \\", r"\midrule"]
for _a in ("ga", "nsga2", "bpso", "bde", "rs"):
    cells = []
    for _cp in (1000, 4000, 16000):
        _r = _dg[(_dg.algo == _a) & (_dg.cp == _cp)]
        cells.append("%s (%.0f\\%%)" % ("{:,}".format(int(round(_r.iloc[0].mean_distinct))).replace(",", r"\,"), 100 * _r.iloc[0].mean_hit_rate) if len(_r) else "--")
    lines.append(row([ALGO_NAME[_a], *cells, "%.0f" % _sg.loc[_a, "mean_seconds"]]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_acct.tex", "\n".join(lines) + "\n")

# Table: equal distinct masks (X6d searches + X6r random-search comparator)
lines = [r"\begin{tabular}{llrrrcc}", r"\toprule", r"Learner & Algorithm & \shortstack{Distinct\\target} & \shortstack{Algorithm\\requests$^{a}$} & \shortstack{RS\\requests$^{a}$} & \shortstack{Gain over RS\\at equal requests} & \shortstack{Gain over RS\\at equal distinct masks} \\", r"\midrule"]
for _lr in ("ridge", "knn"):
    for _a in ("ga", "nsga2"):
        for _t in (1000, 4000):
            _r1 = _dm[(_dm.learner == _lr) & (_dm.algo == _a) & (_dm.target == _t) & _dm.comparison.str.startswith("vs")].iloc[0]
            lines.append(row([(("ridge" if _lr == "ridge" else "5-NN") if (_a == "ga" and _t == 1000) else ""), ALGO_NAME[_a] if _t == 1000 else "", "{:,}".format(_t).replace(",", r"\,"),
                              "{:,}".format(int(round(_r1.mean_calls))).replace(",", r"\,"), "{:,}".format(int(round(_r1.rs_calls))).replace(",", r"\,"), "%s [%s, %s]" % (num(_r1.req_mean_diff), num(_r1.req_lo), num(_r1.req_hi)),
                              "%s [%s, %s]" % (num(_r1.mean_diff), num(_r1.lo), num(_r1.hi))]))
    if _lr == "ridge":
        lines.append(r"\midrule")
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_distinct.tex", "\n".join(lines) + "\n")

# Table: same-size random search (X5m), budgets 4000 and 1000
for _b, _nm in ((4000, "tab_samesize.tex"), (1000, "tab_samesize1k.tex")):
    lines = [r"\begin{tabular}{llrcccr}", r"\toprule", r"Learner & Algorithm & Mean $k$ & Gain over ordinary RS & Gain over same-size RS [95\% CI] & Data sets $>0$ & $p$ (Holm) \\", r"\midrule"]
    for _lr in ("ridge", "knn"):
        for _a in ("ga", "bpso", "bde", "nsga2"):
            _r = _sk[(_sk.learner == _lr) & (_sk.ref == _a) & (_sk.budget == _b)].iloc[0]
            lines.append(row([(("ridge" if _lr == "ridge" else "5-NN") if _a == "ga" else ""), ALGO_NAME[_a], "%.0f" % _r.mean_k, num(_r.vs_rs_mean_diff),
                              "%s [%s, %s]" % (num(_r.mean_diff), num(_r.lo), num(_r.hi)), "%d/%d" % (_r.n_pos, _r.n_ds), pv(_r.p_holm)]))
        if _lr == "ridge":
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}"]
    write(_nm, "\n".join(lines) + "\n")

# Table: SMOTE decomposition (X9s)
lines = [r"\begin{tabular}{llccc}", r"\toprule", r"Learner & Metric & Total (flawed $-$ honest) & Test-row composition & \shortstack{Residual pipeline difference\\on real rows} \\", r"\midrule"]
for _lr in ("ridge", "knn"):
    for _m_, _nm_ in (("ba", "BA"), ("auc", "AUC"), ("mcc", "MCC"), ("f1", "F1")):
        cells = []
        for _c_ in ("total", "composition", "leakage"):
            _r = _sd[(_sd.learner == _lr) & (_sd.metric == _m_) & (_sd.component == _c_)].iloc[0]
            cells.append("%s [%s, %s]" % (num(_r["mean"]), num(_r.lo), num(_r.hi)))
        lines.append(row([(("ridge" if _lr == "ridge" else "5-NN") if _m_ == "ba" else ""), _nm_, *cells]))
    if _lr == "ridge":
        lines.append(r"\midrule")
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_smote_dec.tex", "\n".join(lines) + "\n")

# Table: three definitions of D by budget (appendix)
lines = [r"\begin{tabular}{rcccr}", r"\toprule", r"Budget (requests) & D: Pareto archive, merged (primary) & D$'$: ties kept & D$''$: E1h definition (superseded) & Negative D$''$ records \\", r"\midrule"]
for _cp in (250, 1000, 4000, 16000):
    cells = []
    for _fl in ("D", "Dties", "Dold"):
        _r = h1[(h1.breakdown == "cp=%d" % _cp) & (h1.flaw == _fl)].iloc[0]
        cells.append("%s [%s, %s]" % (num(_r["mean"]), num(_r.lo), num(_r.hi)))
    lines.append(row(["{:,}".format(_cp).replace(",", r"\,"), *cells, "%d / %d" % (int(((_E.gap_old < -1e-12) & (_E.cp == _cp)).sum()), int((_E.cp == _cp).sum()))]))
_r = [h1[(h1.breakdown == "all") & (h1.flaw == _fl)].iloc[0] for _fl in ("D", "Dties", "Dold")]
lines += [r"\midrule", row([r"all", *["%s [%s, %s]" % (num(x["mean"]), num(x.lo), num(x.hi)) for x in _r], "%d / %d" % (int((_E.gap_old < -1e-12).sum()), len(_E))]), r"\bottomrule", r"\end{tabular}"]
write("tab_dvariants.tex", "\n".join(lines) + "\n")

# Table: interval sensitivity (appendix)
lines = [r"\begin{tabular}{lccc}", r"\toprule", r"Practice & $t$ interval (primary) & Percentile bootstrap over data sets & Two-level bootstrap (first analysis) \\", r"\midrule"]
for _fl, _nm_ in (("B", "B"), ("A", "A"), ("D", "D"), ("E5", r"E$_5$")):
    _r = h1[(h1.breakdown == "all") & (h1.flaw == _fl)].iloc[0]
    lines.append(row([_nm_, "%s [%s, %s]" % (num(_r["mean"]), num(_r.lo), num(_r.hi)), "%s [%s, %s]" % (num(_r["mean"]), num(_r.lo_cb), num(_r.hi_cb)),
                      "%s [%s, %s]" % (num(_r["mean"]), num(_r.lo_db), num(_r.hi_db))]))
lines += [r"\bottomrule", r"\end{tabular}"]
write("tab_intervals.tex", "\n".join(lines) + "\n")

# ------------------------------------------------------------------------------------------------ figures (vector PDFs, paper-sized)
# produced by:  EFS_PAPER=1 python analysis/figures.py   (writes paper/figures/*.pdf with a smaller canvas so that text stays legible at column width)
for nm in ("fig1_budget", "fig2_gap_by_dataset", "fig3_gap_vs_pn", "fig4_permutation", "fig5_efs_vs_baselines", "fig6_long_budget", "fig7_unit_leakage", "fig8_advantage_inflation",
           "fig9_synthetic_units", "fig10_random_subset_landscape"):
    assert os.path.exists(os.path.join(FIGD, nm + ".pdf")), "missing paper figure %s: run  EFS_PAPER=1 python analysis/figures.py" % nm
print("tables written:", sorted(os.listdir(GEN)))
