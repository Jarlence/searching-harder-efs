"""Reorder the presentation of verified R22 evidence; no new estimators or runs."""
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "results/r22_strict_scaling/summary.csv"
FIGURES = ROOT / "paper/figures"
PREVIEW = ROOT / "submission/asc/qa/r22_evidence_order"
EXPECTED_SUMMARY = "909879b0d1d95c1f04c034b0f6ffaa40038a124949caca30ed2c4cabee460a5c"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sha(SOURCE) == EXPECTED_SUMMARY
    verification = json.loads((ROOT / "results/r22_strict_scaling/independent_verification.json").read_text(encoding="utf-8"))
    assert verification["jobs"] == 5350 and verification["checkpoints"] == 16050
    with SOURCE.open(encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    used = []

    def get(protocol, estimand, field, learner="all", algorithm="all", low=4000, high=4000):
        criteria = dict(protocol=protocol, estimand=estimand, field=field, learner=learner,
                        algorithm=algorithm, low_budget=str(low), high_budget=str(high))
        matches = [row for row in rows if all(row[key] == value for key, value in criteria.items())]
        assert len(matches) == 1, criteria
        row = matches[0]
        assert int(row["n_datasets"]) == (11 if learner == "knn" else 13)
        used.append(row)
        return row

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "pdf.fonttype": 42, "axes.spines.top": False, "axes.spines.right": False})
    PREVIEW.mkdir(parents=True, exist_ok=True)
    outputs = {}

    def save(fig, stem):
        fig.savefig(FIGURES / (stem + ".pdf"))
        fig.savefig(PREVIEW / (stem + ".png"), dpi=180)
        outputs[(FIGURES / (stem + ".pdf")).relative_to(ROOT).as_posix()] = sha(FIGURES / (stem + ".pdf"))
        plt.close(fig)

    # Same 13 datasets, available algorithm-learner cells and matched run keys
    # at every point. The original 16,000-request cohort is not stitched onto it.
    fig, axes = plt.subplots(1, 2, figsize=(6.7, 3.9), sharey=True)
    fig.subplots_adjust(left=.10, right=.98, bottom=.24, top=.81, wspace=.13)
    bounds = []
    budgets = [250, 1000, 4000]
    for ax, protocol, title in zip(axes, ("shared", "inner_fold"), ("A  Original shared scaling", "B  Strict inner-fold scaling")):
        for field, label, color, marker in (("F", "Inner fitness", "#a9474a", "o"), ("T", "Outer BA", "#167888", "s")):
            values = [get(protocol, "score_level", field, low=budget, high=budget) for budget in budgets]
            mean = np.array([float(row["mean_pp"]) for row in values])
            low = np.array([float(row["ci95_lo_pp"]) for row in values])
            high = np.array([float(row["ci95_hi_pp"]) for row in values])
            ax.plot(budgets, mean, color=color, marker=marker, lw=1.8, ms=4.5, label=label)
            ax.fill_between(budgets, low, high, color=color, alpha=.13, linewidth=0)
            bounds.extend([low.min(), high.max()])
        ax.set_xscale("log", base=4)
        ax.set_xticks(budgets)
        ax.set_xticklabels(["250", "1,000", "4,000"])
        ax.set_xlim(220, 4600)
        ax.set_xlabel("Wrapper requests")
        ax.set_title(title, fontsize=10.5, loc="left", pad=10)
        ax.grid(axis="y", alpha=.18)
        ax.set_axisbelow(True)
    axes[0].set_ylabel("Balanced accuracy (%)")
    axes[0].set_ylim(np.floor((min(bounds)-1)/5)*5, np.ceil((max(bounds)+1)/5)*5)
    axes[0].legend(loc="lower right", frameon=False, fontsize=9)
    fig.text(.54, .05, "Same 13 datasets and run keys at all three budgets; bands: pointwise 95% intervals", ha="center", fontsize=8.4)
    save(fig, "fig_r22_core_budget")

    # Show identical ordinary intervals for comparing protocols. Wider strict
    # intervals use the frozen nine-estimate family (not a newly chosen family
    # of eight). Their width is not evidence of a preprocessing effect.
    fig, axes = plt.subplots(1, 2, figsize=(6.7, 4.25), sharex=True, sharey=True)
    fig.subplots_adjust(left=.12, right=.98, bottom=.32, top=.85, wspace=.18)
    algorithms = [("ga", "GA"), ("bpso", "PSO"), ("bde", "DE"), ("nsga2", "NSGA-II")]
    family_positive = []
    ordinary_zero = 0
    for ax, learner, title in zip(axes, ("ridge", "knn"), ("A  Ridge: 13 datasets", "B  5-NN: 11 datasets")):
        for y, (algorithm, _) in enumerate(algorithms):
            original = get("shared", "algorithm_minus_rs", "B", learner, algorithm)
            strict = get("inner_fold", "algorithm_minus_rs", "B", learner, algorithm)
            assert int(strict["simultaneous_family_n"]) == 9
            for row, offset, color, marker in ((original, -.14, "#777777", "s"), (strict, .14, "#167888", "o")):
                mean = float(row["mean_pp"])
                lo, hi = float(row["ci95_lo_pp"]), float(row["ci95_hi_pp"])
                if row is strict:
                    flo, fhi = float(row["simultaneous_lo_pp"]), float(row["simultaneous_hi_pp"])
                    ax.plot([flo, fhi], [y+offset]*2, color=color, lw=1)
                    ax.plot([flo, flo], [y+offset-.06, y+offset+.06], color=color, lw=1)
                    ax.plot([fhi, fhi], [y+offset-.06, y+offset+.06], color=color, lw=1)
                    if flo > 0:
                        family_positive.append([learner, algorithm])
                    ordinary_zero += int(lo <= 0 <= hi)
                ax.plot([lo, hi], [y+offset]*2, color=color, lw=2.6)
                ax.scatter([mean], [y+offset], color=color, marker=marker, s=27, zorder=3, edgecolors="white", linewidths=.4)
        ax.set_title(title, fontsize=10.5, loc="left", pad=12)
        ax.set_yticks(range(4))
        ax.set_yticklabels([label for _, label in algorithms])
        ax.axvline(0, color="#959da4", lw=.9, ls="--")
        ax.grid(axis="x", alpha=.16)
        ax.set_axisbelow(True)
        ax.set_xlim(-3.5, 11.5)
        ax.set_xticks([-3, 0, 3, 6, 9])
        ax.set_xlabel("Advantage discrepancy (BA points)", fontsize=9)
    axes[0].set_ylim(3.55, -.55)
    assert ordinary_zero == 3
    assert family_positive == [["ridge", "ga"], ["knn", "nsga2"]]
    handles = [Line2D([0], [0], color="#777777", marker="s", lw=2.6, ms=4.5, label="Original: ordinary 95% interval"),
               Line2D([0], [0], color="#167888", marker="o", lw=2.6, ms=4.5, label="Strict: ordinary 95% interval"),
               Line2D([0], [0], color="#167888", lw=1, marker="|", ms=7, label="Strict: nine-estimate family interval")]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.54, .005), frameon=False, fontsize=8.8)
    save(fig, "fig_r22_core_advantage")

    record = dict(generator="paper/make_r22_core_figures.py", source_summary_sha256=sha(SOURCE),
                  source="results/r22_strict_scaling/summary.csv", new_experiments=0, new_estimators=0,
                  displayed_rows=used, outputs=outputs, algorithm_contrasts_per_protocol=8,
                  strict_ordinary_intervals_including_zero=ordinary_zero,
                  strict_family_intervals_above_zero=family_positive, family_size=9,
                  budget_coverage=[250, 1000, 4000], same_dataset_cohort_at_each_budget=True)
    (ROOT / "submission/asc/r22_core_figures_validation.json").write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
    print("Two core figures regenerated from %d stored rows; all eight contrasts and the fixed nine-estimate family retained." % len(used))


if __name__ == "__main__":
    main()
