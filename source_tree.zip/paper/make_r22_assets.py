"""Render verified R22 summaries into manuscript tables and macros.

Presentation only: no estimator, test, confidence interval or experiment is run.
Requires the complete frozen analysis and its independent verification.
"""
import csv
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "results/r22_strict_scaling"
PAPER = ROOT / "paper"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value, places=2):
    text = ("%.*f" % (places,float(value)))
    return text.replace("-",r"\ensuremath{-}")


def ci(row, family=False):
    stem="simultaneous" if family else "ci95"
    return "["+number(row[stem+"_lo_pp"])+", "+number(row[stem+"_hi_pp"])+"]"


def main():
    verification=json.loads((SRC/"independent_verification.json").read_text(encoding="utf-8"))
    validation=json.loads((SRC/"validation.json").read_text(encoding="utf-8"))
    assert verification["jobs"]==validation["jobs"]==5350
    assert verification["checkpoints"]==validation["paired_checkpoints"]==16050
    assert verification["freeze_sha256"]==validation["freeze_sha256"]==sha(ROOT/"docs/STRICT_SCALING_R22_FREEZE.json")
    for name,wanted in validation["outputs"].items():
        assert sha(SRC/name)==wanted,name
    rows=list(csv.DictReader((SRC/"summary.csv").open(encoding="utf-8")))
    def get(protocol,estimand,field,learner="all",algorithm="all",low=250,high=4000):
        matches=[r for r in rows if (r["protocol"],r["estimand"],r["field"],r["learner"],r["algorithm"],int(r["low_budget"]),int(r["high_budget"]))
                 ==(protocol,estimand,field,learner,algorithm,low,high)]
        assert len(matches)==1
        return matches[0]
    macros={}
    for field,name in (("F","Fit"),("T","Outer"),("B","Gap")):
        row=get("inner_fold","budget_increment",field)
        macros["strictBudget"+name]=number(row["mean_pp"])
        macros["strictBudget"+name+"Lo"]=number(row["ci95_lo_pp"])
        macros["strictBudget"+name+"Hi"]=number(row["ci95_hi_pp"])
        if field=="B":
            macros["strictBudgetGapFamilyLo"]=number(row["simultaneous_lo_pp"])
            macros["strictBudgetGapFamilyHi"]=number(row["simultaneous_hi_pp"])
            change=get("inner_minus_shared","budget_increment","B")
            macros["strictBudgetGapChange"]=number(change["mean_pp"])
            macros["strictBudgetGapChangeLo"]=number(change["ci95_lo_pp"])
            macros["strictBudgetGapChangeHi"]=number(change["ci95_hi_pp"])
    for field,name in (("F","Fit"),("T","Outer"),("B","Gap")):
        row=get("inner_fold","algorithm_minus_rs",field,"ridge","ga",4000,4000)
        macros["strictGa"+name]=number(row["mean_pp"])
        macros["strictGa"+name+"Lo"]=number(row["ci95_lo_pp"])
        macros["strictGa"+name+"Hi"]=number(row["ci95_hi_pp"])
        if field=="B":
            macros["strictGaGapFamilyLo"]=number(row["simultaneous_lo_pp"])
            macros["strictGaGapFamilyHi"]=number(row["simultaneous_hi_pp"])
    focal=[r for r in rows if r["focal"]=="True"]
    assert len(focal)==9
    adv=[r for r in focal if r["estimand"]=="algorithm_minus_rs"]
    macros["strictAdvZero"]=str(sum(float(r["ci95_lo_pp"])<=0<=float(r["ci95_hi_pp"]) for r in adv))
    macros["strictAdvFamilyZero"]=str(sum(float(r["simultaneous_lo_pp"])<=0<=float(r["simultaneous_hi_pp"]) for r in adv))
    macros["strictFocalPositive"]=str(sum(float(r["simultaneous_lo_pp"])>0 for r in focal))
    changes=[get("inner_minus_shared","algorithm_minus_rs","B",r["learner"],r["algorithm"],4000,4000) for r in adv]
    macros["strictAdvChangeMin"]=number(min(float(r["mean_pp"]) for r in changes))
    macros["strictAdvChangeMax"]=number(max(float(r["mean_pp"]) for r in changes))
    macros["strictReplayCount"]=str(validation["x1_replay_jobs"])
    (PAPER/"generated/numbers_r22.tex").write_text("% Verified complete R22 outputs; original numeric macros remain unchanged.\n"+
        "\n".join(r"\newcommand{\%s}{%s}"%(k,v) for k,v in macros.items())+"\n",encoding="utf-8")
    labels={"ga":"GA","bpso":"BPSO","bde":"DE","nsga2":"NSGA-II"}
    table=[r"\begin{tabular}{@{}lrrcc@{}}",r"\toprule",r"Quantity & Shared & Strict & 95\% interval & Family interval \\",r"\midrule"]
    for i,row in enumerate(focal):
        if row["estimand"]=="budget_increment":
            label=r"Budget gap, 250--4{,}000"
        else:
            if row["algorithm"]=="ga":
                table.append(r"\midrule")
                table.append(r"\multicolumn{5}{@{}l}{\textit{%s: advantage discrepancy at 4{,}000}} \\"%("Ridge ($N=13$)" if row["learner"]=="ridge" else "5-NN ($N=11$)"))
            label=labels[row["algorithm"]]
        old=get("shared",row["estimand"],row["field"],row["learner"],row["algorithm"],int(row["low_budget"]),int(row["high_budget"]))
        table.append("%s & %s & %s & %s & %s \\\\"%(label,number(old["mean_pp"]),number(row["mean_pp"]),ci(row),ci(row,True)))
    table += [r"\bottomrule",r"\end{tabular}"]
    (PAPER/"readable/tab_r22_core.tex").write_text("\n".join(table)+"\n",encoding="utf-8")
    table=[r"\begin{tabular}{@{}llrrc@{}}",r"\toprule",r"Learner & Algorithm & Change & $N$ & Descriptive 95\% interval \\",r"\midrule"]
    for row in changes:
        table.append("%s & %s & %s & %s & %s \\\\"%("Ridge" if row["learner"]=="ridge" else "5-NN",labels[row["algorithm"]],number(row["mean_pp"]),row["n_datasets"],ci(row)))
    table += [r"\bottomrule",r"\end{tabular}"]
    (PAPER/"readable/tab_r22_changes.tex").write_text("\n".join(table)+"\n",encoding="utf-8")
    for source,target in (("focal_estimates.pdf","fig_r22_datasets.pdf"),("budget_curves.pdf","fig_r22_budget.pdf")):
        shutil.copy2(SRC/source,PAPER/"figures"/target)
    outputs={str(p.relative_to(ROOT)).replace("\\","/"):sha(p) for p in
             [PAPER/"generated/numbers_r22.tex",PAPER/"readable/tab_r22_core.tex",PAPER/"readable/tab_r22_changes.tex",
              PAPER/"figures/fig_r22_datasets.pdf",PAPER/"figures/fig_r22_budget.pdf"]}
    payload=dict(source_summary_sha256=sha(SRC/"summary.csv"),source_validation_sha256=sha(SRC/"validation.json"),
                 independent_verification_sha256=sha(SRC/"independent_verification.json"),outputs=outputs,new_numeric_macros=len(macros),
                 new_estimators=0,new_intervals=0,all_nine_focal_estimates_present=True)
    (ROOT/"submission/asc/r22_assets_validation.json").write_text(json.dumps(payload,indent=2)+"\n",encoding="utf-8")
    print("Rendered R22 tables/figures and %d numeric macros from verified summaries."%len(macros))


if __name__=="__main__":main()
