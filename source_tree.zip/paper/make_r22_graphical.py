"""Graphical abstract from complete R22 results; no new scientific analysis."""
import csv
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
HERE=ROOT/"submission/asc"
SOURCE=ROOT/"results/r22_strict_scaling/summary.csv"


def main():
    verification=json.loads((ROOT/"results/r22_strict_scaling/independent_verification.json").read_text(encoding="utf-8"))
    assert verification["jobs"]==5350
    rows=list(csv.DictReader(SOURCE.open(encoding="utf-8")))
    def get(**criteria):
        matches=[r for r in rows if all(r[k]==str(v) for k,v in criteria.items())]
        assert len(matches)==1,criteria
        return matches[0]
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"pdf.fonttype":42,
                         "axes.spines.top":False,"axes.spines.right":False})
    fig,axes=plt.subplots(1,3,figsize=(13.28,5.31),gridspec_kw={"width_ratios":[1,1.45,1.12]})
    fig.subplots_adjust(left=.06,right=.98,bottom=.23,top=.68,wspace=.61)
    fig.suptitle("Search effort, reported gains and outer performance",fontsize=20,fontweight="bold",y=.97)
    fig.text(.5,.87,"Full-core sensitivity: strict inner-fold scaling | 13 datasets for ridge; 11 for 5-NN",ha="center",fontsize=13,color="#48535f")
    ax=axes[0]
    budget=[get(protocol="inner_fold",estimand="budget_increment",learner="all",algorithm="all",low_budget=250,high_budget=4000,field=f) for f in ("F","T")]
    mean=np.array([float(r["mean_pp"]) for r in budget]);low=np.array([float(r["ci95_lo_pp"]) for r in budget]);high=np.array([float(r["ci95_hi_pp"]) for r in budget])
    ax.bar([0,1],mean,color=["#ab3e45","#227b87"],width=.6,yerr=[mean-low,high-mean],capsize=4)
    ymax=max(8.8,high.max()+1.5);ax.set_ylim(min(0,low.min()-.3),ymax)
    for x,y,top in zip((0,1),mean,high):ax.text(x,top+.3,"%+.2f"%y,ha="center",fontsize=13,fontweight="bold")
    ax.set_xticks([0,1]);ax.set_xticklabels(["Inner\nBA","Outer\nBA"])
    ax.set_ylabel("BA gain (percentage points)")
    ax.set_title("A   Budget: 250 to 4,000\nwrapper requests",loc="left",fontsize=12,pad=16)
    ax.grid(axis="y",alpha=.17);ax.set_axisbelow(True)
    ax=axes[1]
    adv=[];labels=[]
    for learner,name in (("ridge","Ridge"),("knn","5-NN")):
        for algo,label in (("ga","GA"),("bpso","PSO"),("bde","DE"),("nsga2","NSGA-II")):
            adv.append(get(protocol="inner_fold",estimand="algorithm_minus_rs",learner=learner,algorithm=algo,low_budget=4000,high_budget=4000,field="B"))
            labels.append(name+" / "+label)
    for y,row in enumerate(adv):
        color="#227b87" if y<4 else "#ab3e45"
        ax.plot([float(row["simultaneous_lo_pp"]),float(row["simultaneous_hi_pp"])],[y,y],color=color,lw=1.0)
        ax.plot([float(row["ci95_lo_pp"]),float(row["ci95_hi_pp"])],[y,y],color=color,lw=3.2)
        ax.scatter(float(row["mean_pp"]),y,s=30,color=color,zorder=3)
    ax.set_yticks(np.arange(8));ax.set_yticklabels(labels,fontsize=9)
    ax.invert_yaxis();ax.axvline(0,color="#8c959b",ls="--",lw=.9)
    ax.set_xlabel("Inner advantage minus outer advantage\n(BA percentage points)",fontsize=10)
    ax.set_title("B   Algorithm vs ordinary RS\n4,000 requests; all eight contrasts",loc="left",fontsize=12,pad=16)
    ax.grid(axis="x",alpha=.16)
    ax=axes[2];ax.axis("off")
    ax.set_title("C   Define the comparison\nSeparate original-protocol controls",loc="left",fontsize=12,pad=16)
    for y,title,body in ((.94,"Requests","Equal wrapper calls\nCache hits count"),(.61,"Distinct candidates","Equal evaluated masks\nGA and NSGA-II checks"),(.28,"Subset size","Size chosen by the algorithm\nConditional same-size RS")):
        ax.text(0,y,title,va="top",fontweight="bold",fontsize=12,color="#183149")
        ax.text(0,y-.105,body,va="top",fontsize=10,color="#48535f",linespacing=1.35)
    fig.text(.5,.055,"Paired run differences; equal dataset weights. Thick bars: unadjusted 95% intervals.\nThin bars in B: Bonferroni intervals for the fixed nine-estimate family. Exploratory follow-up on previously analysed datasets.",ha="center",fontsize=10,color="#48535f",linespacing=1.5)
    for ext in ("pdf","png"):fig.savefig(HERE/("graphical_abstract."+ext),dpi=300)
    plt.close(fig)
    caption="Graphical abstract for the full-core strict-inner-scaling follow-up (X10s). A: paired budget gains from 250 to 4,000 requests across all 13 datasets after averaging available algorithm-learner cells. B: all eight paired algorithm-minus-ordinary-RS advantage discrepancies at 4,000 requests (ridge: 13 datasets; 5-NN: 11). Thick bars are unadjusted 95% dataset-level t intervals; thin bars in B are Bonferroni intervals from the fixed nine-estimate family, whose ninth estimate is the budget-gap increase. C: separate random-reference controls from the original shared-scaling protocols; these were not jointly matched or rerun with strict scaling. X10s is an exploratory sensitivity extension on previously analysed data, not independent confirmation. All points are generated from stored verified summaries with Matplotlib; no generative image model was used.\n"
    (HERE/"graphical_abstract_caption.txt").write_text(caption,encoding="utf-8")
    from PIL import Image
    with Image.open(HERE/"graphical_abstract.png") as rendered:
        pixels=list(rendered.size)
        assert min(rendered.info["dpi"])>299
    provenance=dict(source_tables={SOURCE.relative_to(ROOT).as_posix():hashlib.sha256(SOURCE.read_bytes()).hexdigest()},
                    generator="paper/make_r22_graphical.py",new_estimators=0,source="complete independently checked R22 summaries",size_pixels=pixels,dpi=300)
    (HERE/"graphical_abstract_provenance.json").write_text(json.dumps(provenance,indent=2)+"\n",encoding="utf-8")
    print("Generated the R22 graphical abstract from all eight verified strict-scaling contrasts.")


if __name__=="__main__":main()
