"""Expose an existing axis-label glyph outside the figure's original page box.

Only the vector PDF page boundary changes. Drawing streams, resources and all
plotted observations are copied without replotting or re-estimating anything.
"""
import hashlib
import json
from pathlib import Path
from pypdf import PdfReader, PdfWriter

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "paper/source_assets/fig4_permutation_original.pdf"
TARGET = ROOT / "paper/figures/fig4_permutation.pdf"
OUT = ROOT / "submission/asc/qa/r22_evidence_order/frame_fix.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert sha(SOURCE.read_bytes()) == "be1eaa1eb9e60043e177d47362b2bc5e8ba95c26039bbcca955041e05d62588a"
reader = PdfReader(SOURCE)
assert len(reader.pages) == 1
page = reader.pages[0]
before = list(map(float, page.mediabox))
stream = page.get_contents().get_data()
page.mediabox.upper_right = (page.mediabox.right, float(page.mediabox.top) + 9)
page.cropbox = page.mediabox
writer = PdfWriter()
writer.add_page(page)
with TARGET.open("wb") as handle:
    writer.write(handle)
after = PdfReader(TARGET).pages[0]
assert after.get_contents().get_data() == stream
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(dict(source=SOURCE.relative_to(ROOT).as_posix(),
    source_sha256=sha(SOURCE.read_bytes()), target=TARGET.relative_to(ROOT).as_posix(),
    target_sha256=sha(TARGET.read_bytes()), original_page_box=before,
    revised_page_box=list(map(float, after.mediabox)), drawing_stream_sha256=sha(stream),
    drawing_stream_unchanged=True, new_estimators=0,
    reason="Expose the closing text of the existing vertical axis label; original vector content preserved"), indent=2)+"\n", encoding="utf-8")
print("Expanded the Figure 2 vector page boundary by 9 points; drawing stream unchanged.")
