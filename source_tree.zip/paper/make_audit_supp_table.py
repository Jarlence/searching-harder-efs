"""Derive a readable audit table without changing the audit codes or counts."""
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "generated" / "tab_audit.tex"
OUTPUT = ROOT / "generated" / "tab_audit_supp.tex"


def audit_rows(text):
    rows = []
    for line in text.splitlines():
        if re.match(r"^F[1-6]\s", line):
            row_text = line[:-2] if line.endswith(r"\\") else line
            cells = [cell.strip() for cell in row_text.split("&")]
            if len(cells) != 6 or not all(cell.isdigit() for cell in cells[1:5]):
                raise ValueError("Unexpected audit-table row: " + line)
            rows.append(cells)
    if len(rows) != 6 or [row[0][:2] for row in rows] != [
        "F1", "F2", "F3", "F4", "F5", "F6"
    ]:
        raise ValueError("Expected the six audit practices in their original order")
    return rows


def main():
    original = SOURCE.read_text(encoding="utf-8")
    rows = audit_rows(original)
    lines = [
        r"\begin{tabularx}{\linewidth}{@{}>{\raggedright\arraybackslash}Xrrrrr@{}}",
        r"\toprule",
        r"Practice & \shortstack{Present\\(P)} & \shortstack{Absent\\(A)} & "
        r"\shortstack{Not\\stated\\(U)} & \shortstack{Not\\applicable\\(N)} & "
        r"\shortstack{P /\\(P+A)} \\",
        r"\midrule",
    ]
    lines.extend(" & ".join(row) + r" \\" for row in rows)
    lines.extend([r"\bottomrule", r"\end{tabularx}", ""])
    derived = "\n".join(lines)
    if audit_rows(derived) != rows:
        raise AssertionError("Audit labels, codes, counts, or ratios changed")
    OUTPUT.write_text(derived, encoding="utf-8")
    print("Derived six unchanged audit rows: " + str(OUTPUT))


if __name__ == "__main__":
    main()
