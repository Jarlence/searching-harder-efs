# R22 execution and manuscript handoff

**Completed, 13 October 2026.** All 5,350 new jobs and 16,050 checkpoints finished with zero recorded job errors. Complete-coverage analysis and independent arithmetic verification passed. The final manuscript and S3 are compiled; current source/PDF checks and the sealed package are identified by submission/asc/RELEASE_MANIFEST.json. The pipeline status ready_for_manuscript_review records the numerical pipeline's handoff, not an unfinished experiment.

Execution was interrupted after 1,362 completed atomic records. The stale lock's process was verified to have ended before removing the lock and resuming the remaining 3,988 jobs. Frozen sources and job keys were unchanged. No partial scientific estimates were used to select or stop configurations. All 300 X1 overlap records match exactly in their score and mask fields.

The remaining instructions document the rules followed during execution and integration.

The user authorised new experiments on 13 October 2026 (Asia/Shanghai). This
changes the previous restriction against new experiments, while keeping author
and public-release information pending.

## Scientific decision

The full-core strict-scaling follow-up has priority because it directly tests
whether the manuscript's budget effect and relative-advantage discrepancies are
sensitive to inner validation rows participating in scaling. More runs cannot
turn the same benchmark into independent confirmation or guarantee acceptance.
The follow-up must be reported even if the key discrepancies shrink or change
sign. Its role is a protocol sensitivity study, not a new optimisation method.

The fixed design and analysis are in `STRICT_SCALING_R22_PLAN.md`; the immutable
local freeze is `STRICT_SCALING_R22_FREEZE.json`. It contains 5,350 jobs, 16,050
checkpoints, original comparator hashes, processed-data hashes, source hashes
and locked environment versions. The source fingerprint is
`91f2a2cb7619f7db529b4a7d0ac824da096804d59687972071495ce779c06e69`.

Before this freeze, eight implementation tests passed: fold-scaler isolation,
outer-test isolation for all five algorithms and both learners, bit-exact X1
implementation equivalence, matching search trajectories, passive checkpoints,
full job coverage, correct paired/data-set aggregation, and nine-estimate
family/figure generation. The original budget means and confidence intervals,
and the original GA/ridge 6.05-point advantage discrepancy, were independently
reproduced by the new analysis script before running the new experiments.

## Execution

The first fixed prefix of 50 jobs uses four workers to check resource behaviour.
The continuation uses six workers, one BLAS thread each. Scheduling changes
neither the job list nor the estimands. No partial scientific summary is made.

`extras/complete_r22.ps1` is a one-time local completion process. It runs the
remaining jobs, complete-coverage analysis, and an independent arithmetic
verifier. It does not schedule recurring tasks, upload anything, or modify
the manuscript. The independent verifier was added after the scientific freeze;
it implements no new estimator or selection rule and records its own hash.

Status files:

- `results/r22_pipeline_status.json`: resource check, running, analysis,
  independent verification, failure, or ready for manuscript review.
- `results/r22_strict_scaling_progress.json`: job counts and elapsed time only.
- `results/r22_pipeline_stdout.log` / `results/r22_pipeline_stderr.log`: execution logs.
- `results/jobs_extra/X10s/`: new job records; old jobs are read-only.
- `results/r22_strict_scaling/`: complete summaries, dataset values, figures,
  provenance and independent verification. This directory is created only after
  full coverage has been verified by the analysis script.

If execution is interrupted, inspect errors and active processes first. A stale
`.runner.lock` may be removed only after verifying its recorded process has
ended. Never run two dispatchers against the same output tree. Resume with the
same frozen source and locked Python environment; do not overwrite the freeze.

## Interpretation and manuscript integration

Read all nine focal estimates and their dataset values before editing the
abstract or cover letter. Report both unadjusted 95% and nine-estimate Bonferroni
intervals; the latter does not erase the history of selecting this follow-up
after observing the original results. Compare strict and shared procedures by
matched runs, keeping the training-size and sample-composition boundaries.

If the main conclusions persist, present this as broader sensitivity evidence,
with actual changes and uncertainty. If they materially weaken, make that change
visible and narrow the claims. Do not hide a changed sign or a wide interval.
Small/nonsignificant changes do not establish equivalence.

Update the methods, core budget and algorithm-comparison results, inner-scaling
limitation, abstract, introduction and cover letter consistently. Keep original
versus follow-up results distinguishable. The follow-up covers ordinary RS and
budgets up to 4,000, not strict-scaled 16,000/long-budget or same-size controls.
Preserve all eight algorithm/learner contrasts and all original negative results.

During the same revision, fix the previously verified wording issues: distinguish
error `1-BA`, scalar objective `0.99*error+0.01*k/p`, and reported inner BA; display
the existing paired budget-gap interval; specify that the label-permutation
tolerance is for the data-set-equal aggregate, not every dataset; acknowledge
the dimension-dependent effective cardinality penalty and error-first NSGA-II
incumbent rule. These are clarifications, not new experimental changes.

Only after interpreting and integrating the completed results should `main.pdf`,
source packages and the research-materials release be rebuilt and verified.
R22 now supersedes R20 as the current manuscript; old R20 snapshots remain intact. Numerical completion alone was not treated as completion of the manuscript: source/PDF, visual and packaging checks were performed separately.

The blinded audit key and human verification sheet remain excluded from all
reads, hashes, outputs and archives. Author/publication fields remain pending.
