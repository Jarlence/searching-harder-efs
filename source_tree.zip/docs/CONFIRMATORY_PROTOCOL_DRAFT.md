# Confirmatory study — protocol DRAFT v0 (NOT registered, nothing has been run)

> 中文提示：这是为"第二批确证性实验"起草的协议，**还没有登记，也没有下载任何新数据、没有运行任何东西**。
> 只有当你（1）审阅并修改它，（2）批准下载哪些数据集，（3）把它上传到外部登记处（OSF Registries / AsPredicted 等）并拿到时间戳**之后**，才会开始跑。
> 登记之前，第 1–6 节可以改；登记之后不再改，只能追加带日期的修订说明。第一项研究相对于这项研究是"探索性的先验证据"，这一项是用事先选定的新数据做的检验。

## 0. Purpose and status

The first study (`paper/`) measured the over-statement of reporting practices in evolutionary feature selection on 13 public data sets (nine high-dimensional biomedical sets, four imbalanced tabular sets) with two fixed learners (ridge, 5-NN) and untuned textbook searches. Its hypotheses were fixed before the main run only internally, and several of its analyses were added or corrected after the results were known. This study asks whether the core findings **replicate on data sets chosen in advance, outside the biomedical domain, with larger n, and with a learner of a different type**. Hypotheses and decision rules below are written before any new data are touched.

## 1. Hypotheses and decision rules (unit of inference = data set)

Let `B` = reported search fitness minus honest outer-test BA (practice B), `H(b)` = honest BA at `b` wrapper requests, `RSk` = random search with the subset size of the reference algorithm's incumbent in the same outer run.

* **C1 (inflation).** For each learner, the mean over data sets of `B` at 4,000 requests is positive and at least 3 BA points. *Rule:* one-sided Wilcoxon signed-rank over data sets, Holm over learners (alpha = 0.05), and the lower limit of the 95 % cluster-bootstrap interval of the mean is >= 3 points.
* **C2 (budget).** The share of (data set, algorithm, learner) cells with Spearman rho(B, log2 budget) > 0 is >= 75 % (pooled and in the mean over data sets, lower 95 % cluster-bootstrap limit >= 60 %), while `H(16,000) - H(4,000)` (mean over data sets) lies within +/- 1 point (the 90 % cluster-bootstrap interval is inside +/- 1: TOST-style equivalence).
* **C3 (null model).** For GA and NSGA-II with each learner, `H(4,000) - RSk(4,000)` (mean over data sets) has an upper 95 % bound below 3 points. Reported with and without equalising the number of *distinct* evaluated masks.
* **C4 (fitness-based ranking).** The five algorithms ranked by reported fitness and by honest BA (mean ranks over data sets, 4,000 requests) do not have identical order for at least one learner; Kendall tau is reported (no threshold).
* **C5 (one score-correction / early-stopping method, see section 5).** At equal total requests (all extra evaluations counted), the method lowers `B` relative to plain GA by at least 2 points, and its honest BA differs from plain GA by less than 1 point in absolute value (equivalence) — i.e. it reduces the *reported* inflation without improving the *true* performance, or, if it improves it, the improvement is reported as such. Either outcome is a result.

Every hypothesis is reported whether it holds or not. Secondary and exploratory analyses (anything not listed above) are labelled exploratory.

## 2. Data (to be fixed and registered BEFORE any download)

* Inclusion rule: public binary (or binarised, rule stated per data set) classification data; 500 <= n <= 20,000 after removing rows with missing values; 20 <= p <= 1,000 numeric features after one-hot encoding of categorical features with at most 10 levels; licence allows research use; **none** of the 14 data sets of the first study; at least 8 of the 12 data sets outside the biomedical domain.
* Size: 12 data sets (power note: with 12 data sets the smallest attainable two-sided Wilcoxon p is 0.0005).
* The list (OpenML identifiers, rule for the positive class) is entered here by the authors and registered with this document: `TODO: list of 12 identifiers`. The assistant will verify each identifier against the OpenML metadata and report n, p, licence and class balance **before** registration, which needs a metadata request per data set and no data download beyond that.
* No data set is added or dropped after registration; a data set that cannot be processed is reported as failed, not replaced.

## 3. Learners, algorithms, budgets, protocol

* Learners (fixed hyper-parameters, no tuning layer): class-balanced ridge (as before) and **one learner of another type** — proposal: CART decision tree, maximum depth 5, balanced class weights (`TODO: confirm; alternatives: linear SVM, naive Bayes`).
* Algorithms: GA, NSGA-II, budget-matched RS, same-size RS (as in the first study; same implementation, `src/efsbench`), plus the method of section 5.
* Budgets: 250, 1,000, 4,000, 16,000 wrapper requests; distinct masks and run time recorded.
* Honest protocol: repeated stratified 5-fold (10 repeats for n < 2,000, 5 repeats otherwise); all data-driven steps inside the training part; the leak-detector tests must pass before the run; a label-permutation control (5 permutations, GA and RS) must report chance within +/- 3 points.
* Practices measured: B and A as before; D with the Pareto-archive definition; E (best of 5 seeds) on three outer folds.

## 4. Analysis

* Unit of inference: data set. Within-data-set values are means over outer runs; intervals are percentile bootstrap intervals over data-set-level values (10,000 resamples), tests are Wilcoxon signed-rank over data sets; no test within a data set.
* Multiplicity: Holm within each hypothesis (over learners / algorithms as stated).
* Outputs are generated by the scripts of the first study (`analysis/`), extended only to read the new job files; the extension is committed and hashed before the first job runs.

## 5. The score-correction / early-stopping method for C5 (proposal; to be fixed before registration)

Validation-based early stopping in the spirit of Loughrey & Cunningham: hold out 20 % of the outer-training part as a validation set (stratified); the GA works on the remaining 80 % (inner CV there); after every generation the incumbent is scored on the validation set; the search stops after 5 generations without improvement of that score, or at the budget; the final model is trained on the whole outer-training part with the selected columns. **Every validation scoring counts as one wrapper request**, so that cost is equal to plain GA at the same total number of requests. `TODO: the authors may prefer another method (for example re-scoring the elite with fresh inner folds); whichever is chosen is specified here, in full, before registration.`

## 6. What is NOT promised

No claim is made that the results will agree with the first study. The decision rules above cannot be changed after seeing results. If hypotheses fail, the paper reports that.

## 7. Registration checklist (for the authors)

1. Review and edit this draft; fill the TODOs (data list, second learner, section 5 method).
2. Approve which data sets may be downloaded (the assistant does not download anything without that approval).
3. Upload to an external registry and keep the receipt (URL, time stamp). Only then run.
4. Report the registration URL in the new paper; amendments only with dates.
