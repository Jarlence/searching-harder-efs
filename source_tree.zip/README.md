# t1 — 进化特征选择（EFS）的可信评估

当前版本为 ASOC R22：联合测量搜索预算、内部评分、外层收益，以及算法相对随机搜索的优势差距。报告做法的文献发生率并未由本研究确定。探索性审计不充当发生率证据。

**当前稿件**：[paper/main.pdf](paper/main.pdf)，53 页；[中文说明](paper/论文中文摘要.md)；[本轮修订依据](docs/ASC_R22_REVISION.md)；[完整投稿材料说明](submission/asc/README.md)。作者与公开发布信息保留待确认，尚未投稿或上传。

用户授权新实验后，本轮完成了严格内层标准化的全部核心复核：5,350 个新作业、16,050 个检查点；原 38,360 个作业保持不变，总计 43,710 个。新结果在 [results/r22_strict_scaling/REPORT.md](results/r22_strict_scaling/REPORT.md)。预算 250→4,000 请求时，内层 BA 增加 5.93 点、外层增加 0.92 点；GA/ridge 的优势差距为 5.71 点，全部八组算法比较均保留。六组家族区间跨零，结果仍是旧数据上的探索性敏感性证据。

冻结方案见 [STRICT_SCALING_R22_PLAN.md](docs/STRICT_SCALING_R22_PLAN.md)，实施记录见 [runbook](docs/STRICT_SCALING_R22_RUNBOOK.md)，复现入口见 [REPRODUCE.md](REPRODUCE.md)。原结果的 SUMMARY、最终报告、Revision 2 和后续 #16–#20 文档是相应阶段的记录，不代表完整的 R22 数字或当前封包。历史冻结与旧快照保留；当前文件身份由 results/MANIFEST.json 和 submission/asc/RELEASE_MANIFEST.json 绑定。

## 目录


| 路径 | 内容 |
|---|---|
| `docs/PROTOCOL.md` | 主实验运行前写下并哈希的**内部协议**（不是外部预注册）：假设、数据集、算法、学习器、预算、估计量、统计 |
| `docs/ANALYSIS_PLAN.md` | 分析细则补充（主实验进行期间、查看任何性能数字之前写下；**没有被哈希**） |
| `docs/DEVIATIONS.md` | 对协议的偏离、修订与更正（包括 R22），每条都写了触发原因、改动、是否看过结果 |
| `docs/REVISION_1.md` | 外部评审的逐条核实记录与仍待你决定的事 |
| `docs/CONFIRMATORY_PROTOCOL_DRAFT.md` | 确证性研究的协议**草稿**（未登记，未运行任何东西） |
| `docs/FREEZE_dev2.json` → `dev3` → `dev4` → `dev5` | 代码 / 数据 / 协议的 SHA-256；dev2–dev4 是主实验期间的冻结，**dev5 是修订时点的记录**（不能证明更早的顺序）；作业文件里的 `code_sha` 与之对应 |
| `src/efsbench/` | 基准实现（见其中的 README.md）：诚实协议、有缺陷协议、五个搜索算法、固定学习器、指标、SMOTE、基线、`tracking.py`（Pareto 档案、请求 / 不同候选数记账） |
| `tests/` | 实施测试（含 R22 新增八项检查）：泄漏探测（把外层测试部分换成乱码，所选特征必须不变；含 Pareto 档案）、与 sklearn 数值等价、预算计数等 |
| `experiments/` | 作业定义与可续跑驱动：`suites.py`、`run_suite.py`、`status.py`、`freeze*.py`；`verify_data.py`（离线校验数据）、`get_data.py`（联网重建数据）；每个作业一个 JSON（`results/jobs/<套件>/`） |
| `extras/` | 额外研究：早期的（标准化逐折重拟合、内层折数、合成单元数据、随机子集景观、RS100）与评审后的（`ex_suites3.py`：Pareto 重放 X8p、不同候选数 X6d、同尺寸随机搜索 X5m、记账诊断 X7d；`ex_suites4.py`：SMOTE 描述性分解 X9s；`ex_suites5.py`：随机搜索补齐不同候选数 X6r），结果在 `results/jobs_extra/` |
| `analysis/` | 汇总与统计：`inflation.py`（Q1–Q4）、`compare.py`（Q5–Q6）、`special.py`、`extras_analysis.py`、`revision.py`（修订1研究）、`revision2.py`（严格不同候选数比较）、`figures.py`、`report.py`；`test_statsx.py` 测试统计函数 |
| `audit/` | 文献审计（探索性）：抽样框（Europe PMC 开放获取全文）、编码手册、首轮编码 `coding_v1.jsonl`（不改）、扩展文章文本检索并检查命中片段（`recall_check.py`、`RECALL_CHECK.md`、`recheck_overrides.jsonl`）、可靠性、**给两位读者的盲核对表**与钥匙文件 |
| `novelty/` | 查新记录、语料、`watch.py`（定期重跑严格查询只列出新论文） |
| `paper/` | **论文稿**（英文 LaTeX）：`main.tex`、`sections/`、`refs.bib`、自动生成的 `generated/`（数字宏与表）、`figures/`、`make_assets.py`、`main.pdf` |
| `pilot/` | 方向选择阶段的原型实验（合成数据；**不是论文结论**） |
| `examples/quickstart.py` | 十行以内跑一次"适应度 vs 诚实 BA"的对照 |
| `results/` | `jobs/`（主作业，每个一个 JSON）、`jobs_extra/`（额外与修订作业）、`superseded/`（被替换的旧结果与**第一稿的全部文件**，保留备查）、`tables/`、`figures/`、`SUMMARY.md`、`REPRODUCIBILITY.md`、`MANIFEST.json` |
| `data/` | 14 个公开数据集（OpenML / UCI，md5 / sha256 已校验）；`data_cards.json` 记录来源与哈希 |

## 复现

环境：Python 3.8.20，numpy 1.24.4，scipy 1.10.1，pandas 2.0.3，scikit-learn 1.3.2，joblib 1.4.2，matplotlib 3.7.5（`requirements-lock.txt`；本机用 conda 环境 `evolve`）。
**不要往 `evolve` 环境里装包**（它是另一篇稿件的冻结环境）。所有命令在项目根目录执行，建议先 `OMP_NUM_THREADS=1`。三条入口（数据校验 / 从作业到论文 / 全部重跑）见 [`REPRODUCE.md`](REPRODUCE.md)。

```
python -m unittest discover -s tests                       # 先过原实施测试与 R22 新增检查
python analysis/test_statsx.py
python experiments/verify_data.py                          # 离线校验 14 个数据集的 md5 / sha256
python experiments/run_suite.py --suites E1h,Eperm,E1f,E2b,E5so,E5si,E6u,E3m,E4s,E7l --workers 20    # 主实验（约 20 600 个作业；可中断、可续跑）
python extras/run_extra.py --suites X1s,X2k,X3u,X4r,X5s --workers 8                                   # 早期额外研究
python extras/run_extra3.py --suites X8p,X6d,X5m,X7d --workers 20                                     # 评审后的追加研究
python extras/run_extra4.py --suites X9s --workers 8
python extras/run_extra5.py --workers 4                    # 修订2：RS精确达到1000/4000不同掩码
python experiments/status.py                                # 进度
python analysis/run_all.py                                 # 依次运行 inflation / compare / special / extras_analysis / revision / revision2 / figures / report -> results/tables、figures、SUMMARY.md
python analysis/repro_check.py 60                           # 随机抽样作业从头重跑，逐位比较 -> results/REPRODUCIBILITY.md（会覆盖该文件）
EFS_PAPER=1 python analysis/figures.py                      # 论文尺寸的图 -> paper/figures（PowerShell：$env:EFS_PAPER='1'; python analysis/figures.py）
python paper/make_assets.py                                 # 从 results/、audit/ 生成 paper/generated/（数字宏与表）
(cd paper && latexmk -pdf main.tex)                         # 编译论文（TeX Live 2026）-> paper/main.pdf
python analysis/manifest.py                                 # 最后一步：results/MANIFEST.json（所有文件哈希）
```

## 研究与发布状态

* 论文稿（`paper/`）是在实验全部做完之后才写的；稿中数字全部由脚本生成。真实作者、单位、仓库地址、基金与利益冲突按用户指示保留占位；AI 使用声明记录实际辅助过程。当前是本地材料，公开发布尚未完成。
* **没有把这项研究称为预注册**：协议只是内部事先设定并哈希，没有外部时间戳；事后上传 OSF / Zenodo 只是存档。要预注册，只能为之后的确证性研究在运行前登记（草稿见 `docs/CONFIRMATORY_PROTOCOL_DRAFT.md`）。
* 没有注册账号、没有登录任何站点、没有上传或投稿任何东西；没有下载任何新的数据集（审计补充核查对文章文本做模式检索并检查命中片段，不是独立人工逐篇全文阅读）。
* Li 等（2026）的公开主稿与补充材料已完整阅读；获取哈希、读取范围与比较见 `novelty/external/li2026/provenance.md`。没有独立重跑对方实验。
* 没有碰 `D:\Python_project\进化算法` 项目，也没有复用它的 5 个数据集。
* 没有绕过任何站点的反爬 / 速率限制（dblp、OpenAlex 匿名额度）。
* 作者声明、利益冲突、投稿、arXiv 预印本、审计的人工核对由你本人完成。
