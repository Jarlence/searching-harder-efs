# Independent X1 core check

Status: passed. No experiments, model fitting or inferential statistics.

All 600 raw main/X1 run-checkpoint pairs, 300 GA-RS pairs, six derived CSVs and 704 input hashes were independently checked.
Main comparators use the same 25 outer keys. F, T, B and Delta_adv identities and data-set-equal averaging agree.

Pooled strict-minus-main changes (percentage points): {'d_fit': -0.011130923742795413, 'd_outer_ba': 0.39729270617824847, 'd_gap_B': -0.4084236299210439}

Relative-discrepancy changes are not uniformly in one direction; negative data-set discrepancies are retained in the JSON/CSV.
Source/spec evidence supports common fold/RNG keys, but saved JSON has no fold indices or predictions.
The result cannot establish full-scope robustness, practical equivalence, pure search bias or fixed-mask causal preprocessing effects.
