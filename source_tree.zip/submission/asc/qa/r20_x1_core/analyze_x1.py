"""Describe core X1 sensitivity using saved results, without fitting anything.

Python 3.8+, standard library only. Default invocation writes derived CSV/JSON
only beside this script. --verify reproduces and compares deterministic tables
and checks recorded input hashes, without writing files. No analysis-module
imports, caches, searches, classifiers, p-values or confidence intervals.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
DS = ("colon", "prostate", "kc3")
LEARNERS = ("ridge", "knn")
ALGOS = ("ga", "rs")
CP = (1000, 4000)
FORBIDDEN = re.compile(r"DO_NOT_OPEN|verification_(?:key|sheet)|__pycache__", re.I)
TOL = 1e-12


def safe(path):
    if FORBIDDEN.search(str(path)):
        raise RuntimeError("Excluded path; refused without opening it")
    return path


def sha(path):
    return hashlib.sha256(safe(path).read_bytes()).hexdigest()


def mean(values):
    values = list(values)
    if not values:
        raise RuntimeError("Empty descriptive mean")
    return math.fsum(values) / len(values)


def csv_blob(rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8")


def source_evidence(text, relative, fragment):
    for n, line in enumerate(text.splitlines(), 1):
        if fragment in line:
            return {"path": relative, "line": n, "excerpt": line.strip()}
    raise RuntimeError("Required source evidence absent: " + relative + ": " + fragment)


def analyze(root):
    inputs = {}

    def read(relative):
        path = safe(root / relative)
        blob = path.read_bytes()
        inputs[relative] = {"bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}
        return blob

    def record(relative):
        return json.loads(read(relative).decode("utf-8-sig"))

    def table(relative):
        return list(csv.DictReader(io.StringIO(read(relative).decode("utf-8-sig"))))

    protected_paths = sorted(
        p.relative_to(root).as_posix()
        for directory, pattern in (
            ("results/tables", "*"), ("paper/generated", "*.tex"),
            ("paper/readable", "tab_samesize_readable.tex"),
            ("paper/readable", "tab_q5rs_readable.tex"),
            ("paper/readable", "tab_q5_readable.tex"),
            ("submission/asc/qa/r18_rs_advantage", "*.py"),
            ("submission/asc/qa/r18_rs_advantage", "*.json"),
            ("submission/asc/qa/r18_rs_advantage", "*.csv"),
            ("submission/asc/qa/r18_rs_advantage", "README.md"),
        )
        for p in (root / directory).glob(pattern)
        if p.is_file() and not FORBIDDEN.search(str(p))
    )
    before = {relative: sha(root / relative) for relative in protected_paths}
    result_tables = [p for p in protected_paths if p.startswith("results/tables/")]
    assert len(result_tables) == 61
    macro_text = read("paper/generated/numbers.tex").decode("utf-8")
    macro_count = len(re.findall(r"\\newcommand\{\\(\w+)\}", macro_text))
    assert macro_count == 1069

    extra_source = read("extras/ex_suites.py").decode("utf-8")
    main_source = read("experiments/suites.py").decode("utf-8")
    proto_source = read("src/efsbench/protocols.py").decode("utf-8")
    read("src/efsbench/algos.py")
    read("src/efsbench/splits.py")
    analysis_source = read("analysis/extras_analysis.py").decode("utf-8")
    evidence = {
        "outer_split_x1": source_evidence(extra_source, "extras/ex_suites.py",
                                         "tr, te = outer_split(y, ds, rep, fold)"),
        "outer_split_main": source_evidence(main_source, "experiments/suites.py",
                                           "tr, te = outer_split(y, ds, rep, fold, tag, use_g)"),
        "inner_key_x1": source_evidence(extra_source, "extras/ex_suites.py",
                                       'S.rng_for("inner", ds, lr, rep, fold, None, False, False)'),
        "inner_key_main": source_evidence(main_source, "experiments/suites.py",
                                         '("inner", ds, lr, rep, fold, pid, s.get("outer_group", False), in_g)'),
        "algorithm_key_x1": source_evidence(extra_source, "extras/ex_suites.py",
                                           'S.rng_for("algo", ds, algo, lr, rep, fold, None, 0, False, False)'),
        "algorithm_key_main": source_evidence(main_source, "experiments/suites.py",
                                             '("algo", ds, algo, lr, rep, fold, pid, s.get("seed", 0)'),
        "strict_inner_scaling": source_evidence(extra_source, "extras/ex_suites.py",
                                                "a, b = P.standardize(Xraw[tr], Xraw[te])"),
        "outer_scaling_x1": source_evidence(extra_source, "extras/ex_suites.py",
                                           "Xtr_s, Xte_s = P.standardize(Xtr, Xte)"),
        "outer_scaling_main": source_evidence(proto_source, "src/efsbench/protocols.py",
                                             "Xtr_s, Xte_s = standardize(Xtr, Xte)"),
        "existing_gap_difference": source_evidence(analysis_source, "analysis/extras_analysis.py",
                                                   '"d_gapB": ((1 - a.inner_err) - a.test_ba)'),
    }
    expected = set(itertools.product(DS, ALGOS, LEARNERS, range(5), range(5), CP))
    records = {}
    job_counts = Counter()
    code_shas = {"X1s": Counter(), "E1h": Counter()}
    raw_fields = set()
    main_coverage = set()
    files = sorted((root / "results/jobs_extra/X1s").glob("*.json"))
    assert len(files) == 300
    for path in files:
        relative = path.relative_to(root).as_posix()
        x = record(relative)
        s = x["spec"]
        assert x["status"] == "ok" and s["kind"] == "scaler" and s["suite"] == "X1s"
        key5 = tuple(s[k] for k in ("ds", "algo", "learner", "rep", "fold"))
        assert s["cps"] == list(CP) and sorted(map(int, x["result"])) == list(CP)
        main_path = "results/jobs/E1h/E1h__%s__%s__%s__rep%d__fol%d__metba.json" % key5
        m = record(main_path)
        ms = m["spec"]
        assert m["status"] == "ok" and ms["kind"] == "honest" and ms["suite"] == "E1h"
        assert tuple(ms[k] for k in ("ds", "algo", "learner", "rep", "fold")) == key5
        assert ms.get("metric", "ba") == "ba" and ms.get("seed", 0) == 0
        assert ms.get("perm") is None and not ms.get("outer_group", False) and not ms.get("inner_group", False)
        job_counts[(s["ds"], s["learner"], s["algo"])] += 1
        code_shas["X1s"][x["code_sha"]] += 1
        code_shas["E1h"][m["code_sha"]] += 1
        main_coverage.update(map(int, m["result"]))
        for cp in CP:
            strict = x["result"][str(cp)]
            main = m["result"][str(cp)]
            raw_fields.update(strict)
            key = key5 + (cp,)
            assert key not in records
            f0, f1 = 1 - main["inner_err"], 1 - strict["inner_err"]
            t0, t1 = main["test_ba"], strict["test_ba"]
            assert all(math.isfinite(v) for v in (f0, f1, t0, t1))
            records[key] = {
                "main_fit": f0, "strict_fit": f1, "main_outer_ba": t0, "strict_outer_ba": t1,
                "main_gap_B": f0 - t0, "strict_gap_B": f1 - t1,
                "d_fit": f1 - f0, "d_outer_ba": t1 - t0,
                "d_gap_B": (f1 - t1) - (f0 - t0),
                "d_auc": strict["test_auc"] - main["test_auc"],
                "main_k": main["k"], "strict_k": strict["k"], "d_k": strict["k"] - main["k"],
            }
    assert set(records) == expected and all(n == 25 for n in job_counts.values())

    existing = table("results/tables/X1s_paired.csv")
    existing_keys = set()
    max_paired_difference = 0.0
    field_map = {"d_ba": "d_outer_ba", "d_fit": "d_fit", "d_gapB": "d_gap_B",
                 "d_auc": "d_auc", "d_k": "d_k"}
    for row in existing:
        key = (row["ds"], row["algo"], row["learner"], int(row["rep"]), int(row["fold"]), int(row["cp"]))
        assert key not in existing_keys
        existing_keys.add(key)
        for source_field, raw_field in field_map.items():
            max_paired_difference = max(max_paired_difference,
                                        abs(float(row[source_field]) - records[key][raw_field]))
    assert existing_keys == expected and max_paired_difference <= TOL
    summary = table("results/tables/X1s_summary.csv")
    max_summary_difference = 0.0
    summary_keys = set()
    for row in summary:
        cell = (row["ds"], row["learner"], row["algo"], int(row["cp"]))
        assert cell not in summary_keys
        summary_keys.add(cell)
        values = [v for k, v in records.items()
                  if (k[0], k[2], k[1], k[5]) == cell]
        assert len(values) == int(row["n"]) == 25
        for source_field, raw_field in list(field_map.items())[:3]:
            max_summary_difference = max(max_summary_difference,
                                         abs(float(row[source_field]) - mean(v[raw_field] for v in values)))
    assert summary_keys == set(itertools.product(DS, LEARNERS, ALGOS, CP))
    assert max_summary_difference <= TOL

    paired = []
    for k, v in sorted(records.items()):
        paired.append(dict(zip(("ds", "algo", "learner", "rep", "fold", "cp"), k), **v))
    core_fields = ("main_fit", "strict_fit", "main_outer_ba", "strict_outer_ba",
                   "main_gap_B", "strict_gap_B", "d_fit", "d_outer_ba", "d_gap_B")
    cells = []
    for ds, learner, algo, cp in itertools.product(DS, LEARNERS, ALGOS, CP):
        values = [v for k, v in records.items() if (k[0], k[2], k[1], k[5]) == (ds, learner, algo, cp)]
        cells.append(dict(ds=ds, learner=learner, algo=algo, cp=cp, n_pairs=len(values),
                          **{field: mean(v[field] for v in values) for field in core_fields}))
    pooled = []
    for ds in DS:
        values = [v for k, v in records.items() if k[0] == ds]
        pooled.append(dict(ds=ds, n_run_checkpoint_pairs=len(values),
                           **{field: mean(v[field] for v in values) for field in core_fields}))
    pooled_summary = {
        field: {"mean_pp": 100 * mean(r[field] for r in pooled),
                "min_dataset_mean_pp": 100 * min(r[field] for r in pooled),
                "max_dataset_mean_pp": 100 * max(r[field] for r in pooled)}
        for field in core_fields
    }
    advantage_runs = []
    for ds, learner, cp, rep, fold in itertools.product(DS, LEARNERS, CP, range(5), range(5)):
        ga = records[(ds, "ga", learner, rep, fold, cp)]
        rs = records[(ds, "rs", learner, rep, fold, cp)]
        r = dict(ds=ds, learner=learner, cp=cp, rep=rep, fold=fold)
        for protocol in ("main", "strict"):
            r[protocol + "_reported_adv"] = ga[protocol + "_fit"] - rs[protocol + "_fit"]
            r[protocol + "_outer_adv"] = ga[protocol + "_outer_ba"] - rs[protocol + "_outer_ba"]
            r[protocol + "_delta_adv"] = r[protocol + "_reported_adv"] - r[protocol + "_outer_adv"]
            assert abs(r[protocol + "_delta_adv"] - (ga[protocol + "_gap_B"] - rs[protocol + "_gap_B"])) <= TOL
        r["change_delta_adv"] = r["strict_delta_adv"] - r["main_delta_adv"]
        assert abs(r["change_delta_adv"] - (ga["d_gap_B"] - rs["d_gap_B"])) <= TOL
        advantage_runs.append(r)
    adv_fields = ("main_reported_adv", "strict_reported_adv", "main_outer_adv", "strict_outer_adv",
                  "main_delta_adv", "strict_delta_adv", "change_delta_adv")
    advantage_datasets = []
    for ds, learner, cp in itertools.product(DS, LEARNERS, CP):
        values = [r for r in advantage_runs if (r["ds"], r["learner"], r["cp"]) == (ds, learner, cp)]
        assert len(values) == 25
        advantage_datasets.append(dict(ds=ds, learner=learner, cp=cp, n_run_pairs=len(values),
                                      **{field + "_pp": 100 * mean(v[field] for v in values) for field in adv_fields}))
    advantage_summary = []
    for learner, cp in itertools.product(LEARNERS, CP):
        values = [r for r in advantage_datasets if (r["learner"], r["cp"]) == (learner, cp)]
        assert len(values) == 3
        row = dict(learner=learner, cp=cp, n_datasets=3, n_run_pairs=sum(v["n_run_pairs"] for v in values))
        row.update({field + "_pp": mean(v[field + "_pp"] for v in values) for field in adv_fields})
        for field in ("main_delta_adv", "strict_delta_adv", "change_delta_adv"):
            row[field + "_dataset_min_pp"] = min(v[field + "_pp"] for v in values)
            row[field + "_dataset_max_pp"] = max(v[field + "_pp"] for v in values)
        advantage_summary.append(row)
    after = {relative: sha(root / relative) for relative in protected_paths}
    assert before == after
    # Hash every protected source as well as every raw paired record. This makes
    # the result independently reconstructible without importing project code.
    for relative in protected_paths:
        if relative not in inputs:
            path = safe(root / relative)
            inputs[relative] = {"bytes": path.stat().st_size, "sha256": before[relative]}
    outputs = {
        "paired_runs.csv": csv_blob(paired), "cell_means.csv": csv_blob(cells),
        "pooled_by_dataset.csv": csv_blob(pooled),
        "advantage_paired_runs.csv": csv_blob(advantage_runs),
        "advantage_by_dataset.csv": csv_blob(advantage_datasets),
        "advantage_summary.csv": csv_blob(advantage_summary),
    }
    checks = {
        "status": "passed", "new_experimental_jobs": 0, "new_classifier_fits": 0,
        "p_values_or_intervals_added": 0,
        "X1s_jobs_read": len(files), "corresponding_E1h_jobs_read": len(files),
        "unique_complete_checkpoint_pairs": len(records), "checkpoint_budgets": list(CP),
        "other_strict_budgets_available": False, "n_datasets": 3,
        "learners": list(LEARNERS), "algorithms": list(ALGOS),
        "outer_repeats_per_cell": 5, "outer_folds_per_repeat": 5,
        "outer_runs_per_cell": 25, "cell_summary_rows": len(cells),
        "GA_RS_run_pairs_per_learner_budget": 75,
        "GA_RS_summary_configurations": len(advantage_summary),
        "GA_RS_dataset_summary_rows": len(advantage_datasets),
        "existing_paired_csv_rows": len(existing),
        "existing_paired_numeric_fields_checked": len(existing) * len(field_map),
        "existing_paired_max_abs_difference_ba_fraction": max_paired_difference,
        "existing_cell_numeric_fields_checked": len(summary) * 3,
        "existing_cell_max_abs_difference_ba_fraction": max_summary_difference,
        "protected_result_tables_unchanged": len(result_tables),
        "protected_numeric_macros_unchanged": macro_count,
        "all_protected_inputs_unchanged": before == after,
        "human_sheet_and_blind_key_excluded_without_reading": True,
        "same_deterministic_split_and_seed_key_source_evidence": evidence,
        "fold_indices_or_predictions_are_not_saved_in_raw_JSON": True,
        "raw_result_fields": sorted(raw_fields),
        "saved_code_shas": {k: dict(v) for k, v in code_shas.items()},
        "main_budget_checkpoints_seen_but_not_strictly_retested": sorted(main_coverage - set(CP)),
        "pooling_rule": "Within a run paired difference, then dataset mean, then equal mean across the three datasets; no run-level inferential independence claim",
        "units": "Core paired/cell CSV values are BA fractions; advantage summary and per-dataset CSV fields ending _pp are percentage points",
        "pooled_dataset_equal_means": pooled_summary,
        "GA_RS_advantage_summary": advantage_summary,
        "protected_source_sha256_before": before, "protected_source_sha256_after": after,
        "limits": [
            "Three selected datasets, GA and ordinary RS, two fixed learners, five repeats by five folds, only 1000/4000 request checkpoints.",
            "Do not use these three-dataset changes to correct the full 13/11-dataset main result or its 6.05-point Ridge/GA estimate.",
            "No strict-scaling evidence at 250, 16000, 64000 or 256000 requests, and no strict-scaling X1 evidence for BPSO, BDE or NSGA-II.",
            "These compare complete rerun search procedures, including changed selected masks and GA trajectories; they do not isolate a fixed-mask causal preprocessing effect.",
            "Training-size and sampling differences between inner scores and outer tests remain in both protocols.",
            "Descriptive means and dataset ranges are not confidence intervals, equivalence tests or evidence that all datasets are unaffected.",
        ],
    }
    return inputs, outputs, checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--verify", action="store_true", help="Recompute and compare saved outputs without writing")
    args = parser.parse_args()
    root = args.root.resolve()
    assert HERE.resolve() == (ROOT / "submission/asc/qa/r20_x1_core").resolve()
    inputs, outputs, checks = analyze(root)
    script_sha = sha(Path(__file__).resolve())
    output_hashes = {name: {"bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}
                     for name, blob in outputs.items()}
    if args.verify:
        old_inputs = json.loads(safe(HERE / "input_sha256.json").read_text(encoding="utf-8"))
        assert old_inputs["files"] == inputs and old_inputs["script_sha256"] == script_sha
        for name, blob in outputs.items():
            assert safe(HERE / name).read_bytes() == blob, "Derived table mismatch: " + name
        old = json.loads(safe(HERE / "validation.json").read_text(encoding="utf-8"))
        assert old["checks"] == checks and old["outputs"] == output_hashes
        print(json.dumps({"status": "passed", "mode": "read-only verification",
                          "input_files": len(inputs), "derived_tables": len(outputs),
                          "new_experiments": 0, "new_p_values_or_intervals": 0}))
    else:
        now = datetime.now(timezone.utc).isoformat()
        for name, blob in outputs.items():
            safe(HERE / name).write_bytes(blob)
        (HERE / "input_sha256.json").write_text(json.dumps(
            {"created_utc": now, "client_date": "2026-10-12", "client_timezone": "America/Los_Angeles",
             "script": "submission/asc/qa/r20_x1_core/analyze_x1.py", "script_sha256": script_sha,
             "files": inputs}, indent=2) + "\n", encoding="utf-8")
        (HERE / "validation.json").write_text(json.dumps(
            {"created_utc": now, "client_date": "2026-10-12", "client_timezone": "America/Los_Angeles",
             "python": sys.version.split()[0], "standard_library_only": True,
             "script_sha256": script_sha, "checks": checks, "outputs": output_hashes},
            ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"status": "passed", "input_files": len(inputs),
                          "checkpoint_pairs": checks["unique_complete_checkpoint_pairs"],
                          "dataset_cells": checks["cell_summary_rows"],
                          "GA_RS_configurations": checks["GA_RS_summary_configurations"],
                          "new_experiments": 0, "new_p_values_or_intervals": 0,
                          "advantage_summary": checks["GA_RS_advantage_summary"]}))


if __name__ == "__main__":
    main()
