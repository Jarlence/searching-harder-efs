"""Independent descriptive X1 reconstruction; imports no project analysis or models."""
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone
from itertools import product
import csv
import hashlib
import json
import math
import re
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3].resolve()
DS, ALGO, LR, CP = ("colon", "prostate", "kc3"), ("ga", "rs"), ("ridge", "knn"), (1000, 4000)
BAN = re.compile(r"DO_NOT_OPEN|verification_(key|sheet)|human.*sheet", re.I)

def path(relative):
    assert not BAN.search(relative), "Forbidden file refused without opening"
    p = (ROOT / relative).resolve()
    p.relative_to(ROOT)
    return p

def sha(relative):
    return hashlib.sha256(path(relative).read_bytes()).hexdigest()

def csv_read(name):
    with (HERE / name).open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def avg(items):
    return statistics.mean(items)

manifest = json.loads((HERE / "input_sha256.json").read_text(encoding="utf-8"))
before = {}
for rel, entry in manifest["files"].items():
    p = path(rel)
    assert p.stat().st_size == entry["bytes"] and sha(rel) == entry["sha256"], rel
    before[rel] = entry["sha256"]
assert len(before) == 704
assert sha("submission/asc/qa/r20_x1_core/analyze_x1.py") == manifest["script_sha256"]
values, raw_files, selected_changes = {}, [], defaultdict(int)
for ds, algo, learner, rep, fold in product(DS, ALGO, LR, range(5), range(5)):
    xrel = "results/jobs_extra/X1s/X1s__%s__%s__%s__rep%d__fol%d.json" % (ds, algo, learner, rep, fold)
    mrel = "results/jobs/E1h/E1h__%s__%s__%s__rep%d__fol%d__metba.json" % (ds, algo, learner, rep, fold)
    x = json.loads(path(xrel).read_text(encoding="utf-8-sig"))
    m = json.loads(path(mrel).read_text(encoding="utf-8-sig"))
    raw_files.extend((xrel, mrel))
    assert x["status"] == m["status"] == "ok"
    assert x["spec"]["suite"] == "X1s" and m["spec"]["suite"] == "E1h"
    for k, expected in zip(("ds", "algo", "learner", "rep", "fold"), (ds, algo, learner, rep, fold)):
        assert x["spec"][k] == m["spec"][k] == expected
    assert x["spec"]["cps"] == [1000, 4000]
    assert not m["spec"].get("outer_group", False) and not m["spec"].get("inner_group", False)
    assert m["spec"].get("perm") is None and m["spec"].get("seed", 0) == 0
    assert m["spec"].get("metric", "ba") == "ba"
    for cp in CP:
        a, b = m["result"][str(cp)], x["result"][str(cp)]
        f0, f1, t0, t1 = 1-a["inner_err"], 1-b["inner_err"], a["test_ba"], b["test_ba"]
        assert all(math.isfinite(v) and 0 <= v <= 1 for v in (f0, f1, t0, t1))
        d = {"main_fit": f0, "strict_fit": f1, "main_outer_ba": t0, "strict_outer_ba": t1,
             "main_gap_B": f0-t0, "strict_gap_B": f1-t1,
             "d_fit": f1-f0, "d_outer_ba": t1-t0, "d_gap_B": (f1-t1)-(f0-t0),
             "d_auc": b["test_auc"]-a["test_auc"], "main_k": a["k"], "strict_k": b["k"],
             "d_k": b["k"]-a["k"]}
        assert abs(d["d_gap_B"] - (d["d_fit"]-d["d_outer_ba"])) < 1e-14
        values[(ds, algo, learner, rep, fold, cp)] = d
        selected_changes[(algo, learner)] += int(a["sel"] != b["sel"])
assert len(values) == 600 and len(set(raw_files)) == 600

checks = defaultdict(lambda: {"fields": 0, "max_abs_difference": 0.0})
def compare(name, actual, expected):
    for k, v in expected.items():
        difference = abs(float(actual[k]) - v)
        assert difference < 1e-12, (name, k, actual[k], v)
        checks[name]["fields"] += 1
        checks[name]["max_abs_difference"] = max(checks[name]["max_abs_difference"], difference)

rows = csv_read("paired_runs.csv")
assert len(rows) == 600
seen = set()
for r in rows:
    key = r["ds"], r["algo"], r["learner"], int(r["rep"]), int(r["fold"]), int(r["cp"])
    assert key not in seen
    seen.add(key)
    compare("paired_runs", r, values[key])
assert seen == set(values)
core = ("main_fit", "strict_fit", "main_outer_ba", "strict_outer_ba",
        "main_gap_B", "strict_gap_B", "d_fit", "d_outer_ba", "d_gap_B")
cells, pooled = {}, {}
for ds, learner, algo, cp in product(DS, LR, ALGO, CP):
    vv = [values[(ds, algo, learner, r, f, cp)] for r, f in product(range(5), range(5))]
    cells[(ds, learner, algo, cp)] = {k: avg(v[k] for v in vv) for k in core}
for r in csv_read("cell_means.csv"):
    assert int(r["n_pairs"]) == 25
    compare("cell_means", r, cells[(r["ds"], r["learner"], r["algo"], int(r["cp"]))])
for ds in DS:
    vv = [v for key, v in values.items() if key[0] == ds]
    assert len(vv) == 200
    pooled[ds] = {k: avg(v[k] for v in vv) for k in core}
for r in csv_read("pooled_by_dataset.csv"):
    assert int(r["n_run_checkpoint_pairs"]) == 200
    compare("pooled_by_dataset", r, pooled[r["ds"]])

adv = {}
for ds, learner, cp, rep, fold in product(DS, LR, CP, range(5), range(5)):
    a, b = values[(ds, "ga", learner, rep, fold, cp)], values[(ds, "rs", learner, rep, fold, cp)]
    v = {}
    for protocol in ("main", "strict"):
        f, t = a[protocol+"_fit"]-b[protocol+"_fit"], a[protocol+"_outer_ba"]-b[protocol+"_outer_ba"]
        v[protocol+"_reported_adv"], v[protocol+"_outer_adv"] = f, t
        v[protocol+"_delta_adv"] = f-t
        assert abs(f-t-(a[protocol+"_gap_B"]-b[protocol+"_gap_B"])) < 1e-14
    v["change_delta_adv"] = v["strict_delta_adv"]-v["main_delta_adv"]
    assert abs(v["change_delta_adv"]-(a["d_gap_B"]-b["d_gap_B"])) < 1e-14
    adv[(ds, learner, cp, rep, fold)] = v
adv_rows = csv_read("advantage_paired_runs.csv")
assert len(adv_rows) == 300
for r in adv_rows:
    compare("advantage_paired_runs", r, adv[(r["ds"], r["learner"], int(r["cp"]), int(r["rep"]), int(r["fold"]))])
fields = tuple(next(iter(adv.values())).keys())
ds_adv = {}
for ds, learner, cp in product(DS, LR, CP):
    vv = [adv[(ds, learner, cp, rep, fold)] for rep, fold in product(range(5), range(5))]
    ds_adv[(ds, learner, cp)] = {k+"_pp": 100*avg(v[k] for v in vv) for k in fields}
ds_rows = csv_read("advantage_by_dataset.csv")
assert len(ds_rows) == 12
for r in ds_rows:
    assert int(r["n_run_pairs"]) == 25
    compare("advantage_by_dataset", r, ds_adv[(r["ds"], r["learner"], int(r["cp"]))])
summary = []
for r in csv_read("advantage_summary.csv"):
    learner, cp = r["learner"], int(r["cp"])
    assert int(r["n_datasets"]) == 3 and int(r["n_run_pairs"]) == 75
    vv = [ds_adv[(ds, learner, cp)] for ds in DS]
    exp = {k+"_pp": avg(v[k+"_pp"] for v in vv) for k in fields}
    for k in ("main_delta_adv", "strict_delta_adv", "change_delta_adv"):
        exp[k+"_dataset_min_pp"] = min(v[k+"_pp"] for v in vv)
        exp[k+"_dataset_max_pp"] = max(v[k+"_pp"] for v in vv)
    compare("advantage_summary", r, exp)
    summary.append({"learner": learner, "requests": cp, **exp})
assert len(summary) == 4

old_paired = path("results/tables/X1s_paired.csv")
with old_paired.open(encoding="utf-8-sig", newline="") as f:
    original = list(csv.DictReader(f))
assert len(original) == 600
for r in original:
    key = r["ds"], r["algo"], r["learner"], int(r["rep"]), int(r["fold"]), int(r["cp"])
    d = values[key]
    compare("original_X1s_paired", r, {k: d[v] for k, v in
            (("d_ba","d_outer_ba"),("d_fit","d_fit"),("d_gapB","d_gap_B"),("d_auc","d_auc"),("d_k","d_k"))})
for rel, old_hash in before.items():
    assert sha(rel) == old_hash

report = {
    "status": "passed", "created_utc": datetime.now(timezone.utc).isoformat(),
    "client_date": "2026-10-12", "client_timezone": "America/Los_Angeles",
    "independent_script_sha256": sha("submission/asc/qa/r20_x1_core/independent_check.py"),
    "primary_script_reviewed_sha256": manifest["script_sha256"],
    "input_hashes_checked_before_and_after": len(before),
    "raw_files_read": len(raw_files), "run_checkpoint_pairs": len(values),
    "GA_RS_run_pairs": len(adv), "numeric_comparisons": dict(checks),
    "source_protocol_review": {
        "files": ["extras/ex_suites.py","experiments/suites.py","src/efsbench/protocols.py","src/efsbench/splits.py"],
        "finding": "X1/main use identical deterministic outer, inner and algorithm keys for the included E1h specifications. X1 refits scaling per inner training fold; both final outer-test fits use only outer-training scaling. JSON lacks fold indices/predictions, so this is source/spec evidence rather than an empirical saved-fold identity check.",
    },
    "pooled_equal_dataset_changes_pp": {k: 100*avg(pooled[ds][k] for ds in DS)
                                       for k in ("d_fit","d_outer_ba","d_gap_B")},
    "selected_mask_changes_out_of_150_checkpoints_per_algorithm_learner":
        {"%s/%s" % k: v for k,v in selected_changes.items()},
    "all_four_advantage_summaries_pp": summary,
    "negative_dataset_main_delta_adv": [{"ds":k[0],"learner":k[1],"requests":k[2],
                                         "value_pp":v["main_delta_adv_pp"]} for k,v in ds_adv.items()
                                        if v["main_delta_adv_pp"] < 0],
    "negative_dataset_inner_fold_delta_adv": [{"ds":k[0],"learner":k[1],"requests":k[2],
                                               "value_pp":v["strict_delta_adv_pp"]} for k,v in ds_adv.items()
                                              if v["strict_delta_adv_pp"] < 0],
    "conclusion": "Matched descriptive analysis is numerically correct. Near-zero pooled fitness change coexists with changes of either sign in relative GA-RS discrepancies and with heterogeneous data-set changes. The four pooled mean discrepancies remain positive in this subset, but data-set discrepancies are not uniformly positive.",
    "limits": [
        "Only three selected data sets, GA/ordinary RS, two fixed learners and 1000/4000 request checkpoints.",
        "Same 25 outer keys per cell, not the full main repeats; equal data-set averaging.",
        "Ranges are descriptive. No new confidence intervals, p-values, practical-equivalence thresholds or inference from 75 runs as independent evidence.",
        "Changes can alter selected masks and search trajectories; not fixed-mask leakage attribution and not removal of sampling/training-size effects.",
        "Cannot replace/correct the full 13/11-data-set 6.05-point contrast or prove the full budget curve robust.",
        "No new experiment, classifier fit, project-loader import, blind-key/human-sheet reading or protected-file change.",
    ],
}
(HERE / "independent_review.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
lines = ["# Independent X1 core check", "", "Status: passed. No experiments, model fitting or inferential statistics.", "",
         "All 600 raw main/X1 run-checkpoint pairs, 300 GA-RS pairs, six derived CSVs and 704 input hashes were independently checked.",
         "Main comparators use the same 25 outer keys. F, T, B and Delta_adv identities and data-set-equal averaging agree.", "",
         "Pooled strict-minus-main changes (percentage points): " + str(report["pooled_equal_dataset_changes_pp"]), "",
         "Relative-discrepancy changes are not uniformly in one direction; negative data-set discrepancies are retained in the JSON/CSV.",
         "Source/spec evidence supports common fold/RNG keys, but saved JSON has no fold indices or predictions.",
         "The result cannot establish full-scope robustness, practical equivalence, pure search bias or fixed-mask causal preprocessing effects."]
(HERE / "independent_review.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
print(json.dumps({"status":"passed","raw_files":600,"input_hashes":704,"checks":dict(checks),
                  "pooled_changes_pp":report["pooled_equal_dataset_changes_pp"]}))
