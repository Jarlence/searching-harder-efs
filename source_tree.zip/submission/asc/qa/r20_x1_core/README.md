# X1 core sensitivity from saved records

This is a descriptive re-summary of existing results, not a new experiment.
Source records are read-only. Default invocation writes only derived files in
this QA directory; the verification option writes nothing.

Run from the project root with Python 3.8 or later:

    & 'D:/Anaconda/envs/evolve/python.exe' submission/asc/qa/r20_x1_core/analyze_x1.py
    & 'D:/Anaconda/envs/evolve/python.exe' submission/asc/qa/r20_x1_core/analyze_x1.py --verify

The script uses the Python standard library only. It imports no project
analysis loaders, writes no cache, and performs no search, classifier fitting,
p-value calculation, confidence interval, equivalence test or bootstrap.
The --root option can identify a different checkout or extracted reproduction
bundle containing the same results, paper, extras, experiments and src paths.

## Coverage and pairing

X1 includes colon, prostate and kc3; GA and ordinary request-budget RS; ridge
and 5-NN; five repeats with five outer folds; and checkpoints of 1,000 and
4,000 requests. There are 300 stored X1 jobs, 300 corresponding main E1h jobs,
and 600 uniquely paired run-checkpoint records.

The key is (ds, algo, learner, rep, fold, cp). Every expected key is present
exactly once. The main comparator uses the same 25 outer keys per cell, rather
than all main-experiment repeats. Source excerpts identify identical outer
split, inner-fold and algorithm RNG keys; raw JSON does not save fold indices
or predictions. Both protocols fit outer-test preprocessing on outer training
data only. X1 re-fits scaling separately in each inner training fold before
scoring inner validation rows.

The CSV fields called strict_* mean inner-fold scaling in X1. They do not mean
strict distinct-candidate budgeting. This comparison uses request budgets and
the ordinary RS size distribution.

## Definitions and aggregation

F = 1 - inner_err; T = test_ba; B = F - T. Every d_* field is X1 inner-fold
scaling minus the main shared-scaling procedure, within a matched run.

For the GA-RS comparison:

    delta_adv = (F_GA - F_RS) - (T_GA - T_RS) = B_GA - B_RS
    change_delta_adv = delta_adv_X1 - delta_adv_main = d_B_GA - d_B_RS

The script first forms each difference within a run, then averages within a
data set, then gives the three data sets equal weight. Each learner-budget
configuration has 75 GA-RS run pairs, but only three data sets. Run pairs are
not treated as independent data sets for inference. No inferential statistics
are reported. Data-set ranges are descriptive ranges, not confidence intervals.

Across all covered cells, the equal-data-set mean changes are fitness
−0.01113 percentage points, outer BA +0.39729 points, and B −0.40842 points.
The GA-RS relative gap need not move in the same direction:

| Learner | Requests | Main delta_adv | Inner-fold-scaling delta_adv | Change | Range of three data-set changes |
|---|---:|---:|---:|---:|---:|
| Ridge | 1,000 | 4.5208 | 4.2028 | −0.3179 | −2.9764 to +1.3013 |
| Ridge | 4,000 | 2.2173 | 3.4222 | +1.2049 | +0.6375 to +1.7518 |
| 5-NN | 1,000 | 3.5472 | 4.1666 | +0.6194 | −1.0528 to +1.6471 |
| 5-NN | 4,000 | 3.1502 | 2.3741 | −0.7761 | −1.3136 to −0.1223 |

All values in this table are percentage points. Apparent stability of pooled
fitness does not make the comparative gap invariant.

## Files and verification

- paired_runs.csv: all 600 main/X1 run-checkpoint pairs, including F, T, B,
  their changes, AUC change and feature counts.
- cell_means.csv: all 24 data-set/learner/algorithm/budget cells, 25 pairs each.
- pooled_by_dataset.csv: three data-set means across the balanced covered
  learner, algorithm and checkpoint cells.
- advantage_paired_runs.csv: all 300 GA-RS comparisons, formed within the
  same data set, learner, repetition, fold and checkpoint.
- advantage_by_dataset.csv: all 12 data-set/learner/budget comparisons.
- advantage_summary.csv: all four learner/budget comparisons with equal
  data-set means and ranges.
- input_sha256.json: SHA-256 and byte counts of every raw or protected
  input, plus the analysis script hash.
- validation.json: complete-key checks, source evidence, agreement with the
  original X1 CSVs, preservation checks, output hashes and descriptive results.

Paired/cell/core CSV scores use BA fractions. Advantage summary and data-set
CSV fields ending in _pp use percentage points. The original
results/tables/X1s_paired.csv already contains changes in F, T and B, and
X1s_summary.csv already contains their cell means. Raw-record verification
of those saved fields has maximum absolute difference zero. The 61 original
result tables, all 1,069 original numerical macros and the existing generated
and random-control QA sources are checked unchanged before and after this
analysis. No original table, macro, paper source or frozen result is written.
The human verification sheet and blind key are excluded without reading.

## Limits

This three-data-set result cannot correct or replace the full 13/11-data-set
main comparison, including its 6.05-point ridge/GA estimate. X1 has no stored
strict inner-scaling checkpoints at 250, 16,000, 64,000 or 256,000 requests,
and does not include BPSO, BDE or NSGA-II. It cannot establish that the entire
budget curve or all data sets and algorithms are unaffected.

These compare complete search procedures. Re-fitting scaling can change the
selected masks and GA trajectory. The contrast is not a same-mask causal
decomposition of preprocessing leakage, and it does not remove inner/outer
training-size or sampling differences. Descriptive changes, including their
heterogeneity and reverse directions, must not be recast as proof of
equivalence or as pure search-induced bias.

New records use the client date and time zone specified for this revision
(2026-10-12, America/Los_Angeles); creation timestamps remain real UTC.
