# Stored-result comparison of random-search controls

This directory contains an exploratory re-summary of saved scores. It does not
run searches or fit classifiers. The current manuscript, its existing result
tables, its 1,069 generated number macros, and its frozen experiment records are
not changed by this script.

Reproduce with the locked scientific environment:

```powershell
& 'D:/Anaconda/envs/evolve/python.exe' 'D:/Python_project/t1/submission/asc/qa/r18_rs_advantage/validate_rs_advantage.py'
```

The script asserts Python 3.8, NumPy 1.24.4, and SciPy 1.10.1. It imports no
project analysis loader and writes only into this directory.

The complete set was fixed before estimating results: at each of 1,000 and
4,000 targets, four algorithms with two learners against ordinary RS,
same-size RS, and RS100, plus GA and NSGA-II with two learners against RS
at equal distinct-mask targets. This gives 56 main configurations. All are
retained. An additional 16 ordinary-RS configurations use exactly the RS100
intersection to separate changes of comparator from changes of run coverage.

For each matched data set, learner, repeat, outer fold, and target, the script
computes reported advantage `F_algo - F_RS`, outer advantage `T_algo - T_RS`,
and their difference `Delta_adv = (F_algo-F_RS) - (T_algo-T_RS)`. Here `F` is
the stored balanced accuracy `1-inner_err`, and `T` is `test_ba`. These are
scores of the selected incumbent; `F` is not the size-penalized search objective.
The same-size CSV stores the equivalent fields directly as `rsk_fit` and
`rsk_ba`, and its stored feature count is checked against each original
incumbent. Paired differences are averaged within each data set and then
equally across data sets. Each reported interval is an unadjusted 95%
Student-t interval across the 13 Ridge or 11 5-NN data-set means, with
`df = n_ds - 1`. Repeated folds are not treated as independent inferential
units. CSV scores and interval endpoints are BA percentage points.

Input scores come from 5,350 E1h JSON jobs, 600 X5s/RS100 JSON jobs, 2,140
X6d/distinct-algorithm JSON jobs, 1,070 X6r/distinct-RS JSON jobs, and
`results/tables/X5m_runs.csv`. The reference table for reconstruction is
`results/tables/Q5b_advantage_inflation.csv`. All 9,162 input files and
the script have SHA-256 hashes in `input_sha256.json`.

Ordinary, same-size, and strict-distinct comparisons use 580 Ridge and 490
5-NN paired outer runs per algorithm and target. RS100 has only 320 Ridge
and 265 5-NN matching runs. Its 15 stored extra jobs without an original
E1h match are listed individually in `validation.json` and are excluded:
five Speech/Ridge folds in repeat 4 and ten Oil-spill/5-NN folds in repeats
3 and 4. No replacement experiment is generated. The additional
`ordinary_rs100_subset` rows use the same 585 outer keys as RS100.
Each data set's exact paired-run count is recorded in the data-set CSVs
and in the validation report.

For strict-distinct comparisons, both saved candidates must have
`reached=true` and `distinct` exactly equal to the same target.
Their request counts can differ, and their means are included in the
data-set output. This is a distinct-mask-budget comparison; it is not
the same estimand as 4,000 wrapper requests.

Outputs:

- `advantage_summary.csv`: all 56 main configurations, with the mean and
  interval for reported advantage, outer advantage, and advantage inflation.
- `advantage_by_dataset.csv`: their 672 data-set records, including pair
  counts and mean request counts.
- `ordinary_rs100_subset_summary.csv`: 16 coverage-matched ordinary-RS
  configurations with the same three estimates and intervals.
- `ordinary_rs100_subset_by_dataset.csv`: their 192 data-set records.
- `rs100_coverage_comparison_by_dataset.csv`: 192 data-set comparisons
  between RS100 and ordinary RS on identical run coverage; these are
  differences of estimates, with no additional tests or intervals.
- `validation.json`: score and key checks, complete coverage information,
  excluded jobs, software versions, original output hashes, and limitations.
- `input_sha256.json`: every input hash and the script hash.

The eight ordinary-RS configurations at 4,000 requests reconstruct all
72 means and interval endpoints from the existing table. The largest
absolute difference is `2.7755575615628914e-17` in BA fractions, attributable
to floating-point aggregation order; 34 of 72 fields match as binary floats.
The before/after SHA-256 hashes of all 61 original result-table files,
`paper/generated/numbers.tex`, and `docs/FREEZE_rev2.json` are identical.

These post-hoc results do not provide confirmatory multiple-comparison
evidence. No p-values, bootstrap rank checks, equivalence tests, or
operator-effect estimates are computed. In particular, same-size RS
conditions on an incumbent size selected by the compared algorithm.
RS100 changes size support and has fewer matching outer runs, so its
direct coverage-consistent reference is `ordinary_rs100_subset`.
An interval containing zero does not establish equivalence, and an
interval excluding zero does not settle a field-wide algorithm ranking.
The saved searches and classifiers have not been rerun.
