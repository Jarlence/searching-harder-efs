"""Independent raw-record audit; no import of the primary QA analysis."""
from pathlib import Path
from collections import defaultdict, Counter
from statistics import mean, stdev
from scipy.stats import t
import csv
import hashlib
import json
import math
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
ALGOS = ("ga", "bpso", "bde", "nsga2")
CPS = (1000, 4000)
TOL = 1e-10  # percentage points


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_raw(suite):
    folder = ROOT / "results" / ("jobs" if suite == "E1h" else "jobs_extra") / suite
    records = {}
    aggregate = hashlib.sha256()
    paths = sorted(folder.glob("*.json"))
    for path in paths:
        payload = path.read_bytes()
        file_sha = hashlib.sha256(payload).hexdigest()
        rel = path.relative_to(ROOT).as_posix()
        aggregate.update((rel + "\0" + file_sha + "\0").encode("utf-8"))
        obj = json.loads(payload)
        s = obj["spec"]
        assert obj["status"] == "ok" and s["suite"] == suite, rel
        if suite == "E1h":
            assert s["metric"] == "ba" and s.get("perm") is None, rel
            assert not s.get("outer_group", False) and not s.get("inner_group", False), rel
        checkpoints = (int(s["budget"]),) if suite == "X5m" else CPS
        for cp in checkpoints:
            r = obj["result"][str(cp)]
            key = (s["ds"], s["learner"], int(s["rep"]), int(s["fold"]), cp, s["algo"])
            assert key not in records, key
            assert all(math.isfinite(r[k]) and 0 <= r[k] <= 1 for k in ("inner_err", "test_ba"))
            if suite in ("X6d", "X6r"):
                assert r["reached"] is True and r["distinct"] == cp and r["calls"] >= cp, key
            if suite == "X5m":
                assert cp == int(s["budget"]) and int(r["k"]) == int(s["k"]), key
            records[key] = {
                "fitness": 1.0 - r["inner_err"], "outer": r["test_ba"],
                "k": int(r["k"]), "source": rel,
                "calls": int(r["calls"]) if suite in ("X6d", "X6r") else cp,
            }
    return records, {
        "job_files": len(paths), "used_checkpoint_records": len(records),
        "path_sha256_aggregate": aggregate.hexdigest(),
        "aggregate_recipe": "sorted relative path + NUL + SHA256 bytes digest + NUL",
    }


def replacement(key, algo):
    return key[:-1] + (algo,)


def summary(algorithm, comparator, learner, algo, cp, control, subset=None):
    diffs = defaultdict(list)
    used = set()
    for key in sorted(algorithm):
        if key[1] != learner or key[4] != cp or key[5] != algo:
            continue
        base_key = key if control == "same_size" else replacement(
            key, "rs100" if control == "rs100" else "rs"
        )
        if subset is not None and replacement(key, "rs100") not in subset:
            continue
        if base_key not in comparator:
            if control == "rs100":
                continue
            raise AssertionError(("Missing comparator", key))
        a, b = algorithm[key], comparator[base_key]
        if control == "same_size":
            assert a["k"] == b["k"], key
        fit_diff = a["fitness"] - b["fitness"]
        outer_diff = a["outer"] - b["outer"]
        delta = fit_diff - outer_diff
        assert abs(delta - ((a["fitness"] - a["outer"]) - (b["fitness"] - b["outer"]))) < 1e-14
        diffs[key[0]].append((fit_diff, outer_diff, delta))
        used.add(key)
    expected_n = 13 if learner == "ridge" else 11
    assert len(diffs) == expected_n, (control, learner, algo, cp, len(diffs))
    ds_means = {
        ds: tuple(mean(row[i] for row in values) for i in range(3))
        for ds, values in sorted(diffs.items())
    }
    result = {
        "control": control, "budget": cp, "learner": learner, "algo": algo,
        "n_ds": len(diffs), "n_pairs": len(used),
    }
    for i, name in enumerate(("rep", "outer", "infl")):
        values = [row[i] for row in ds_means.values()]
        centre = mean(values)
        half = float(t.ppf(0.975, len(values) - 1)) * stdev(values) / math.sqrt(len(values))
        result["mean_" + name] = 100 * centre
        result[name + "_lo"] = 100 * (centre - half)
        result[name + "_hi"] = 100 * (centre + half)
    result["pairs_per_dataset"] = {ds: len(values) for ds, values in sorted(diffs.items())}
    result["dataset_means_percentage_points"] = {
        ds: [100 * v for v in values] for ds, values in ds_means.items()
    }
    return result


def classify(row):
    if row["infl_lo"] > 0:
        return "interval_above_zero"
    if row["infl_hi"] < 0:
        return "interval_below_zero"
    return "interval_contains_zero"


def main():
    required = ("advantage_summary.csv", "validation.json")
    assert all((HERE / name).is_file() for name in required), "Primary QA results must exist first"
    before = {
        p.relative_to(ROOT).as_posix(): digest(p)
        for p in sorted((ROOT / "results/tables").glob("*")) if p.is_file()
    }
    before["paper/generated/numbers.tex"] = digest(ROOT / "paper/generated/numbers.tex")
    before["docs/FREEZE_rev2.json"] = digest(ROOT / "docs/FREEZE_rev2.json")
    suites, sources = {}, {}
    for suite in ("E1h", "X5m", "X5s", "X6d", "X6r"):
        suites[suite], sources[suite] = load_raw(suite)
    e, size, r100, d, dr = (suites[k] for k in ("E1h", "X5m", "X5s", "X6d", "X6r"))
    assert sources["E1h"]["job_files"] == 5350
    assert sources["X5m"]["job_files"] == 8560
    assert sources["X5s"]["job_files"] == 600
    assert sources["X6d"]["job_files"] == 2140
    assert sources["X6r"]["job_files"] == 1070
    assert all(key in e and e[key]["k"] == row["k"] for key, row in size.items())
    csv_rows = list(csv.DictReader((ROOT / "results/tables/X5m_runs.csv").read_text(
        encoding="utf-8-sig").splitlines()))
    assert len(csv_rows) == len(size) == 8560
    csv_fitness_max_error = 0.0
    csv_outer_max_error = 0.0
    for row in csv_rows:
        key = (row["ds"], row["learner"], int(row["rep"]), int(row["fold"]),
               int(row["budget"]), row["ref"])
        raw = size[key]
        csv_fitness_max_error = max(csv_fitness_max_error, abs(raw["fitness"] - float(row["rsk_fit"])))
        csv_outer_max_error = max(csv_outer_max_error, abs(raw["outer"] - float(row["rsk_ba"])))
        assert raw["k"] == int(row["k"])
    assert csv_fitness_max_error < 1e-14 and csv_outer_max_error < 1e-14
    unmatched = sorted(key for key in r100 if replacement(key, "rs") not in e)
    unmatched_jobs = sorted(set((key[0], key[1], key[2], key[3]) for key in unmatched))
    assert len(unmatched_jobs) == 15
    intersection_jobs = sorted(set((key[0], key[1], key[2], key[3])
                                  for key in r100 if replacement(key, "rs") in e))
    assert len(intersection_jobs) == 585

    estimates = []
    subset_estimates = []
    for control in ("ordinary", "same_size", "rs100", "strict_distinct"):
        algorithms = d if control == "strict_distinct" else e
        comparators = {"ordinary": e, "same_size": size, "rs100": r100, "strict_distinct": dr}[control]
        algos = ("ga", "nsga2") if control == "strict_distinct" else ALGOS
        for cp in CPS:
            for learner in ("ridge", "knn"):
                for algo in algos:
                    estimates.append(summary(algorithms, comparators, learner, algo, cp, control))
    for cp in CPS:
        for learner in ("ridge", "knn"):
            for algo in ALGOS:
                row = summary(e, e, learner, algo, cp, "ordinary", subset=r100)
                row["control"] = "ordinary_rs100_subset"
                subset_estimates.append(row)
    assert len(estimates) == 56 and len(subset_estimates) == 16

    published = list(csv.DictReader((ROOT / "results/tables/Q5b_advantage_inflation.csv").read_text(
        encoding="utf-8-sig").splitlines()))
    published = {(int(r["cp"]), r["learner"], r["algo"]): r for r in published}
    table8_errors = []
    for row in estimates:
        if row["control"] == "ordinary" and row["budget"] == 4000:
            old = published[(4000, row["learner"], row["algo"])]
            for new, original in (
                ("mean_rep", "rep"), ("rep_lo", "rep_lo"), ("rep_hi", "rep_hi"),
                ("mean_outer", "true"), ("outer_lo", "true_lo"), ("outer_hi", "true_hi"),
                ("mean_infl", "infl"), ("infl_lo", "infl_lo"), ("infl_hi", "infl_hi"),
            ):
                table8_errors.append(abs(row[new] - 100 * float(old[original])))
    assert len(table8_errors) == 72 and max(table8_errors) < TOL

    primary = list(csv.DictReader((HERE / "advantage_summary.csv").read_text(encoding="utf-8").splitlines()))
    primary = {(r["control"], int(r["budget"]), r["learner"], r["algo"]): r for r in primary}
    primary_errors = []
    for row in estimates:
        other = primary[(row["control"], row["budget"], row["learner"], row["algo"])]
        assert row["n_ds"] == int(other["n_ds"]) and row["n_pairs"] == int(other["n_pairs"])
        for name in ("mean_rep", "rep_lo", "rep_hi", "mean_outer", "outer_lo", "outer_hi",
                     "mean_infl", "infl_lo", "infl_hi"):
            primary_errors.append(abs(row[name] - float(other[name])))
    assert len(primary_errors) == 504 and max(primary_errors) < TOL
    primary_subset = list(csv.DictReader(
        (HERE / "ordinary_rs100_subset_summary.csv").read_text(encoding="utf-8").splitlines()))
    primary_subset = {
        (int(r["budget"]), r["learner"], r["algo"]): r for r in primary_subset
    }
    subset_errors = []
    for row in subset_estimates:
        other = primary_subset[(row["budget"], row["learner"], row["algo"])]
        assert row["n_ds"] == int(other["n_ds"]) and row["n_pairs"] == int(other["n_pairs"])
        for name in ("mean_rep", "rep_lo", "rep_hi", "mean_outer", "outer_lo", "outer_hi",
                     "mean_infl", "infl_lo", "infl_hi"):
            subset_errors.append(abs(row[name] - float(other[name])))
    assert len(subset_errors) == 144 and max(subset_errors) < TOL

    dataset_errors = []
    dataset_rows_verified = 0
    for filename, rows in (
        ("advantage_by_dataset.csv", estimates),
        ("ordinary_rs100_subset_by_dataset.csv", subset_estimates),
    ):
        other_rows = list(csv.DictReader((HERE / filename).read_text(encoding="utf-8").splitlines()))
        other_rows = {
            (r["control"], int(r["budget"]), r["learner"], r["algo"], r["ds"]): r
            for r in other_rows
        }
        for row in rows:
            for ds, means in row["dataset_means_percentage_points"].items():
                other = other_rows[(row["control"], row["budget"], row["learner"], row["algo"], ds)]
                assert int(other["n_pairs"]) == row["pairs_per_dataset"][ds]
                for index, label in enumerate(("rep", "outer", "infl")):
                    dataset_errors.append(abs(means[index] - float(other["mean_" + label])))
                dataset_rows_verified += 1
    assert dataset_rows_verified == 864
    assert len(dataset_errors) == 2592 and max(dataset_errors) < TOL

    classifications = {}
    for control in ("ordinary", "same_size", "rs100", "strict_distinct", "ordinary_rs100_subset"):
        for cp in CPS:
            group = [r for r in estimates + subset_estimates
                     if r["control"] == control and r["budget"] == cp]
            classifications[control + "_" + str(cp)] = {
                "counts": dict(Counter(classify(r) for r in group)),
                "all_rows": [{
                    "learner": r["learner"], "algo": r["algo"],
                    "mean_infl": r["mean_infl"], "infl_lo": r["infl_lo"], "infl_hi": r["infl_hi"],
                    "classification": classify(r),
                } for r in group],
            }
    assert all(digest(ROOT / rel) == old for rel, old in before.items())
    def get_row(control, learner, algo, cp=4000):
        return next(row for row in estimates + subset_estimates if (
            row["control"], row["learner"], row["algo"], row["budget"]
        ) == (control, learner, algo, cp))

    ordinary_ga = get_row("ordinary", "ridge", "ga")
    size_ga = get_row("same_size", "ridge", "ga")
    distinct_ga = get_row("strict_distinct", "ridge", "ga")
    rs100_ga = get_row("rs100", "ridge", "ga")
    subset_ga = get_row("ordinary_rs100_subset", "ridge", "ga")
    negative_points = [
        {key: row[key] for key in (
            "control", "budget", "learner", "algo", "mean_infl", "infl_lo", "infl_hi"
        )}
        for row in estimates + subset_estimates if row["mean_infl"] < 0
    ]
    matched_baseline_shifts = []
    for cp in CPS:
        for learner in ("ridge", "knn"):
            deltas = [
                get_row("rs100", learner, algo, cp)["mean_infl"]
                - get_row("ordinary_rs100_subset", learner, algo, cp)["mean_infl"]
                for algo in ALGOS
            ]
            # On identical runs the algorithm cancels, leaving only a baseline shift.
            assert max(deltas) - min(deltas) < TOL
            matched_baseline_shifts.append({
                "budget": cp, "learner": learner,
                "rs100_minus_matched_ordinary_delta_adv_pp": mean(deltas),
                "maximum_algorithm_spread_pp": max(deltas) - min(deltas),
                "interpretation": "Descriptive point shift on identical outer keys; no causal or significance claim",
            })
    report = {
        "status": "passed", "independent_script": "independent_check.py",
        "independent_script_sha256": digest(Path(__file__)),
        "runtime": {"python": sys.version, "executable": sys.executable},
        "method": {
            "raw_scores": "fitness=1-inner_err and outer=test_ba from original JSON, including all X5m jobs",
            "paired_delta": "(F_algorithm-F_comparator)-(T_algorithm-T_comparator)",
            "pair_key": ["dataset", "learner", "repeat", "fold", "request checkpoint or exact distinct target"],
            "unit": "Dataset-level mean paired difference; 13 ridge / 11 5-NN datasets; equal dataset weights",
            "CI": "Exploratory unadjusted 95% Student-t interval, df=N_datasets-1; no p-values or fitting",
            "independence": "This script imports no primary QA analysis or project loader",
        },
        "source_suites": sources,
        "same_size_raw_csv_check": {
            "records_verified": 8560, "all_incumbent_sizes_match": True,
            "max_fitness_error_BA_fraction": csv_fitness_max_error,
            "max_outer_error_BA_fraction": csv_outer_max_error,
        },
        "source_protocol_review": {
            "reviewed_source_sha256": {
                rel: digest(ROOT / rel) for rel in (
                    "experiments/suites.py", "extras/ex_suites.py", "extras/ex_suites2.py",
                    "extras/ex_suites3.py", "extras/ex_suites5.py",
                    "src/efsbench/protocols.py", "src/efsbench/tracking.py",
                    "src/efsbench/wrapper.py",
                )
            },
            "same_outer_split_rule": "Both main suites.outer_split and extras.ex_suites.outer_split use make_folds(y,5,rng_for('outer',ds,rep))[fold].",
            "same_size_inner_fold_key": "X5m k_rsk passes ('inner',ds,learner,rep,fold,None,False,False), identical to unpermuted, ungrouped E1h.",
            "fitness_definition": "Wrapper error is one minus BA of pooled inner out-of-fold predictions; saved 1-inner_err is the incumbent's internal BA.",
            "same_size_sampling": "X5m chooses all random masks at E1h incumbent k in the matched run; it controls final feature count conditionally.",
            "strict_stopping": "X6d and X6r use distinct-mask stopping, require reached=True and distinct exactly 1,000/4,000; saved calls may exceed target.",
            "preprocessing_limit": "All these controls share the original outer-training-fitted scaler across inner folds. No outer-test features enter its fitting, but inner validation features participate in common scaling. This review does not substitute for X1 or prove fold-local preprocessing equivalence.",
        },
        "rs100_coverage": {
            "source_jobs": 600, "matched_original_outer_run_jobs": 585,
            "excluded_jobs": [{"ds": k[0], "learner": k[1], "rep": k[2], "fold": k[3]}
                              for k in unmatched_jobs],
            "checkpoints_excluded": len(unmatched),
        },
        "all_56_estimates": estimates,
        "ordinary_rs100_subset_16_estimates": subset_estimates,
        "all_interval_directions": classifications,
        "ordinary_4000_Table8_check": {
            "numeric_fields": len(table8_errors), "max_abs_error_percentage_points": max(table8_errors),
        },
        "primary_QA_check": {
            "numeric_fields": len(primary_errors), "max_abs_error_percentage_points": max(primary_errors),
            "summary_sha256": digest(HERE / "advantage_summary.csv"),
            "validation_sha256": digest(HERE / "validation.json"),
        },
        "primary_ordinary_subset_QA_check": {
            "numeric_fields": len(subset_errors), "max_abs_error_percentage_points": max(subset_errors),
            "summary_sha256": digest(HERE / "ordinary_rs100_subset_summary.csv"),
        },
        "primary_dataset_QA_check": {
            "rows": dataset_rows_verified, "numeric_fields": len(dataset_errors),
            "max_abs_error_percentage_points": max(dataset_errors),
            "primary_dataset_csv_sha256": digest(HERE / "advantage_by_dataset.csv"),
            "ordinary_subset_dataset_csv_sha256": digest(HERE / "ordinary_rs100_subset_by_dataset.csv"),
        },
        "all_63_protected_files_unchanged": True,
        "protected_sha256": before,
        "interpretation_checks": {
            "negative_point_estimates_retained": negative_points,
            "matched_baseline_shifts": matched_baseline_shifts,
            "ga_ridge_4000_control_effect": {
                "ordinary_outer_advantage_pp": ordinary_ga["mean_outer"],
                "same_size_outer_advantage_pp": size_ga["mean_outer"],
                "ordinary_delta_adv_pp": ordinary_ga["mean_infl"],
                "same_size_delta_adv_pp": size_ga["mean_infl"],
                "meaning": "Matching feature count shrinks this outer advantage but increases the internal-minus-outer advantage gap; these are different quantities.",
            },
            "ga_ridge_strict_distinct_4000": {
                key: distinct_ga[key] for key in ("mean_infl", "infl_lo", "infl_hi")
            },
            "ga_ridge_rs100_4000_coverage": {
                "rs100_delta_adv_pp": rs100_ga["mean_infl"],
                "identical_run_ordinary_delta_adv_pp": subset_ga["mean_infl"],
                "full_run_ordinary_delta_adv_pp": ordinary_ga["mean_infl"],
                "meaning": "The RS100-minus-full-ordinary difference cannot be assigned solely to subset-size support because outer-run coverage also changes.",
            },
            "budget_monotonicity_counterexample": {
                "ordinary_ga_ridge_1000_delta_adv_pp": get_row("ordinary", "ridge", "ga", 1000)["mean_infl"],
                "ordinary_ga_ridge_4000_delta_adv_pp": ordinary_ga["mean_infl"],
                "meaning": "The comparative inflation contrast need not grow with search budget; the paper's budget fitness-versus-outer result does not imply that stronger claim.",
            },
        },
        "limits": [
            "Post-hoc existing-results analysis; all contrasts retained; unadjusted intervals are not a confirmatory discovery count.",
            "Benchmark datasets are a fixed, mainly biomedical convenience set, not a probability sample of all EFS tasks.",
            "Dataset averaging avoids treating repeated folds as independent evidence, but 13/11 datasets still give limited precision.",
            "Same-size RS uses the compared algorithm's selected size; it constrains interpretation without identifying operator causality.",
            "Strict-distinct controls unique evaluated masks, not equal requests, and changes the stopping rule for both methods.",
            "RS100 intersects only 585 original outer runs; its direct comparison with ordinary full-run estimates mixes run coverage and comparator.",
            "No equivalence, practical-value absence, ranking stability, universal algorithm superiority, or leakage prevalence follows.",
        ],
    }
    (HERE / "independent_review.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                                                encoding="utf-8")
    lines = [
        "# Independent review of stored-result random-search contrasts", "",
        "Status: passed. Independently read all five source suites; no original statistics, jobs, macros, or manuscript files were modified.", "",
        "Pairing uses the same dataset, learner, repetition, outer fold and request checkpoint (or exact distinct target). Fitness is 1-inner_err; outer score is test_ba. Each paired difference is averaged within dataset before equal weighting and Student-t intervals across 13 ridge or 11 5-NN datasets.", "",
        "All 8,560 same-size CSV rows were checked against raw X5m JSON and the corresponding E1h incumbent size. The ordinary 4,000-request estimates reproduce all 72 Table 8 numerical fields. All 504 fields of the primary QA's 56 contrasts, 144 fields of its 16 coverage-matched supporting contrasts, and 2,592 dataset-level numeric fields agree within the stated floating-point tolerance.", "",
        "RS100 contains 600 jobs; only 585 overlap original outer-run keys. The omitted keys are speech/ridge repetition 4 (five folds) and oil_spill/5-NN repetitions 3 and 4 (ten folds). Therefore the independent report also records 16 ordinary-RS contrasts restricted to the identical RS100 run subset.", "",
        "| Control | Target | Intervals above zero | Intervals containing zero | Intervals below zero |",
        "|---|---:|---:|---:|---:|",
    ]
    for label, details in classifications.items():
        control, cp = label.rsplit("_", 1)
        counts = details["counts"]
        lines.append("| %s | %s | %s | %s | %s |" % (
            control, cp, counts.get("interval_above_zero", 0),
            counts.get("interval_contains_zero", 0), counts.get("interval_below_zero", 0)))
    lines += ["", "All interval directions and estimates, including opposite directions and intervals spanning zero, are preserved in independent_review.json.", "",
              "The positive contrast quantifies a larger algorithm-minus-RS advantage under internal fitness than under outer BA. It does not establish superiority of RS, causality of evolutionary operators, stability of ranking, equivalence, or a universal effect. This is an exploratory re-summary of stored experiments, with unadjusted intervals and a fixed benchmark set.", ""]
    lines += [
        "## Numerical interpretation", "",
        "GA/ridge at 4,000 requests has ordinary outer advantage %.2f points and same-size outer advantage %.2f points, while its comparative inflation is %.2f and %.2f points respectively. Thus size matching can reduce the true advantage without reducing the inflation contrast; these outcomes must not be conflated." % (
            ordinary_ga["mean_outer"], size_ga["mean_outer"], ordinary_ga["mean_infl"], size_ga["mean_infl"]), "",
        "At 4,000 exact distinct masks the GA/ridge inflation contrast remains %.2f [%.2f, %.2f] points. This supports robustness to this budget definition for the studied setting, without proving general operator effects." % (
            distinct_ga["mean_infl"], distinct_ga["infl_lo"], distinct_ga["infl_hi"]), "",
        "RS100 gives GA/ridge %.2f inflation points, versus %.2f points for ordinary RS on exactly the same outer-run subset. The %.2f-point ordinary estimate uses more repetitions, so a direct difference from it would mix comparator and coverage effects." % (
            rs100_ga["mean_infl"], subset_ga["mean_infl"], ordinary_ga["mean_infl"]), "",
        "Ordinary GA/ridge inflation is %.2f at 1,000 requests and %.2f at 4,000 requests. Comparative inflation therefore need not increase with budget. The budget effect on internal fitness versus outer BA is a different estimand." % (
            get_row("ordinary", "ridge", "ga", 1000)["mean_infl"], ordinary_ga["mean_infl"]), "",
        "Two signed inflation point estimates are negative: same-size 5-NN/BPSO at 1,000 and RS100 ridge/BPSO at 1,000. Both intervals span zero. They are retained rather than absorbed into a claim of universal positive distortion.", "",
    ]
    (HERE / "independent_review.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({
        "status": "passed", "groups": 56, "ordinary_subset_groups": 16,
        "raw_jobs": sum(x["job_files"] for x in sources.values()),
        "table8_max_error_pp": max(table8_errors), "primary_max_error_pp": max(primary_errors),
        "subset_max_error_pp": max(subset_errors), "dataset_max_error_pp": max(dataset_errors),
        "directions": {key: value["counts"] for key, value in classifications.items()},
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
