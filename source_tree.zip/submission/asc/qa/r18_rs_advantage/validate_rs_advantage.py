"""Standalone exploratory re-summary of stored random-search controls.

Python 3.8 / frozen evolve environment. Reads stored results only; writes only
to this QA directory. No search, classifier fitting, p-values, bootstrap, TOST,
rank tests, project-loader cache writes, or original table updates.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from collections import Counter
from datetime import datetime, timezone

import numpy as np
import scipy
from scipy import stats

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
CP = (1000, 4000)
ALGOS = ("ga", "bpso", "bde", "nsga2")
CORE = ("colon", "cns", "dlbcl", "leukemia", "prostate", "gli",
        "smk", "ovarian", "breast", "oil_spill", "ozone", "speech", "kc3")
LEARNERS = ("ridge", "knn")
INPUTS = {}
SOURCE_COUNTS = {}
SOURCE_CODE_SHAS = {}
TOL = 1e-12


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rel(path):
    return path.resolve().relative_to(ROOT).as_posix()


def tracked_read(path):
    raw = path.read_bytes()
    INPUTS[rel(path)] = hashlib.sha256(raw).hexdigest()
    return raw


def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                            encoding="utf-8")


def score(val, calls, context):
    for field in ("inner_err", "test_ba"):
        if field not in val:
            raise ValueError("Missing saved %s at %s" % (field, context))
    err, test = float(val["inner_err"]), float(val["test_ba"])
    if not all(math.isfinite(x) and 0.0 <= x <= 1.0 for x in (err, test)):
        raise ValueError("Invalid saved score at " + context)
    return dict(fit=1.0 - err, test=test, k=int(val["k"]), calls=int(calls))


def suite(name):
    records = {}
    code_counts = Counter()
    paths = sorted((ROOT / "results" /
                    ("jobs" if name == "E1h" else "jobs_extra") / name).glob("*.json"))
    if not paths:
        raise ValueError("Missing suite " + name)
    for path in paths:
        rec = json.loads(tracked_read(path).decode("utf-8-sig"))
        spec = rec["spec"]
        assert rec["status"] == "ok", rel(path)
        assert spec["suite"] == name, rel(path)
        assert spec["ds"] in CORE and spec["learner"] in LEARNERS, rel(path)
        assert 0 <= spec["fold"] < 5 and spec["rep"] >= 0, rel(path)
        key = (spec["ds"], spec["learner"], spec["algo"],
               int(spec["rep"]), int(spec["fold"]))
        assert key not in records, "Duplicate raw job key: " + str(key)
        out = {}
        for cp in CP:
            val = rec["result"][str(cp)]
            if name in ("X6d", "X6r"):
                assert val["reached"] is True, rel(path)
                assert val["distinct"] == cp and val["calls"] >= cp, rel(path)
                calls = val["calls"]
            else:
                assert cp in spec["cps"], rel(path)
                calls = cp
            out[cp] = score(val, calls, "%s/%d" % (rel(path), cp))
        records[key] = dict(scores=out, path=rel(path))
        code_counts[rec["code_sha"]] += 1
    SOURCE_COUNTS[name] = dict(job_files=len(paths),
                              used_checkpoint_records=2 * len(paths))
    SOURCE_CODE_SHAS[name] = dict(code_counts)
    return records


def same_size(main):
    path = ROOT / "results/tables/X5m_runs.csv"
    rows = list(csv.DictReader(tracked_read(path).decode("utf-8-sig").splitlines()))
    out = {}
    for row in rows:
        key = (row["ds"], row["learner"], row["ref"],
               int(row["rep"]), int(row["fold"]))
        cp = int(row["budget"])
        assert cp in CP and key in main, str(key)
        full_key = key + (cp,)
        assert full_key not in out, "Duplicate same-size CSV key"
        assert int(row["k"]) == main[key]["scores"][cp]["k"], "Incumbent-size mismatch"
        fit, test = float(row["rsk_fit"]), float(row["rsk_ba"])
        assert all(math.isfinite(x) and 0.0 <= x <= 1.0 for x in (fit, test))
        out[full_key] = dict(fit=fit, test=test, k=int(row["k"]), calls=cp)
    expected = {key + (cp,) for key in main if key[2] in ALGOS for cp in CP}
    assert set(out) == expected, "Same-size CSV does not cover all original algorithm keys"
    SOURCE_COUNTS["X5m_runs.csv"] = dict(rows=len(rows),
                                       matched_incumbent_sizes=len(rows))
    return out


def interval(values):
    vals = np.asarray(values, dtype=float)
    assert len(vals) > 1 and np.isfinite(vals).all()
    point = float(vals.mean())
    half = float(stats.t.ppf(0.975, len(vals) - 1) *
                 vals.std(ddof=1) / np.sqrt(len(vals)))
    return point, point - half, point + half


def rows_csv(name, rows):
    assert rows
    with (HERE / name).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def protected():
    table_files = sorted(p for p in (ROOT / "results/tables").glob("*") if p.is_file())
    return dict(result_tables={rel(p): sha(p) for p in table_files},
                numeric_macros=sha(ROOT / "paper/generated/numbers.tex"),
                freeze_rev2=sha(ROOT / "docs/FREEZE_rev2.json"))


def main():
    assert HERE == ROOT / "submission/asc/qa/r18_rs_advantage"
    assert sys.version_info[:2] == (3, 8)
    assert np.__version__ == "1.24.4" and scipy.__version__ == "1.10.1"
    before = protected()
    macro_text = (ROOT / "paper/generated/numbers.tex").read_text(encoding="utf-8")
    macro_count = len(re.findall(r"\\newcommand\{\\(\w+)\}", macro_text))
    assert len(before["result_tables"]) == 61 and macro_count == 1069
    e1 = suite("E1h")
    r100 = suite("X5s")
    d_alg = suite("X6d")
    d_rs = suite("X6r")
    r_size = same_size(e1)
    expected_dalg = {k for k in e1 if k[2] in ("ga", "nsga2")}
    expected_drs = {k for k in e1 if k[2] == "rs"}
    assert set(d_alg) == expected_dalg, "Distinct algorithm key coverage differs from main"
    assert set(d_rs) == expected_drs, "Distinct random-search key coverage differs from main"
    assert set(k[2] for k in r100) == {"rs100"}
    unused_r100 = [
        dict(ds=k[0], learner=k[1], algo=k[2], rep=k[3], fold=k[4],
             source=r100[k]["path"],
             reason="No matching original E1h outer run; excluded without generating one")
        for k in sorted(r100) if (k[0], k[1], "rs", k[3], k[4]) not in e1]
    expected_r100_keys = {k for k in r100
                         if (k[0], k[1], "rs", k[3], k[4]) in e1}
    summaries, ds_rows, group_detail = [], [], []
    missing_scores, missing_keys = [], []
    for control in ("ordinary", "same_size", "rs100", "strict_distinct",
                    "ordinary_rs100_subset"):
        mode = "distinct_masks" if control == "strict_distinct" else "wrapper_requests"
        for cp in CP:
            for learner in LEARNERS:
                allowed_algos = ("ga", "nsga2") if control == "strict_distinct" else ALGOS
                for algo in allowed_algos:
                    by_ds = {}
                    counts = {}
                    available_main = [k for k in sorted(e1) if k[1:3] == (learner, algo)]
                    used = []
                    for key in available_main:
                        if control == "strict_distinct":
                            a = d_alg[key]["scores"][cp]
                            base_key = (key[0], learner, "rs", key[3], key[4])
                            b = d_rs[base_key]["scores"][cp]
                        elif control == "same_size":
                            a = e1[key]["scores"][cp]
                            b = r_size[key + (cp,)]
                        elif control == "rs100":
                            base_key = (key[0], learner, "rs100", key[3], key[4])
                            if base_key not in r100:
                                continue
                            a = e1[key]["scores"][cp]
                            b = r100[base_key]["scores"][cp]
                        else:
                            if control == "ordinary_rs100_subset":
                                rs100_key = (key[0], learner, "rs100", key[3], key[4])
                                if rs100_key not in r100:
                                    continue
                            a = e1[key]["scores"][cp]
                            base_key = (key[0], learner, "rs", key[3], key[4])
                            b = e1[base_key]["scores"][cp]
                        d_rep = a["fit"] - b["fit"]
                        d_outer = a["test"] - b["test"]
                        d_infl = d_rep - d_outer
                        assert abs(d_infl - ((a["fit"] - a["test"]) -
                                             (b["fit"] - b["test"]))) < 1e-14
                        by_ds.setdefault(key[0], []).append(
                            (d_rep, d_outer, d_infl, a["calls"], b["calls"]))
                        used.append(key)
                    expected_datasets = {k[0] for k in e1 if k[1:3] == (learner, algo)}
                    assert set(by_ds) == expected_datasets
                    assert len(by_ds) == (13 if learner == "ridge" else 11)
                    if control not in ("rs100", "ordinary_rs100_subset"):
                        assert set(used) == set(available_main)
                    else:
                        remapped = {(k[0], k[1], "rs100", k[3], k[4]) for k in used}
                        assert remapped == {k for k in expected_r100_keys if k[1] == learner}
                    ds_vals = []
                    for ds in CORE:
                        if ds not in by_ds:
                            continue
                        matrix = np.asarray(by_ds[ds], dtype=float)
                        values = matrix[:, :3].mean(axis=0)
                        ds_vals.append(values)
                        counts[ds] = len(matrix)
                        ds_rows.append(dict(
                            control=control, budget_mode=mode, budget=cp,
                            learner=learner, algo=algo, ds=ds, n_pairs=len(matrix),
                            mean_rep=100.0 * float(values[0]),
                            mean_outer=100.0 * float(values[1]),
                            mean_infl=100.0 * float(values[2]),
                            mean_algorithm_requests=float(matrix[:, 3].mean()),
                            mean_comparator_requests=float(matrix[:, 4].mean())))
                    matrix = np.asarray(ds_vals, dtype=float)
                    row = dict(control=control, budget_mode=mode, budget=cp,
                               learner=learner, algo=algo, unit="BA_percentage_points",
                               n_ds=len(ds_vals), n_pairs=sum(counts.values()))
                    for i, label in enumerate(("rep", "outer", "infl")):
                        point, lo, hi = interval(matrix[:, i])
                        row["mean_" + label] = 100.0 * point
                        row[label + "_lo"] = 100.0 * lo
                        row[label + "_hi"] = 100.0 * hi
                    summaries.append(row)
                    group_detail.append(dict(control=control, budget=cp,
                                             budget_mode=mode, learner=learner,
                                             algo=algo, n_ds=len(counts),
                                             n_pairs=sum(counts.values()),
                                             pairs_per_dataset=counts,
                                             unmatched_algorithm_main_runs=len(available_main) - len(used)))
    assert len(summaries) == 72
    assert Counter((r["control"], r["budget"]) for r in summaries) == Counter({
        ("ordinary", 1000): 8, ("ordinary", 4000): 8,
        ("same_size", 1000): 8, ("same_size", 4000): 8,
        ("rs100", 1000): 8, ("rs100", 4000): 8,
        ("strict_distinct", 1000): 4, ("strict_distinct", 4000): 4,
        ("ordinary_rs100_subset", 1000): 8, ("ordinary_rs100_subset", 4000): 8})
    primary_summaries = [r for r in summaries if r["control"] != "ordinary_rs100_subset"]
    subset_summaries = [r for r in summaries if r["control"] == "ordinary_rs100_subset"]
    primary_ds_rows = [r for r in ds_rows if r["control"] != "ordinary_rs100_subset"]
    subset_ds_rows = [r for r in ds_rows if r["control"] == "ordinary_rs100_subset"]
    assert len(primary_summaries) == 56 and len(subset_summaries) == 16
    assert len(primary_ds_rows) == 672 and len(subset_ds_rows) == 192
    rs100_ds = {(r["budget"], r["learner"], r["algo"], r["ds"]): r
                for r in primary_ds_rows if r["control"] == "rs100"}
    coverage_rows = []
    for row in subset_ds_rows:
        other = rs100_ds[(row["budget"], row["learner"], row["algo"], row["ds"])]
        assert row["n_pairs"] == other["n_pairs"]
        diff = dict(budget=row["budget"], learner=row["learner"], algo=row["algo"],
                    ds=row["ds"], n_pairs=row["n_pairs"], unit="BA_percentage_points")
        for label in ("rep", "outer", "infl"):
            field = "mean_" + label
            diff["ordinary_subset_" + label] = row[field]
            diff["rs100_" + label] = other[field]
            diff["rs100_minus_ordinary_subset_" + label] = other[field] - row[field]
        coverage_rows.append(diff)
    ref_path = ROOT / "results/tables/Q5b_advantage_inflation.csv"
    reference = list(csv.DictReader(tracked_read(ref_path).decode("utf-8-sig").splitlines()))
    reference = {(int(r["cp"]), r["learner"], r["algo"]): r for r in reference}
    differences, comparisons = [], []
    for row in summaries:
        if row["control"] != "ordinary" or row["budget"] != 4000:
            continue
        original = reference[(4000, row["learner"], row["algo"])]
        for new_name, old_name in (("mean_rep", "rep"), ("rep_lo", "rep_lo"),
                                   ("rep_hi", "rep_hi"), ("mean_outer", "true"),
                                   ("outer_lo", "true_lo"), ("outer_hi", "true_hi"),
                                   ("mean_infl", "infl"), ("infl_lo", "infl_lo"),
                                   ("infl_hi", "infl_hi")):
            actual = row[new_name] / 100.0
            expected = float(original[old_name])
            error = abs(actual - expected)
            differences.append(error)
            comparisons.append(dict(learner=row["learner"], algo=row["algo"],
                                     field=new_name, reconstructed_ba_fraction=actual,
                                     existing_csv_ba_fraction=expected,
                                     absolute_error_ba_fraction=error))
    assert len(comparisons) == 72 and max(differences) <= TOL
    after = protected()
    assert before == after, "An original protected output changed during verification"
    input_manifest = dict(input_files_sha256=INPUTS,
                          script_path=rel(Path(__file__)),
                          script_sha256=sha(Path(__file__)))
    write_json("input_sha256.json", input_manifest)
    rows_csv("advantage_summary.csv", primary_summaries)
    rows_csv("advantage_by_dataset.csv", primary_ds_rows)
    rows_csv("ordinary_rs100_subset_summary.csv", subset_summaries)
    rows_csv("ordinary_rs100_subset_by_dataset.csv", subset_ds_rows)
    rows_csv("rs100_coverage_comparison_by_dataset.csv", coverage_rows)
    report = dict(
        status="passed", created_utc=datetime.now(timezone.utc).isoformat(),
        runtime=dict(python=sys.version, executable=sys.executable,
                     numpy=np.__version__, scipy=scipy.__version__),
        analysis_decision="Before computing estimates: retain all 28 configurations at each of 1,000 and 4,000 targets, 56 total; no result-based selection. Additional 16 ordinary-RS summaries use exactly the RS100 intersection to control run coverage.",
        main_configurations=56,
        coverage_matched_supporting_configurations=16,
        method=dict(
            run_difference="[(F_algorithm-F_comparator)-(T_algorithm-T_comparator)]",
            fitness_field="1-inner_err from stored JSON; same-size comparator uses saved rsk_fit",
            outer_field="stored test_ba; same-size comparator uses saved rsk_ba",
            matching_keys=["data set", "learner", "algorithm-specific comparator",
                           "repeat", "outer fold", "checkpoint or distinct target"],
            aggregation="Mean paired differences within data set, then equal mean over data sets",
            interval="Unadjusted exploratory 95% Student-t interval over data-set means; df=n_ds-1",
            units="CSV results are BA percentage points; verification errors are BA fractions",
            p_values_computed=False, tests_performed=False, new_experiments=False),
        source_counts=SOURCE_COUNTS, source_code_sha_counts=SOURCE_CODE_SHAS,
        all_groups=group_detail,
        unmatched_rs100_jobs_excluded=unused_r100,
        missing_score_fields=missing_scores, invalid_or_duplicate_pair_keys=missing_keys,
        ordinary_4000_existing_table_check=dict(
            numeric_fields_checked=72,
            tolerance_ba_fraction=TOL,
            maximum_absolute_error_ba_fraction=max(differences),
            exact_binary_float_matches=sum(d == 0.0 for d in differences),
            all_within_tolerance=True, field_comparisons=comparisons),
        preserved_outputs=dict(
            original_result_tables=len(before["result_tables"]),
            original_numeric_macros=macro_count,
            all_before_after_sha256_unchanged=True,
            before=before, after=after),
        input_manifest=dict(path=rel(HERE / "input_sha256.json"),
                            sha256=sha(HERE / "input_sha256.json"),
                            file_count=len(INPUTS),
                            script_sha256=sha(Path(__file__))),
        output_files=dict(
            summary_sha256=sha(HERE / "advantage_summary.csv"),
            dataset_rows_sha256=sha(HERE / "advantage_by_dataset.csv"),
            ordinary_subset_summary_sha256=sha(HERE / "ordinary_rs100_subset_summary.csv"),
            ordinary_subset_dataset_sha256=sha(HERE / "ordinary_rs100_subset_by_dataset.csv"),
            coverage_comparison_dataset_sha256=sha(HERE / "rs100_coverage_comparison_by_dataset.csv")),
        limitations=[
            "Post-hoc exploratory re-summary; confidence intervals for all 56 main and 16 coverage-matched supporting configurations are unadjusted, not confirmatory multiple-comparison evidence.",
            "Only 13 ridge/11 5-NN data sets; data-set-equal averaging does not treat repeated outer folds as independent units.",
            "RS100 uses the intersection with original runs (320 ridge/265 5-NN pairs per algorithm per target); full ordinary/same-size/distinct use 580/490. Compare RS100 directly to ordinary_rs100_subset, which uses the same 585 outer keys; do not attribute differences from full ordinary to the baseline alone.",
            "Same-size RS conditions on incumbent feature count selected by the compared algorithm; it is not an independently size-selecting procedure or a causal isolation of evolutionary operators.",
            "Strict-distinct controls both evaluated masks at the target, with different wrapper-request counts; its estimand is not identical to a request-budget contrast.",
            "RS100 widens uniform subset-size support to min(100,p); ordinary support is min(40,p). Neither exactly matches evolutionary size distributions.",
            "No equivalence, operator-effect, rank-stability, p-value, or universal algorithm-ordering conclusion is established.",
            "Stored records and derived statistics are verified; classifiers and searches were not rerun."
        ])
    write_json("validation.json", report)
    print(json.dumps(dict(status=report["status"], main_groups=len(primary_summaries),
                          coverage_matched_groups=len(subset_summaries),
                          data_set_rows=len(primary_ds_rows),
                          supporting_data_set_rows=len(subset_ds_rows),
                          input_files=len(INPUTS),
                          ordinary_fields_checked=72,
                          max_error_ba_fraction=max(differences),
                          rs100_excluded_jobs=len(unused_r100),
                          original_outputs_unchanged=True)))


if __name__ == "__main__":
    main()
