"""Read-only verification of the existing Q5b mean-rank Kendall tau-b summary.

Run with the frozen experiment interpreter. This does not launch a search,
perform an inferential test, calculate a p-value, or write result tables.
"""
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import scipy

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "submission" / "asc"
ALGOS = ["ga", "bpso", "bde", "nsga2", "rs"]
CORE = ["colon", "cns", "dlbcl", "leukemia", "prostate", "gli",
        "smk", "ovarian", "breast", "oil_spill", "ozone", "speech", "kc3"]
CP = 4000


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def pair_counts(x, y):
    counts = dict(concordant=0, discordant=0, tied_x_only=0,
                  tied_y_only=0, tied_both=0)
    detail = []
    for i in range(len(x)):
        for j in range(i + 1, len(x)):
            dx, dy = x[i] - x[j], y[i] - y[j]
            if dx == 0 and dy == 0:
                kind = "tied_both"
            elif dx == 0:
                kind = "tied_x_only"
            elif dy == 0:
                kind = "tied_y_only"
            elif dx * dy > 0:
                kind = "concordant"
            else:
                kind = "discordant"
            counts[kind] += 1
            detail.append(dict(algorithms=[ALGOS[i], ALGOS[j]], kind=kind))
    cd = counts["concordant"] + counts["discordant"]
    denominator = math.sqrt((cd + counts["tied_x_only"]) *
                            (cd + counts["tied_y_only"]))
    tau_b = (counts["concordant"] - counts["discordant"]) / denominator
    return counts, detail, tau_b


def main():
    table_paths = sorted((ROOT / "results" / "tables").glob("*"))
    before_tables = {p.name: digest(p) for p in table_paths if p.is_file()}
    files = sorted((ROOT / "results" / "jobs" / "E1h").glob("*.json"))
    records = []
    aggregate = hashlib.sha256()
    for path in files:
        aggregate.update((path.name + ":" + digest(path) + "\n").encode("utf-8"))
        rec = load_json(path)
        assert rec["status"] == "ok"
        assert rec["spec"]["kind"] == "honest"
        spec, val = rec["spec"], rec["result"][str(CP)]
        records.append(dict(ds=spec["ds"], learner=spec["learner"],
                            algo=spec["algo"], rep=spec["rep"],
                            fold=spec["fold"], fit=1.0 - val["inner_err"],
                            test_ba=val["test_ba"]))
    frame = pd.DataFrame(records)
    assert not frame.duplicated(["ds", "learner", "algo", "rep", "fold"]).any()
    rank_path = ROOT / "results" / "tables" / "Q5b_rank_by_criterion.csv"
    rank_table = pd.read_csv(rank_path)
    output = dict(
        status="passed",
        scope="Independent descriptive recomputation of existing 4,000-request mean ranks and Kendall tau-b; no new experiments, p-values, or tests.",
        runtime=dict(python=sys.version, python_executable=sys.executable,
                     numpy=np.__version__, pandas=pd.__version__, scipy=scipy.__version__),
        method=dict(
            checkpoint_requests=CP,
            algorithms=ALGOS,
            score_means="Average the original E1h outer-run fitness BA (1-inner_err) and outer-test BA within each data set and algorithm.",
            dataset_ranks="Rank the five mean scores within each data set, descending (1 is best); exact ties receive average ranks.",
            algorithm_rank_vectors="Average the within-data-set ranks equally over available data sets, keeping one value per algorithm.",
            statistic="Kendall tau-b of the two five-element mean-rank vectors in common algorithm order.",
            independent_formula="(C-D)/sqrt((C+D+ties_in_fitness_only)*(C+D+ties_in_outer_only)); pairs tied in both vectors excluded.",
            inferential_limit="Descriptive agreement of this benchmark's mean-rank vectors; no ranking stability, superiority, or inferential p-value is assessed.",
        ),
        source=dict(raw_jobs="results/jobs/E1h", raw_files_read=len(files),
                    raw_rows_used_at_checkpoint=len(frame),
                    filename_and_file_sha256_aggregate=aggregate.hexdigest(),
                    rank_table=str(rank_path.relative_to(ROOT)).replace("\\", "/"),
                    rank_table_sha256=digest(rank_path),
                    implementation="analysis/compare.py: advantage_inflation, R uses pandas average-tie descending ranks; scipy.stats.kendalltau called without variant so default is b.",
                    implementation_sha256=digest(ROOT / "analysis" / "compare.py")),
        groups=[],
    )
    for lr, expected_n in [("ridge", 13), ("knn", 11)]:
        by = {"fitness": {}, "honest": {}}
        run_counts = {}
        for ds in CORE:
            h = frame[(frame.ds == ds) & (frame.learner == lr)]
            if h.algo.nunique() < 5:
                continue
            means = h.groupby("algo")[["fit", "test_ba"]].mean()
            by["fitness"][ds] = means["fit"]
            by["honest"][ds] = means["test_ba"]
            run_counts[ds] = h.groupby("algo").size().to_dict()
        ranks = {k: pd.DataFrame(v).T.rank(axis=1, ascending=False,
                    method="average") for k, v in by.items()}
        average = {k: v.mean(axis=0).reindex(ALGOS) for k, v in ranks.items()}
        assert len(ranks["fitness"]) == expected_n
        existing = rank_table[(rank_table.cp == CP) &
                              (rank_table.learner == lr)].set_index("algo").reindex(ALGOS)
        x, y = average["fitness"].to_numpy(), average["honest"].to_numpy()
        max_error = max(float(np.max(np.abs(
            x - existing["mean_rank_by_fitness"].to_numpy()))),
            float(np.max(np.abs(
            y - existing["mean_rank_by_honest"].to_numpy()))))
        assert max_error < 1e-12
        counts, detail, tau_b = pair_counts(x, y)
        expected_tau = float(existing["kendall_tau_between_rankings"].iloc[0])
        assert abs(tau_b - expected_tau) < 1e-12
        output["groups"].append(dict(
            learner=lr, n_datasets=expected_n,
            dataset_names=list(ranks["fitness"].index),
            runs_per_dataset_and_algorithm=run_counts,
            mean_rank_by_fitness=average["fitness"].to_dict(),
            mean_rank_by_outer_ba=average["honest"].to_dict(),
            within_dataset_ranks_by_fitness=ranks["fitness"].to_dict(orient="index"),
            within_dataset_ranks_by_outer_ba=ranks["honest"].to_dict(orient="index"),
            pair_counts=counts, algorithm_pair_details=detail,
            tau_b_independent_formula=tau_b,
            tau_b_existing_csv=expected_tau,
            tau_b_rounded_for_manuscript=format(tau_b, ".2f"),
            maximum_absolute_mean_rank_error=max_error,
            absolute_tau_error=abs(tau_b - expected_tau),
        ))
    # Cross-check the existing full paired-advantage verification without
    # creating additional estimates, intervals, tests, or p-values.
    verified = load_json(HERE / "focused_stats_validation.json")
    advantage_path = ROOT / "results" / "tables" / "Q5b_advantage_inflation.csv"
    assert verified["status"] == "passed"
    assert verified["source"]["result_csv_sha256"] == digest(advantage_path)
    advantage = pd.read_csv(advantage_path)
    advantage = advantage[advantage.cp == CP]
    assert len(advantage) == 8
    assert dict(advantage.groupby("learner").n_ds.first()) == {"knn": 11, "ridge": 13}
    output["existing_paired_advantage_validation"] = dict(
        verification_report="submission/asc/focused_stats_validation.json",
        verification_report_sha256=digest(HERE / "focused_stats_validation.json"),
        original_5350_jobs_verified=verified["source"]["raw_files_read"],
        original_4280_paired_runs_verified=verified["source"]["matched_algorithm_rs_pairs_across_eight_groups"],
        source_csv_current_hash_matches=True,
        learner_n_datasets=dict(advantage.groupby("learner").n_ds.first()),
        statistical_unit="Data set; outer runs matched by (data set, learner, repeat, outer fold) before aggregation.",
        estimand="[(F_algorithm-F_RS)-(T_algorithm-T_RS)] per matched outer run; mean within data set, then equal mean across data sets.",
        confidence_interval="Existing unadjusted exploratory Student-t interval of data-set means; not a difference of marginal interval limits or rounded table values.",
    )
    after_tables = {p.name: digest(p) for p in table_paths if p.is_file()}
    assert before_tables == after_tables
    output["integrity"] = dict(result_tables_checked=len(before_tables),
                              every_result_table_sha256_unchanged=True)
    out_path = HERE / "r17_kendall_validation.json"
    out_path.write_text(json.dumps(output, ensure_ascii=False, indent=2,
                                  default=lambda z: z.item() if hasattr(z, "item") else str(z)) + "\n",
                        encoding="utf-8")
    print(json.dumps(dict(status=output["status"], raw_files=len(files),
                          groups=[dict(learner=g["learner"],
                                       tau_b=g["tau_b_independent_formula"],
                                       pair_counts=g["pair_counts"])
                                  for g in output["groups"]],
                          report=str(out_path)), ensure_ascii=False))


if __name__ == "__main__":
    main()
