# Independent verification of X11c GPU primary effects

Directly recomputed from the 12,000-row checkpoint CSV; no project aggregation function was imported. Each difference was paired within its outer run, averaged within dataset, then averaged equally across eight datasets. Student t df=7. Units: BA percentage points.

|Contrast|Mean discrepancy|Ordinary 95% CI|Three-item Bonferroni interval|Fixed decision|
|---|---:|---|---|---|
|C1|2.232771081|[0.922296636, 3.543245526]|[0.499482027, 3.966060135]|supported_positive|
|C2|3.393792784|[0.214558297, 6.573027271]|[-0.811197521, 7.598783088]|inconclusive|
|C3|2.430854604|[0.908596328, 3.953112879]|[0.417451278, 4.444257930]|supported_positive|

The family intervals have individual confidence 98.333333%. C1 and C3 meet the predefined positive criterion. C2 does not. Its ordinary 95% interval does not override the fixed multiplicity rule.

|Contrast|Internal component F|Outer component T|Discrepancy B=F-T|
|---|---:|---:|---:|
|C1|4.346968395|2.114197315|2.232771081|
|C2|4.674597375|1.280804591|3.393792784|
|C3|3.991505228|1.560650624|2.430854604|

For C1, F and T are the paired 250-to-4,000 increments across all five searches and two learners. For C2/C3 they are the algorithm-minus-RS internal and outer advantages at 4,000 requests. They are distinct quantities.

Primary CSV, primary JSON and all 24 dataset primary rows agree within 1e-10 percentage points. Largest primary numeric discrepancy: 1.78e-15; largest dataset discrepancy: 1.78e-15.
Checkpoint B=F-T maximum residual: 0 BA fractions; paired residual: 0; dataset residual: 8.88e-16 percentage points; overall residual: 4.44e-16 percentage points.

No original-thirteen results were read. No fitting, network operation or result-file modification was performed. Only these independent verification reports were written.

Validation status: PASS
