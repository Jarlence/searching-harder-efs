# Complete GPU execution integrity validation

Status: **PASSED**

This check reads saved files and recomputes hashes and deterministic record transformations. It does not rerun learners, compute primary statistical estimates, or access the network.

| Check | Observed evidence |
|---|---|
| Freeze chain | Original 30-source freeze → 37-source local freeze → 44-source GPU freeze; all 33 data-file entries and fixed design entries agree. |
| Current protected inputs | 44 source files and 33 data files matched their frozen SHA-256 values. |
| Raw GPU jobs | 4000/4,000 records validated; 4000/4,000 raw SHA-256 values match job_hashes.json. |
| Checkpoint coverage | 12000/12,000, exactly 250 / 1,000 / 4,000 requests in every job. |
| Cell coverage | Every dataset has 500 jobs; every dataset × algorithm × learner has all 10 repeats × 5 folds = 50 jobs. |
| Paired folds | 400 paired outer partitions and 800 paired inner partitions agree across corresponding algorithms/learners and match frozen split hashes. |
| GPU chronology | Freeze 2026-10-15T02:39:15.973622+00:00; first GPU job 2026-10-15T02:39:21.919250+00:00; last completion 2026-10-15T18:12:08.553922+00:00; analysis 2026-10-15T18:19:07.204839+00:00. |
| Actual CUDA diagnostics | Every record reports cuda:0 / float64, positive corresponding ridge or kNN execution, exact per-distinct-candidate operation counts, and deterministic non-TF32 runtime metadata. |
| Saved exports | All 13 frozen analysis-output hashes agree. Checkpoints CSV (12000 rows) and execution CSV (4000 rows) exactly match raw job records and their declared arithmetic transforms. |
| Preserved CPU records | 684/684 files retained; all filename-to-SHA mappings equal the pre-GPU test report. No CPU raw-record content is reused in GPU records. |

## Dataset coverage

| Dataset | Valid jobs |
|---|---|
| nc_climate | 500 / 500 |
| nc_credit | 500 / 500 |
| nc_dbworld | 500 / 500 |
| nc_dexter | 500 / 500 |
| nc_gisette | 500 / 500 |
| nc_ionosphere | 500 / 500 |
| nc_qsar | 500 / 500 |
| nc_spambase | 500 / 500 |

## Scope of this finding

This establishes file integrity, complete execution, recorded device provenance, timing, and export consistency. It is not an independent rerun of the 4,000 experiments and does not by itself establish the scientific hypotheses. The CUDA dispatch counter counts declared learner/scaling operations, not individual GPU kernel launches. CPU search control, training-only scaler statistics, kNN argpartition, and metrics are deliberately retained.

Full source/data hashes, output hashes, operation totals, CUDA maximum-dimension ranges, cell counts, and failures are recorded in complete_integrity_validation.json.

## Failures

None.
