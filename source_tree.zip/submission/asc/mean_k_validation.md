# Feature-count weighting correction

The two X5m summary tables now use the mean of within-data-set mean feature counts, matching the manuscript prose (13 available data sets for ridge; 11 for 5-NN). No experiments were rerun.

All 8,560 X5m run feature counts exactly match their corresponding E1h incumbents, with no missing, duplicate, or mismatched run key. The within-data-set means exactly match E1h_honest_means.csv when CSV floats are parsed with round_trip.

| Learner | Budget | Algorithm | Previous run-weighted mean | Data-set-equal mean | Rounded |
|---|---:|---|---:|---:|---:|
| knn | 1000 | bde | 87.56530612244897 | 79.89696969696969 | 80 |
| knn | 1000 | bpso | 20.579591836734693 | 20.086666666666666 | 20 |
| knn | 1000 | ga | 24.56734693877551 | 23.40909090909091 | 23 |
| knn | 1000 | nsga2 | 11.19795918367347 | 10.906060606060604 | 11 |
| knn | 4000 | bde | 92.15306122448979 | 83.71090909090911 | 84 |
| knn | 4000 | bpso | 20.602040816326532 | 20.072727272727278 | 20 |
| knn | 4000 | ga | 22.787755102040816 | 21.684848484848487 | 22 |
| knn | 4000 | nsga2 | 6.689795918367347 | 6.622424242424242 | 7 |
| ridge | 1000 | bde | 72.08620689655173 | 70.05717948717948 | 70 |
| ridge | 1000 | bpso | 21.063793103448276 | 21.48820512820513 | 21 |
| ridge | 1000 | ga | 22.637931034482758 | 23.4351282051282 | 23 |
| ridge | 1000 | nsga2 | 12.010344827586207 | 12.623846153846152 | 13 |
| ridge | 4000 | bde | 76.28793103448275 | 74.28897435897437 | 74 |
| ridge | 4000 | bpso | 21.041379310344826 | 21.603333333333335 | 22 |
| ridge | 4000 | ga | 21.432758620689654 | 23.103589743589744 | 23 |
| ridge | 4000 | nsga2 | 8.436206896551724 | 9.215897435897435 | 9 |

CSV validation preserves original field strings, row order, BOM, quoting, and line endings except for mean_k values.
- X5m_same_size_rs.csv: 16 mean_k cells changed; 384 non-k field strings compared, 0 differences.
- X5m_size_effect_on_rs.csv: 16 mean_k cells changed; 208 non-k field strings compared, 0 differences.

Exact rational means, per-data-set means, before/after strings, runtime, and SHA-256 values are recorded in mean_k_validation.json. The generator uses xa.groupby(level="ds").k.mean().mean() for both summary tables.

Pandas default CSV float parsing can differ by one ULP from round_trip parsing; this changes no integer feature count displayed in the manuscript.
