# Reproducing the results


## R22: completed full-core strict inner-fold scaling

The current R22 manuscript adds 5,350 X10s jobs (16,050 checkpoints) to the unchanged 38,360 earlier records. Its strict-scaling follow-up is a sensitivity study on previously analysed data, not independent confirmation. Read docs/STRICT_SCALING_R22_PLAN.md and the immutable STRICT_SCALING_R22_FREEZE.json before running it. Keep the original pinned scientific environment; document rendering may use a separate Python environment.

~~~powershell
python extras/run_extra6.py --dry
python extras/run_extra6.py --workers 6
python analysis/strict_scaling_r22.py
python analysis/verify_strict_scaling_r22.py
~~~

Do not run --freeze over the supplied freeze. Completed atomic job records are validated and skipped. For an independent rerun, preserve the supplied record and move only the chosen X10s job aside in a separate copy of the project, then run the unchanged dispatcher. Compare score, mask and split fields; completion times may differ. The analysis requires complete coverage. All 300 overlapping historical X1 jobs were checked for exact stored score/mask agreement; this overlap is not independent evidence.

The fixed nine-estimate family includes the paired budget-gap increase and eight algorithm–RS advantage discrepancies. The summaries include ordinary 95% and Bonferroni family intervals, all dataset means and all paired checkpoints. Other paired protocol-change intervals are descriptive. New outputs live in results/r22_strict_scaling/. R22 does not overwrite the original table collection.

The remaining sections below describe the original suites and their historical reproduction checks. They do not include X10s automatically, and their timing estimates exclude R22. Original and R22 source freezes are immutable; do not regenerate an old freeze for the current project. Current manuscript and submission rebuilding is documented in paper/README.md and submission/asc/README.md. The final material archive contains all 43,710 records, but no external data bytes, blind keys, human verification sheets or third-party full texts.


Three entry points, from cheap to expensive. All commands run from the project root in a Python 3.8 environment with the pinned packages of
[`requirements-lock.txt`](requirements-lock.txt) (create a new environment for this; do not install into an environment that other work depends on).
Set `OMP_NUM_THREADS=1` first; bit-exact agreement was verified on Windows 11, CPython 3.8.20, numpy 1.24.4, scipy 1.10.1, scikit-learn 1.3.2 with single-threaded BLAS.
Other platforms or BLAS builds may differ in the last digits of floating-point results.

## 0. Integrity of the inputs (offline, seconds)

```
python experiments/verify_data.py
```
Recomputes the MD5 of the 13 raw OpenML files and the UCI Parkinson archive and the SHA-256 of the 14 processed data sets and compares them with `data/data_cards.json`.
(`python experiments/get_data.py` rebuilds the processed data from the public sources; it needs network access and, for the Parkinson set, 7-Zip.)

## 1. Original stored jobs to original tables, figures and numbers (about 20–30 minutes)

```
python -m unittest discover -s tests           # original and R22 implementation checks
python analysis/test_statsx.py                 # 10 tests of the statistics helpers
python analysis/run_all.py                     # results/tables, results/figures, results/SUMMARY.md
EFS_PAPER=1 python analysis/figures.py         # paper-sized vector figures -> paper/figures
python paper/make_assets.py                    # paper/generated/numbers.tex and tab_*.tex (every number and table of the paper)
cd paper && latexmk -pdf main.tex              # paper/main.pdf
python analysis/manifest.py                    # SHA-256 of all code, documents, tables and the whole job set -> results/MANIFEST.json
```
`results/MANIFEST.json` lists the hash of each file and one hash over the complete job set, so that the stored results can be checked as a whole.
The revision-2 analysis also runs `analysis/revision2.py`, which requires the complete X6r random-search suite and replaces the approximate distinct-budget comparison with a comparator that reaches the same number of distinct masks.

## 2. Representative jobs re-run from scratch and compared bit by bit (minutes)

```
python analysis/repro_check.py 60              # 60 random jobs among those that took <= 25 s; WRITES results/REPRODUCIBILITY.md
python analysis/revision.py                    # includes the bit-for-bit check of the Pareto replay (results/tables/X8p_check.json)
python analysis/revision2.py                   # X6r completeness, original RS replay, and strictly matched distinct-candidate analysis
```
The reported check re-ran 68 jobs: 60 drawn at random from the jobs that had taken at most 25 seconds and the cheapest 8 jobs of four slow suites (E6u, E6uf, Ep_f, E7l).
It is a check of determinism, not an independent replication of the scientific results.

## 3. Everything from scratch (about 190 CPU hours on one workstation; resumable)

```
python experiments/run_suite.py --suites E1h,Eperm,E1f,E2b,E3m,E4s,E5so,E5si,E6u,E7l --workers 20   # main experiment, ~20,600 jobs
python extras/run_extra.py  --suites X1s,X2k,X3u,X4r,X5s --workers 8                                  # earlier sensitivity / mechanism studies
python extras/run_extra3.py --suites X8p,X6d,X5m,X7d --workers 20                                      # follow-up studies after the external review
python extras/run_extra4.py --suites X9s --workers 8
python extras/run_extra5.py --workers 4         # X6r: ONLY RS extended to 1,000 / 4,000 distinct masks (revision 2)
```
Every job is one JSON file (`results/jobs*/<suite>/`), written atomically; re-running skips finished jobs.
Search and split streams derive from SHA-256 of the identifying keys; cardinality repair uses a separate fixed-seed stream. A job is deterministic under the same package versions and numerical environment.

## Where things are

| What | Where |
|---|---|
| Paper | `paper/main.pdf` (sources `paper/main.tex`, `paper/sections/`; numbers from `paper/generated/`) |
| Protocol (hashed before the main run), analysis plan, change log, review log | `docs/PROTOCOL.md`, `docs/ANALYSIS_PLAN.md`, `docs/DEVIATIONS.md`, `docs/REVISION_1.md`; hashes in `docs/FREEZE_dev*.json` |
| Benchmark implementation | `src/efsbench/` (outer-test-isolated protocol, five searches, budget accounting, Pareto archive in `tracking.py`) |
| Results and summary | `results/SUMMARY.md`, `results/tables/`, `results/figures/`, `results/jobs*/` |
| Literature audit | `audit/` (codebook, extracts, codes, recall check, human-verification sheet) |

历史修订2最终本地冻结（当时的流程，不要对当前版本重跑或覆盖该冻结）：分析和PDF验证完成后运行 `python experiments/freeze_rev2.py`，再运行 `python analysis/manifest.py`。前者会核对原37,290作业整体哈希及dev4核心/processed data不变；后者记录当前稿件和输出。旧冻结文件与历史快照保留。这些都是本地修订记录，不是外部预注册或已公开发布。
