"""Deep-dive for one paper: print every sentence matching a regex.  usage: python grep.py PMCID "regex" [max]"""
import os
import re
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import extract as E  # noqa: E402

pmcid, pat = sys.argv[1], re.compile(sys.argv[2], re.I)
mx = int(sys.argv[3]) if len(sys.argv) > 3 else 8
raw = E.fetch(pmcid)
root = ET.fromstring(raw)
n = 0
for sec, s in E.sentences(E.paragraphs(root)):
    if pat.search(s):
        print("  (%s) %s" % (sec[:40], s[:360]))
        n += 1
        if n >= mx:
            break
if n == 0:
    print("  (no match)")
