# Recall check of the audit extraction (automatic)

Full text (everything except the reference list) of the 211 included papers was re-read; 0 could not be fetched or parsed.

Papers coded F1 = U (not stated) that were re-read: 162.
Of these, 48 (30%) contain at least one sentence matching a pattern for 'when / on which samples were features selected' that the coder never saw.

Where the unseen candidate sentences are (papers with at least one in the location):

* body: 36 papers
* body-intro/discussion: 17 papers
* table: 6 papers
* abstract: 3 papers
* figure-caption: 2 papers

Papers with an unseen candidate in a methods-type body section (the coder's own territory; missed by the three-sentences-per-category cap or the ranking): 28.

For comparison, papers coded F1 = A or P: 49, of which 28 contain unseen candidate sentences.
