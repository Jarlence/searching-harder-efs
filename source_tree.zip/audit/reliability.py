"""Intra-rater reliability of the AI hand coding: blind re-coding of 40 papers (audit/recode/*.txt) vs the first pass (coding_v1.jsonl),
plus agreement with the independent rule-based coder (explicit pattern hits).  Writes audit/RELIABILITY.md."""
import json
import os
import sys
from collections import Counter

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))
ex = {}
for l in open(os.path.join(ROOT, "audit", "extracts.jsonl"), encoding="utf-8"):
    r = json.loads(l); ex[r["pmcid"]] = r
first = {}
for l in open(os.path.join(ROOT, "audit", "coding_v1.jsonl"), encoding="utf-8"):
    d = json.loads(l); first[d["pmcid"]] = d
second = {}
for f in sorted(os.listdir(os.path.join(ROOT, "audit", "recode"))):
    if f.endswith(".txt"):
        for line in open(os.path.join(ROOT, "audit", "recode", f), encoding="utf-8"):
            line = line.strip()
            if line:
                p = [x.strip() for x in line.split("|")]
                second[p[0]] = dict(incl=int(p[1]), F1=p[2], F2=p[3], F3=p[4], F4=p[5], F5=p[6], F6=p[7], validation=p[8], evidence=p[9] if len(p) > 9 else "")
ids = sorted(second)
CODES = ("F1", "F2", "F3", "F4", "F5", "F6")


def kappa(a, b):
    n = len(a)
    if n == 0:
        return float("nan")
    cats = sorted(set(a) | set(b))
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in cats)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def boot_kappa(a, b, n=4000, seed=1):
    rng = np.random.default_rng(seed); a = np.array(a); b = np.array(b); out = []
    for _ in range(n):
        i = rng.integers(0, len(a), len(a)); out.append(kappa(list(a[i]), list(b[i])))
    out = np.array([x for x in out if not np.isnan(x)])
    return (float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))) if len(out) else (float("nan"), float("nan"))


def ok(i, c):
    f = ex[i]["flags"]
    return c["incl"] == 1 and f["ec_terms"] >= 5 and f["fs_terms"] >= 3 and ex[i].get("article_type") == "research-article"


L = ["### 编码可靠性（盲复编码 + 规则编码器）", "",
     "**盲复编码**：从 239 篇抽样中按固定种子取 40 篇（只取 PMC1xxxxxxx 号段——PMC8/PMC9 号段的首轮编码行曾在我的工作上下文中显示过，复编码不再盲，故排除），"
     "仅看抽取句子、不看首轮编码，按同一份手册重新编码；与首轮逐篇比较。这是**同一编码者两次编码的一致性**（intra-rater），**不是**独立第二编码者；"
     "独立人工核对表见 `audit/verification_sheet.csv`。", ""]
inc_a = [first[i]["incl"] for i in ids]; inc_b = [second[i]["incl"] for i in ids]
L.append("- 纳入判断一致：%d/%d = %.0f%%（κ = %.2f）；两次都编为纳入且满足全文术语阈值（进化类 ≥ 5、特征选择 ≥ 3）的论文 %d 篇。" % (
    sum(x == y for x, y in zip(inc_a, inc_b)), len(ids), 100.0 * np.mean([x == y for x, y in zip(inc_a, inc_b)]), kappa(inc_a, inc_b),
    sum(1 for i in ids if ok(i, first[i]) and ok(i, second[i]))))
both = [i for i in ids if ok(i, first[i]) and ok(i, second[i])]
L += ["", "| 编码 | 篇数 | 完全一致 | 原始一致率 | Cohen κ [95% 自助区间] | 两次编码的分布（首轮 P/A/U/N → 复编 P/A/U/N） |", "|---|---:|---:|---:|---|---|"]
dis_lines = []
for c in CODES:
    a = [first[i][c] for i in both]; b = [second[i][c] for i in both]
    agree = sum(x == y for x, y in zip(a, b)); k = kappa(a, b); lo, hi = boot_kappa(a, b)
    ca, cb = Counter(a), Counter(b)
    L.append("| %s | %d | %d | %.0f%% | %.2f [%.2f, %.2f] | %s → %s |" % (c, len(both), agree, 100.0 * agree / len(both), k, lo, hi,
                                                                       "/".join(str(ca[x]) for x in "PAUN"), "/".join(str(cb[x]) for x in "PAUN")))
    for i, x, y in zip(both, a, b):
        if x != y:
            dis_lines.append((i, c, x, y))
# the quantity that drives the headline: is an explicit flaw (P) coded in either pass?
pa = [any(first[i][c] == "P" for c in ("F1", "F2", "F3", "F5", "F6")) for i in both]
pb = [any(second[i][c] == "P" for c in ("F1", "F2", "F3", "F5", "F6")) for i in both]
L += ["", "- **\"至少一项明确缺陷（P）\"**（决定正文头条数字）：首轮 %d/%d，复编 %d/%d，一致 %d/%d。" % (sum(pa), len(both), sum(pb), len(both), sum(x == y for x, y in zip(pa, pb)), len(both))]
u1 = [first[i]["F1"] == "U" for i in both]; u2 = [second[i]["F1"] == "U" for i in both]
L.append("- **F1 无法判断（U）的比例**：首轮 %.0f%%，复编 %.0f%%（决定\"报告不透明\"这一头条结论）。" % (100.0 * np.mean(u1), 100.0 * np.mean(u2)))
L += ["", "不一致的条目（共 %d 处）：" % len(dis_lines), ""]
for i, c, x, y in dis_lines:
    L.append("- %s %s：首轮 %s → 复编 %s（首轮证据：%s；复编证据：%s）" % (i, c, x, y, first[i]["evidence"][:70], second[i]["evidence"][:70]))
# rule-based coder
def rule(i, f):
    tags = {e["tag"] for e in ex[i]["extracts"].get("expl", [])}
    p, a = (f + "_P") in tags, (f + "_A") in tags
    return "P" if p and not a else ("A" if a and not p else "U")


allinc = [i for i, c in first.items() if ok(i, c)]
L += ["", "**与独立规则编码器的一致性**（规则编码器只看显式模式命中：`F1_P/F1_A/F2_P/F2_A`；全部 %d 篇纳入论文）" % len(allinc), ""]
for f in ("F1", "F2"):
    pairs = [(first[i][f], rule(i, f)) for i in allinc if first[i][f] != "N" or rule(i, f) != "U"]
    det = [(x, y) for x, y in pairs if x in "PA" and y in "PA"]
    L.append("- %s：规则编码器判定（P/A）%d 篇；两者都能判定的 %d 篇中一致 %d 篇（%.0f%%），κ = %.2f。AI 判 A 而规则无命中的 %d 篇属于规则编码器漏判（只覆盖显式句型）。" % (
        f, sum(1 for _, y in pairs if y in "PA"), len(det), sum(x == y for x, y in det), 100.0 * sum(x == y for x, y in det) / max(len(det), 1),
        kappa([x for x, _ in det], [y for _, y in det]) if len(det) > 1 else float("nan"), sum(1 for x, y in pairs if x == "A" and y == "U")))
open(os.path.join(ROOT, "audit", "RELIABILITY.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
print("\n".join(L))
