### 编码可靠性（盲复编码 + 规则编码器）

**盲复编码**：从 239 篇抽样中按固定种子取 40 篇（只取 PMC1xxxxxxx 号段——PMC8/PMC9 号段的首轮编码行曾在我的工作上下文中显示过，复编码不再盲，故排除），仅看抽取句子、不看首轮编码，按同一份手册重新编码；与首轮逐篇比较。这是**同一编码者两次编码的一致性**（intra-rater），**不是**独立第二编码者；独立人工核对表见 `audit/verification_sheet.csv`。

- 纳入判断一致：35/40 = 88%（κ = 0.00）；两次都编为纳入且满足全文术语阈值（进化类 ≥ 5、特征选择 ≥ 3）的论文 35 篇。

| 编码 | 篇数 | 完全一致 | 原始一致率 | Cohen κ [95% 自助区间] | 两次编码的分布（首轮 P/A/U/N → 复编 P/A/U/N） |
|---|---:|---:|---:|---|---|
| F1 | 35 | 35 | 100% | 1.00 [1.00, 1.00] | 0/5/30/0 → 0/5/30/0 |
| F2 | 35 | 35 | 100% | 1.00 [1.00, 1.00] | 0/1/5/29 → 0/1/5/29 |
| F3 | 35 | 34 | 97% | 0.65 [0.00, 1.00] | 0/0/2/33 → 0/0/1/34 |
| F4 | 35 | 32 | 91% | 0.62 [-0.03, 1.00] | 0/5/30/0 → 0/4/31/0 |
| F5 | 35 | 34 | 97% | 0.94 [0.80, 1.00] | 0/13/22/0 → 0/14/21/0 |
| F6 | 35 | 33 | 94% | 0.84 [0.59, 1.00] | 1/1/6/27 → 0/1/6/28 |

- **"至少一项明确缺陷（P）"**（决定正文头条数字）：首轮 1/35，复编 0/35，一致 34/35。
- **F1 无法判断（U）的比例**：首轮 86%，复编 86%（决定"报告不透明"这一头条结论）。

不一致的条目（共 7 处）：

- PMC10354005 F3：首轮 U → 复编 N（首轮证据：stratified 10-fold CV each generation; no test set mentioned；复编证据：10-fold CV inside fitness; Pareto ranking by rule; final test not stat）
- PMC10354005 F4：首轮 U → 复编 A（首轮证据：stratified 10-fold CV each generation; no test set mentioned；复编证据：10-fold CV inside fitness; Pareto ranking by rule; final test not stat）
- PMC11680579 F4：首轮 A → 复编 U（首轮证据：100 independent runs on benchmarks; FS minor part；复编证据：test functions run 100 times; protocol not shown）
- PMC13447636 F4：首轮 A → 复编 U（首轮证据：FS exclusively on training data; pipeline repeated three times；复编证据：FS exclusively on training data; 5-fold inside training）
- PMC10280564 F5：首轮 U → 复编 A（首轮证据：no protocol sentences found；复编证据：test set exists; FS data not stated）
- PMC11288465 F6：首轮 U → 复编 N（首轮证据：hyperparameters tuned on the testing set; augmentation timing not stat；复编证据：80/20; hyperparameters tuned on the test set (noted)）
- PMC13358131 F6：首轮 P → 复编 U（首轮证据：10 runs mean reported; main EEG dataset not partitioned subject-wise (；复编证据：10 runs mean+-sd; primary dataset 284 patients split unit not stated）

**与独立规则编码器的一致性**（规则编码器只看显式模式命中：`F1_P/F1_A/F2_P/F2_A`；全部 211 篇纳入论文）

- F1：规则编码器判定（P/A）41 篇；两者都能判定的 24 篇中一致 22 篇（92%），κ = 0.47。AI 判 A 而规则无命中的 20 篇属于规则编码器漏判（只覆盖显式句型）。
- F2：规则编码器判定（P/A）10 篇；两者都能判定的 6 篇中一致 6 篇（100%），κ = 1.00。AI 判 A 而规则无命中的 6 篇属于规则编码器漏判（只覆盖显式句型）。
