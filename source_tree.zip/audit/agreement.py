"""Sanity check of the AI hand-coding against an independent rule-based coder that only looks at the explicit-pattern hits."""
import json
import os
from collections import Counter

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ex = {json.loads(l)["pmcid"]: json.loads(l) for l in open(os.path.join(ROOT, "audit", "extracts.jsonl"), encoding="utf-8")}
cod = [json.loads(l) for l in open(os.path.join(ROOT, "audit", "coding_v1.jsonl"), encoding="utf-8")]
cod = [c for c in cod if c["incl"] == 1 and ex[c["pmcid"]]["flags"]["ec_terms"] >= 5 and ex[c["pmcid"]]["flags"]["fs_terms"] >= 3]


def rule(r, f):
    tags = {e["tag"] for e in r["extracts"].get("expl", [])}
    p, a = (f + "_P") in tags, (f + "_A") in tags
    return "P" if p and not a else ("A" if a and not p else "U")


def kappa(pairs):
    n = len(pairs)
    cats = sorted({x for p in pairs for x in p})
    po = sum(1 for a, b in pairs if a == b) / n
    pe = sum((sum(1 for a, _ in pairs if a == c) / n) * (sum(1 for _, b in pairs if b == c) / n) for c in cats)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


for f in ("F1", "F2"):
    pairs = [(c[f], rule(ex[c["pmcid"]], f)) for c in cod if c[f] != "N" or rule(ex[c["pmcid"]], f) != "U"]
    both = [(a, b) for a, b in pairs if a in "PA" and b in "PA"]
    cm = Counter(pairs)
    print(f, "n=%d" % len(pairs), "| rule says P/A on %d papers; of those where BOTH are P/A (%d): agree %d (%.0f%%)" % (
        sum(1 for _, b in pairs if b in "PA"), len(both), sum(1 for a, b in both if a == b), 100.0 * sum(1 for a, b in both if a == b) / max(len(both), 1)),
        "| kappa(both determinate) = %.2f" % (kappa(both) if len(both) > 1 else float("nan")))
    print("   confusion (AI, rule):", dict(cm))
    dis = [c["pmcid"] for c in cod if c[f] in "PA" and rule(ex[c["pmcid"]], f) in "PA" and c[f] != rule(ex[c["pmcid"]], f)]
    print("   disagreements:", dis)
