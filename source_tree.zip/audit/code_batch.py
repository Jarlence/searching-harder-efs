"""Append hand-coded audit lines to audit/coding_v1.jsonl.
usage: python code_batch.py batch_file.txt
line format:  PMCID|incl|F1|F2|F3|F4|F5|F6|validation|evidence (free text, <=25 words)
codes: P present / A absent / U unclear / N not applicable;  incl: 1 include, 0 exclude (reason in evidence)"""
import json
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUT = os.path.join(ROOT, "audit", "coding_v1.jsonl")
VALID = set("PAUN")
seen = {}
if os.path.exists(OUT):
    for l in open(OUT, encoding="utf-8"):
        d = json.loads(l); seen[d["pmcid"]] = d
n = 0
for line in open(sys.argv[1], encoding="utf-8"):
    line = line.strip()
    if not line or line.startswith("#"):
        continue
    p = [x.strip() for x in line.split("|")]
    if len(p) < 9:
        raise SystemExit("bad line: " + line)
    pmcid, incl, codes, val, ev = p[0], p[1], p[2:8], p[8], (p[9] if len(p) > 9 else "")
    assert incl in ("0", "1"), line
    for c in codes:
        assert c in VALID, line
    seen[pmcid] = dict(pmcid=pmcid, incl=int(incl), F1=codes[0], F2=codes[1], F3=codes[2], F4=codes[3], F5=codes[4],
                       F6=codes[5], validation=val, evidence=ev)
    n += 1
with open(OUT, "w", encoding="utf-8") as f:
    for d in seen.values():
        f.write(json.dumps(d, ensure_ascii=False) + "\n")
print("coded this batch: %d   total coded: %d" % (n, len(seen)))
