"""Fetch Europe PMC full text (JATS XML) for the sampled papers IN MEMORY and keep only protocol-relevant sentences.
Full texts are not stored; the extracts (verbatim sentences, <= 420 chars) + metadata + licence go to extracts.jsonl."""
import json
import os
import re
import sys
import time
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
UA = {"User-Agent": "t1-audit/1.0"}

I = re.I
CATS = {
    "split": re.compile(r"(\d+|ten|five)[- ]fold|k-?fold|cross[- ]validat|hold-?out|leave[- ]one[- ](out|subject|patient)|"
                        r"\b(train(ing)?|test(ing)?|validation)\b[^.]{0,40}\b(set|data|part|portion|subset)\b|\bsplit\b|"
                        r"\d{2}\s*%[^.]{0,40}(train|test)", I),
    "fs_when": re.compile(r"feature selection|selected features|feature subset|selecting features", I),
    "fs_when_ctx": re.compile(r"\b(before|prior to|after|within|inside|inner|nested|each fold|each iteration|each run|training "
                              r"(set|data|part|fold|portion|subset)|entire|whole|full|all (the )?(data|samples|instances|dataset)|"
                              r"test(ing)? (set|data)|leak\w*)\b", I),
    "resample": re.compile(r"\bSMOTE\b|ADASYN|oversampl|over-sampl|undersampl|under-sampl|\bresampl|\bre-sampl|"
                           r"balanc(ed|ing) (the )?(training )?(data|dataset|classes|set)|data augmentation|synthetic (minority|samples)", I),
    "pareto": re.compile(r"pareto|non-?dominated|\bknee\b|trade-?off|final solution|best solution|solution[^.]{0,30}(selected|chosen)", I),
    "runs": re.compile(r"independent runs?|\b\d+ runs\b|runs of|repeated \d+|\b\d+ times\b|different seeds?|random seeds?|averaged over|"
                       r"mean (and|±)|standard deviation|best (result|accuracy|performance|fitness)|worst", I),
    "group": re.compile(r"\bsubjects?\b|\bpatients?\b|participants?|recordings?|sessions?|speakers?|bearings?|machines?|repeated measure|"
                        r"per subject|subject-wise|patient-wise|\bLOSO\b|leave-one-subject|record-wise|same (person|individual|patient)", I),
    "nested": re.compile(r"\bnested\b|inner (loop|fold|cross)|outer (loop|fold)|double cross", I),
}
_ALLD = r"(entire|whole|full|complete|original|all (of )?the)\s+(data\s?set|data|samples|instances)"
_TRN = r"(training|train)\s+(set|data|part|portion|fold|subset|samples|dataset)"
_FSW = r"(feature selection|feature subset|selected features|feature reduction|wrapper|fitness)"
EXPL = {
    "F1_P": [re.compile(_ALLD + r"[^.]{0,110}" + _FSW, I), re.compile(_FSW + r"[^.]{0,110}" + _ALLD, I),
             re.compile(r"(before|prior to)\s+(splitting|dividing|partition\w*|the (train|split|cross))", I),
             re.compile(_FSW + r"[^.]{0,70}(before|prior to)[^.]{0,40}(split|divid|partition|cross|classif)", I)],
    "F1_A": [re.compile(_FSW + r"[^.]{0,110}" + _TRN, I), re.compile(_TRN + r"[^.]{0,110}" + _FSW, I),
             re.compile(r"within (each|every) (fold|iteration|split)|inside (each|the) (fold|loop)|\bnested\b|inner (loop|cross)", I),
             re.compile(r"(validation|monitoring) set[^.]{0,80}" + _FSW, I)],
    "F2_P": [re.compile(r"(SMOTE|oversampl\w*|over-sampl\w*|undersampl\w*|under-sampl\w*|resampl\w*|ADASYN)[^.]{0,120}" + _ALLD, I),
             re.compile(r"(SMOTE|oversampl\w*|undersampl\w*|resampl\w*|balanc\w+ (the )?(data|dataset|classes))[^.]{0,80}"
                        r"(before|prior to)[^.]{0,40}(split|divid|partition|cross|train)", I)],
    "F2_A": [re.compile(r"(SMOTE|oversampl\w*|over-sampl\w*|undersampl\w*|under-sampl\w*|resampl\w*|ADASYN|augment\w*)[^.]{0,120}"
                        r"(only|solely)?[^.]{0,20}(training|train|each fold)", I)],
}
FLAGS = {
    "ec_terms": re.compile(r"genetic algorithm|evolutionary|swarm|differential evolution|metaheuristic|meta-heuristic|nature-inspired|"
                           r"bio-inspired|\bPSO\b|\bGA\b|\bNSGA|grey wolf|gray wolf|whale optim|harris hawk|firefly|ant colony|"
                           r"bat algorithm|cuckoo|optimi[sz]ation algorithm", I),
    "fs_terms": re.compile(r"feature selection|feature subset|selected features|selecting features", I),
    "nested": CATS["nested"],
    "stats_test": re.compile(r"wilcoxon|friedman|t-test|mann-whitney|nemenyi|kruskal|anova", I),
    "code": re.compile(r"github|zenodo|figshare|code (is|are) (publicly )?available|supplementary code|source code", I),
    "leak_claim": re.compile(r"data leakage|information leakage|leakage", I),
}


def fetch(pmcid, tries=4):
    u = "https://www.ebi.ac.uk/europepmc/webservices/rest/%s/fullTextXML" % pmcid
    for a in range(tries):
        try:
            return urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=90).read()
        except Exception:  # noqa: BLE001
            time.sleep(1.5 * (a + 1))
    return None


def paragraphs(root):
    out = []

    def walk(el, path):
        for ch in el:
            tag = ch.tag.split("}")[-1]
            if tag in ("ref-list", "table-wrap", "fig", "app-group", "ack", "fn-group", "back"):
                continue
            if tag == "sec":
                t = ch.find("title")
                walk(ch, path + [("".join(t.itertext()).strip() if t is not None else "")])
            elif tag == "p":
                out.append((" > ".join(x for x in path if x), re.sub(r"\s+", " ", "".join(ch.itertext())).strip()))
            else:
                walk(ch, path)
    body = root.find(".//body")
    if body is not None:
        walk(body, [])
    return out


SENT = re.compile(r"(?<=[.!?])\s+(?=[A-Z(\[])")
BAD_SEC = re.compile(r"introduction|related work|literature|background|review of|discussion|conclusion|limitation|future work|"
                     r"motivation|abstract", I)
LIMIT_SEC = re.compile(r"discussion|limitation|conclusion|future", I)
LIMIT_PAT = re.compile(r"leakage|over-?fit|optimis(tic|m)|bias|generali[sz]|independent (test|dataset|cohort|validation)|"
                       r"external (validation|dataset)|unseen", I)


def sentences(par):
    res = []
    for sec, txt in par:
        for s in SENT.split(txt):
            s = s.strip()
            if 25 <= len(s) <= 900:
                res.append((sec, s))
    return res


def extract(rec, per_cat=3):
    raw = fetch(rec["pmcid"])
    if raw is None:
        return dict(rec, error="fetch failed")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return dict(rec, error="xml parse failed")
    art = root if root.tag.split("}")[-1] == "article" else root.find(".//article")
    atype = art.get("article-type") if art is not None else None
    par = paragraphs(root)
    sents = sentences(par)
    text_all = " ".join(s for _, s in sents)
    flags = {k: len(p.findall(text_all)) for k, p in FLAGS.items()}
    ex, used = {}, set()
    for cat, pat in CATS.items():
        if cat == "fs_when_ctx":
            continue
        scored = []
        for i, (sec, s) in enumerate(sents):
            if BAD_SEC.search(sec):                      # sentences about OTHER people's work live in intro / discussion
                continue
            if cat == "fs_when":
                if not (pat.search(s) and CATS["fs_when_ctx"].search(s)):
                    continue
                sc = len(set(m.group(0).lower() for m in CATS["fs_when_ctx"].finditer(s)))
            else:
                ms = set(m.group(0).lower() for m in pat.finditer(s))
                if not ms:
                    continue
                sc = len(ms)
            meth = 1 if re.search(r"method|material|experiment|implementation|setup|data|evaluation|protocol", sec, I) else 0
            scored.append((-(sc + meth), i, sec, s))
        scored.sort()
        ex[cat] = []
        for _, i, sec, s in scored:
            if i in used:
                continue
            ex[cat].append(dict(sec=sec[:60], text=s[:420])); used.add(i)
            if len(ex[cat]) >= per_cat:
                break
    lim = []
    for i, (sec, s) in enumerate(sents):
        if LIMIT_SEC.search(sec) and LIMIT_PAT.search(s):
            lim.append(dict(sec=sec[:60], text=s[:420]))
            if len(lim) >= 3:
                break
    ex["limits"] = lim
    expl = []
    for tag, pats in EXPL.items():
        n = 0
        for sec, s in sents:
            if BAD_SEC.search(sec):
                continue
            if any(p.search(s) for p in pats):
                expl.append(dict(tag=tag, sec=sec[:60], text=s[:420])); n += 1
                if n >= 2:
                    break
    ex["expl"] = expl
    jt = root.find(".//journal-title")
    journal = "".join(jt.itertext()).strip() if jt is not None else rec.get("journal")
    return dict(rec, journal=journal, article_type=atype, n_sentences=len(sents), flags=flags, extracts=ex)


def main():
    sample = json.load(open(os.path.join(ROOT, "audit", "sample.json"), encoding="utf-8"))
    out_path = os.path.join(ROOT, "audit", "extracts.jsonl")
    done = set()
    if os.path.exists(out_path):
        done = {json.loads(l)["pmcid"] for l in open(out_path, encoding="utf-8")}
    todo = [r for r in sample if r["pmcid"] not in done]
    print("todo", len(todo), flush=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=4) as ex, open(out_path, "a", encoding="utf-8") as f:
        for i, r in enumerate(ex.map(extract, todo)):
            f.write(json.dumps(r, ensure_ascii=False) + "\n"); f.flush()
            if (i + 1) % 20 == 0:
                print(i + 1, "%.0fs" % (time.time() - t0), flush=True)


if __name__ == "__main__":
    main()
