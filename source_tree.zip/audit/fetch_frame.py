"""Europe PMC sampling frame + seeded stratified sample for the protocol audit (reads metadata only)."""
import json
import os
import sys
import urllib.parse
import urllib.request

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))
from efsbench.splits import rng_for  # noqa: E402

UA = {"User-Agent": "t1-audit/1.0"}
FS = '(TITLE_ABS:"feature selection" OR TITLE_ABS:"feature subset selection" OR TITLE_ABS:"selecting features")'
EC = ('(TITLE_ABS:evolutionary OR TITLE_ABS:"genetic algorithm" OR TITLE_ABS:"particle swarm" OR TITLE_ABS:metaheuristic OR '
      'TITLE_ABS:"meta-heuristic" OR TITLE_ABS:"swarm intelligence" OR TITLE_ABS:"differential evolution" OR TITLE_ABS:NSGA OR '
      'TITLE_ABS:"grey wolf" OR TITLE_ABS:"gray wolf" OR TITLE_ABS:"whale optimization" OR TITLE_ABS:"harris hawks" OR '
      'TITLE_ABS:"nature-inspired" OR TITLE_ABS:"bio-inspired" OR TITLE_ABS:"optimization algorithm" OR TITLE_ABS:"firefly" OR '
      'TITLE_ABS:"ant colony" OR TITLE_ABS:"bat algorithm" OR TITLE_ABS:"cuckoo search")')
QUERY = FS + " AND " + EC + " AND OPEN_ACCESS:y AND HAS_FT:y AND PUB_YEAR:[2021 TO 2026]"


def main(n_sample=240):
    recs, cursor = [], "*"
    while True:
        u = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urllib.parse.urlencode(
            {"query": QUERY, "format": "json", "resultType": "core", "pageSize": 200, "cursorMark": cursor})
        d = json.load(urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=120))
        rs = d["resultList"]["result"]
        for x in rs:
            if x.get("pmcid"):
                recs.append(dict(pmcid=x["pmcid"], year=int(x.get("pubYear") or 0), journal=x.get("journalTitle"),
                                 title=x.get("title"), doi=x.get("doi"), license=x.get("license"),
                                 abstract=(x.get("abstractText") or "")[:1500]))
        nxt = d.get("nextCursorMark")
        if not rs or not nxt or nxt == cursor:
            break
        cursor = nxt
    seen, uniq = set(), []
    for r in recs:
        if r["pmcid"] not in seen:
            seen.add(r["pmcid"]); uniq.append(r)
    print("frame:", len(uniq))
    with open(os.path.join(ROOT, "audit", "frame.jsonl"), "w", encoding="utf-8") as f:
        for r in uniq:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    # drop obvious reviews / surveys by title, then proportional stratified sample by year (seeded)
    import re
    rev = re.compile(r"\b(review|survey|systematic|meta-analysis|bibliometric|overview|perspective)\b", re.I)
    cand = [r for r in uniq if not rev.search(r["title"] or "")]
    print("after title-based review filter:", len(cand))
    rng = rng_for("audit_sample", 2026)
    by_year = {}
    for r in cand:
        by_year.setdefault(r["year"], []).append(r)
    sample = []
    for y, lst in sorted(by_year.items()):
        k = max(1, int(round(n_sample * len(lst) / len(cand))))
        idx = rng.permutation(len(lst))[:k]
        sample += [lst[i] for i in sorted(idx)]
    print("sample:", len(sample), {y: sum(1 for s in sample if s["year"] == y) for y in sorted(by_year)})
    with open(os.path.join(ROOT, "audit", "sample.json"), "w", encoding="utf-8") as f:
        json.dump(sample, f, ensure_ascii=False, indent=0)


if __name__ == "__main__":
    main()
