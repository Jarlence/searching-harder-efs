"""Print a compact reading view of audit extracts.  usage: python show.py START COUNT"""
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
rows = [json.loads(l) for l in open(os.path.join(ROOT, "audit", "extracts.jsonl"), encoding="utf-8")]
rows.sort(key=lambda r: r["pmcid"])
a, n = int(sys.argv[1]), int(sys.argv[2])
W = int(sys.argv[3]) if len(sys.argv) > 3 else 210
for r in rows[a:a + n]:
    print("=" * 100)
    print("%s | %s | %s | %s" % (r["pmcid"], r["year"], (r.get("journal") or "")[:28], (r["title"] or "")[:95]))
    print("   flags: nested=%d stats=%d code=%d leak_word=%d" % tuple(r["flags"][k] for k in ("nested", "stats_test", "code", "leak_claim")))
    for e in r["extracts"].get("expl", []):
        print("  <<%s>> %s" % (e["tag"], e["text"][:W + 60]))
    keep = {"pareto": re.compile(r"pareto|non-?dominated|knee|multi-?objective", re.I),
            "runs": re.compile(r"\b\d+ (independent )?(runs|times)|independent runs|seeds|best (result|accuracy)", re.I),
            "group": re.compile(r"subjects?|patients?|participants?|recordings?|sessions?|speakers?|bearings?|per (subject|patient)", re.I)}
    for cat, k in (("split", 2), ("fs_when", 1), ("resample", 1), ("pareto", 1), ("runs", 1), ("group", 1), ("limits", 1)):
        shown = 0
        for e in r["extracts"].get(cat, []):
            if cat in keep and not keep[cat].search(e["text"]):
                continue
            print("  [%-8s] %s" % (cat, e["text"][:W]))
            shown += 1
            if shown >= k:
                break
