"""Audit codes = first-pass coding (coding_v1.jsonl, frozen, never edited) + the F1 corrections found by the full-text recall check
(recheck_overrides.jsonl; audit/RECALL_CHECK.md).  load("v1") returns the first pass, load("v1.1") the corrected codes (default)."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def load(version="v1.1"):
    cod = [json.loads(l) for l in open(os.path.join(HERE, "coding_v1.jsonl"), encoding="utf-8")]
    if version == "v1":
        return cod
    path = os.path.join(HERE, "recheck_overrides.jsonl")
    ov = {}
    if os.path.exists(path):
        ov = {r["pmcid"]: r for r in (json.loads(l) for l in open(path, encoding="utf-8"))}
    for c in cod:
        o = ov.get(c["pmcid"])
        if o:
            c["F1_v1"] = c["F1"]
            c["F1"] = o["F1"]
            c["evidence"] = c["evidence"] + " || recheck (" + o["where"] + "): " + o["evidence"]
    return cod
