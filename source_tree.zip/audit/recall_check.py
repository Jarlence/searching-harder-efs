"""Recall check of the audit extraction (written after an external review pointed out that 'not extracted' is not 'not stated').

The first pass (extract.py) skipped tables, figure captions, appendices and back matter, skipped intro / discussion / conclusion sections for
the category sentences and showed the coder at most three sentences per category.  Here the FULL text (everything except the reference list) of every
included paper is re-fetched in memory from Europe PMC (open-access JATS, as in extract.py; nothing but short sentences is stored) and every
sentence that looks like a statement about WHEN / ON WHICH SAMPLES features were selected is collected, with its location.  We then count, for
the papers coded F1 = U (not stated), how many contain such sentences that the coder never saw.

    python audit/recall_check.py            ->  audit/recall_check.jsonl, audit/RECALL_CHECK.md"""
import json
import os
import re
import sys
import time
import xml.etree.ElementTree as ET
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import extract as EX  # noqa: E402

ROOT = EX.ROOT
I = re.I
FS = r"(feature selection|feature subset|selected features|selecting features|feature reduction|wrapper|fitness|optimi[sz]ation (process|algorithm))"
TRN = r"(training|train)\s+(set|data|part|portion|fold|subset|samples|dataset|split|phase|instances)"
ALLD = r"(entire|whole|full|complete|original|all (of )?the|all)\s+(data\s?set|dataset|data|samples|instances|records)"
STRONG = [
    re.compile(FS + r"[^.]{0,120}" + TRN, I), re.compile(TRN + r"[^.]{0,120}" + FS, I),
    re.compile(FS + r"[^.]{0,120}" + ALLD, I), re.compile(ALLD + r"[^.]{0,120}" + FS, I),
    re.compile(r"(before|prior to)\s+(the\s+)?(splitting|dividing|partition\w*|data split|train|cross[- ]validation|classification)", I),
    re.compile(FS + r"[^.]{0,80}(before|prior to|after)[^.]{0,40}(split|divid|partition|cross|classif|train)", I),
    re.compile(r"\bnested\b|inner (loop|fold|cross)|outer (loop|fold)|double cross|within (each|every) (fold|iteration|split)|inside (each|the) (fold|loop)", I),
    re.compile(r"(validation|monitoring) (set|data)[^.]{0,80}" + FS, I),
    re.compile(r"leakage", I),
    re.compile(r"(independent|separate|unseen|held-?out|hold-?out) (test|testing|validation)[^.]{0,80}(set|data|samples)", I),
]
SENT = EX.SENT


def text_of(el):
    return re.sub(r"\s+", " ", "".join(el.itertext())).strip()


def parse_full(raw):
    """every sentence of the article except the reference list, with a location tag"""
    root = ET.fromstring(raw)
    parent = {}
    for p in root.iter():
        for c in p:
            parent[c] = p
    out = []

    def tag(el):
        return el.tag.split("}")[-1]

    def loc_of(el):
        chain, sec = [], ""
        cur = el
        while cur in parent:
            cur = parent[cur]
            t = tag(cur)
            chain.append(t)
            if t == "sec" and not sec:
                tt = cur.find("title")
                sec = text_of(tt) if tt is not None else ""
        if "ref-list" in chain:
            return None, sec
        if "table-wrap" in chain:
            return "table", sec
        if "fig" in chain:
            return "figure-caption", sec
        if "app" in chain or "app-group" in chain:
            return "appendix", sec
        if "abstract" in chain:
            return "abstract", sec
        if "back" in chain:
            return "back", sec
        if "boxed-text" in chain:
            return "box", sec
        if EX.BAD_SEC.search(sec):
            return "body-intro/discussion", sec
        return "body", sec

    seen = set()
    for el in root.iter():
        t = tag(el)
        if t in ("p", "caption", "td", "th", "title") and t != "title":
            if t in ("td", "th"):
                continue                                       # table cells are joined below
            loc, sec = loc_of(el)
            if loc is None:
                continue
            if t == "caption":
                txt = text_of(el)
                for s in SENT.split(txt):
                    s = s.strip()
                    if len(s) >= 25 and (loc, s) not in seen:
                        seen.add((loc, s)); out.append((loc, sec, s))
                continue
            # a <p> inside a caption is handled by the caption; avoid double counting
            if parent.get(el) is not None and tag(parent[el]) == "caption":
                continue
            txt = text_of(el)
            for s in SENT.split(txt):
                s = s.strip()
                if len(s) >= 25 and (loc, s) not in seen:
                    seen.add((loc, s)); out.append((loc, sec, s))
    for tw in root.iter():
        if tag(tw) == "table-wrap":
            loc, sec = loc_of(tw)
            if loc is None:
                continue
            for tb in tw.iter():
                if tag(tb) == "table":
                    for row in tb.iter():
                        if tag(row) == "tr":
                            txt = " | ".join(text_of(c) for c in row if tag(c) in ("td", "th"))
                            if len(txt) >= 25:
                                out.append(("table", sec, txt[:600]))
    return out


def candidates(sents):
    res = []
    for loc, sec, s in sents:
        if len(s) > 900:
            continue
        hit = [i for i, p in enumerate(STRONG) if p.search(s)]
        if hit:
            res.append(dict(loc=loc, sec=sec[:50], text=s[:420], pat=hit))
    return res


def norm(s):
    return re.sub(r"\W+", "", s.lower())[:70]


def one(rec):
    raw = EX.fetch(rec["pmcid"])
    if raw is None:
        return dict(pmcid=rec["pmcid"], error="fetch failed")
    try:
        sents = parse_full(raw)
    except ET.ParseError:
        return dict(pmcid=rec["pmcid"], error="xml parse failed")
    seen_by_coder = set()
    for cat, lst in rec["extracts"].items():
        for e in lst:
            seen_by_coder.add(norm(e["text"]))
    cands = candidates(sents)
    for c in cands:
        c["seen"] = norm(c["text"]) in seen_by_coder
    return dict(pmcid=rec["pmcid"], n_sent_full=len(sents), n_cand=len(cands), cands=cands[:40])


def main():
    ex = {}
    for l in open(os.path.join(HERE, "extracts.jsonl"), encoding="utf-8"):
        r = json.loads(l); ex[r["pmcid"]] = r
    cod = {}
    for l in open(os.path.join(HERE, "coding_v1.jsonl"), encoding="utf-8"):
        c = json.loads(l); cod[c["pmcid"]] = c
    inc = [p for p, c in cod.items() if c["incl"] == 1 and ex[p]["flags"]["ec_terms"] >= 5 and ex[p]["flags"]["fs_terms"] >= 3
           and ex[p].get("article_type") == "research-article"]
    out_path = os.path.join(HERE, "recall_check.jsonl")
    done = set()
    if os.path.exists(out_path):
        done = {json.loads(l)["pmcid"] for l in open(out_path, encoding="utf-8")}
    todo = [ex[p] for p in inc if p not in done]
    print("included", len(inc), "todo", len(todo), flush=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=4) as pool, open(out_path, "a", encoding="utf-8") as f:
        for i, r in enumerate(pool.map(one, todo)):
            f.write(json.dumps(r, ensure_ascii=False) + "\n"); f.flush()
            if (i + 1) % 20 == 0:
                print(i + 1, "%.0fs" % (time.time() - t0), flush=True)
    summarize(inc, cod)


def summarize(inc, cod):
    rows = {}
    for l in open(os.path.join(HERE, "recall_check.jsonl"), encoding="utf-8"):
        r = json.loads(l); rows[r["pmcid"]] = r
    err = [p for p in inc if "error" in rows.get(p, {"error": 1})]
    U = [p for p in inc if cod[p]["F1"] == "U" and p in rows and "error" not in rows[p]]
    L = ["# Recall check of the audit extraction (automatic)", "",
         "Full text (everything except the reference list) of the %d included papers was re-read; %d could not be fetched or parsed." % (len(inc), len(err)), ""]
    nU = len(U)
    new_any = [p for p in U if any(not c["seen"] for c in rows[p]["cands"])]
    new_loc = Counter()
    for p in U:
        locs = {c["loc"] for c in rows[p]["cands"] if not c["seen"]}
        for lc in locs:
            new_loc[lc] += 1
    L += ["Papers coded F1 = U (not stated) that were re-read: %d." % nU,
          "Of these, %d (%.0f%%) contain at least one sentence matching a pattern for 'when / on which samples were features selected' that the coder never saw."
          % (len(new_any), 100.0 * len(new_any) / max(nU, 1)), "",
          "Where the unseen candidate sentences are (papers with at least one in the location):", ""]
    for lc, n in new_loc.most_common():
        L.append("* %s: %d papers" % (lc, n))
    strong_body = [p for p in U if any((not c["seen"]) and c["loc"] == "body" and (set(c["pat"]) & {0, 1, 2, 3, 4, 5, 6, 7}) for c in rows[p]["cands"])]
    L += ["", "Papers with an unseen candidate in a methods-type body section (the coder's own territory; missed by the three-sentences-per-category cap or the ranking): %d." % len(strong_body)]
    others = [p for p in inc if cod[p]["F1"] in ("A", "P") and p in rows and "error" not in rows[p]]
    new_other = [p for p in others if any(not c["seen"] for c in rows[p]["cands"])]
    L += ["", "For comparison, papers coded F1 = A or P: %d, of which %d contain unseen candidate sentences." % (len(others), len(new_other))]
    open(os.path.join(HERE, "RECALL_CHECK.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
