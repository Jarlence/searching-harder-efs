"""Blind re-coding helper: pick a seeded random subset of the 239 sampled papers and print the same reading view as show.py
(extracts only - NO earlier codes).   usage: python recode_show.py START COUNT   (START/COUNT index into the 40-paper subset)"""
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(ROOT, "src"))
from efsbench.splits import rng_for  # noqa: E402

rows = [json.loads(l) for l in open(os.path.join(ROOT, "audit", "extracts.jsonl"), encoding="utf-8")]
rows.sort(key=lambda r: r["pmcid"])
# Papers PMC8xxxxxx / PMC9xxxxxx are excluded from the blind subset: their first-pass codes (batches b08, b09) had been displayed in my
# working context, so a re-code of them would not be blind.  The subset is the first 40 PMC1xxxxxxx papers of a seeded permutation.
perm = rng_for("audit_recode", 1).permutation(len(rows))
sub = [rows[int(i)] for i in perm if rows[int(i)]["pmcid"].startswith("PMC1")][:40]
sub.sort(key=lambda r: r["pmcid"])
done = set()
for f in os.listdir(os.path.join(ROOT, "audit", "recode")):
    if f.endswith(".txt"):
        for line in open(os.path.join(ROOT, "audit", "recode", f), encoding="utf-8"):
            if line.strip():
                done.add(line.split("|")[0])
todo = [r for r in sub if r["pmcid"] not in done]
if len(sys.argv) < 3:
    print("subset (%d):" % len(sub), ",".join(r["pmcid"] for r in sub)); print("not yet coded (%d):" % len(todo), ",".join(r["pmcid"] for r in todo)); raise SystemExit
a, n = int(sys.argv[1]), int(sys.argv[2])
sub = todo
W = 210
keep = {"pareto": re.compile(r"pareto|non-?dominated|knee|multi-?objective", re.I),
        "runs": re.compile(r"\b\d+ (independent )?(runs|times)|independent runs|seeds|best (result|accuracy)", re.I),
        "group": re.compile(r"subjects?|patients?|participants?|recordings?|sessions?|speakers?|bearings?|per (subject|patient)", re.I)}
for r in sub[a:a + n]:
    print("=" * 100)
    print("%s | %s | %s | %s" % (r["pmcid"], r["year"], (r.get("journal") or "")[:28], (r["title"] or "")[:95]))
    print("   flags: nested=%d stats=%d code=%d leak_word=%d ec_terms=%d fs_terms=%d type=%s" % (
        *[r["flags"][k] for k in ("nested", "stats_test", "code", "leak_claim", "ec_terms", "fs_terms")], r.get("article_type")))
    for e in r["extracts"].get("expl", []):
        print("  <<%s>> %s" % (e["tag"], e["text"][:W + 60]))
    for cat, k in (("split", 2), ("fs_when", 1), ("resample", 1), ("pareto", 1), ("runs", 1), ("group", 1), ("limits", 1)):
        shown = 0
        for e in r["extracts"].get(cat, []):
            if cat in keep and not keep[cat].search(e["text"]):
                continue
            print("  [%-8s] %s" % (cat, e["text"][:W]))
            shown += 1
            if shown >= k:
                break
