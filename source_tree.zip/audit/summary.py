"""Audit summary: detection rate of each protocol flaw with Wilson CIs, transparency, trends, plus a blind human-verification sheet and its key."""
import csv
import json
import math
import os
from collections import Counter

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ex = {}
for l in open(os.path.join(ROOT, "audit", "extracts.jsonl"), encoding="utf-8"):
    r = json.loads(l); ex[r["pmcid"]] = r
import sys  # noqa: E402
sys.path.insert(0, os.path.join(ROOT, "audit"))
import codes  # noqa: E402
cod = codes.load("v1.1")          # first-pass coding + the F1 corrections of the full-text recall check (audit/RECALL_CHECK.md, audit/recheck_overrides.jsonl)
cod_v1 = {c["pmcid"]: c for c in codes.load("v1")}


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def pct(k, n):
    return "%.1f%%" % (100.0 * k / n) if n else "-"


inc = []
for c in cod:
    r = ex[c["pmcid"]]
    ok = c["incl"] == 1 and r["flags"]["ec_terms"] >= 5 and r["flags"]["fs_terms"] >= 3 and r.get("article_type") == "research-article"
    c["_ok"] = ok; c["_year"] = r["year"]; c["_journal"] = r.get("journal"); c["_flags"] = r["flags"]; c["_title"] = r["title"]
    c["_doi"] = r.get("doi"); c["_lic"] = r.get("license")
    if ok:
        inc.append(c)
n = len(inc)
out = {"n_sampled": len(cod), "n_included": n, "excluded": [(c["pmcid"], c["incl"], c["_flags"]["ec_terms"], c["_flags"]["fs_terms"]) for c in cod if not c["_ok"]]}
NAMES = {"F1": "先选特征后划分 / 选择与评估共用数据", "F2": "先重采样后划分", "F3": "按测试集挑解", "F4": "只报最好一次",
         "F5": "无独立保留集（适应度即报告）", "F6": "单元泄漏（重复测量按记录划分）"}
lines = ["# 审计汇总（自动生成）", "", "抽样框 933 篇 → 抽样 %d 篇 → 纳入 %d 篇（进化类术语 ≥ 5 次、特征选择术语 ≥ 3 次、research-article、编码纳入标记为 1）。" % (len(cod), n), ""]
lines += ["| 缺陷 | P 存在 | A 不存在 | U 无法判断 | N 不适用 | P / 全部 | P / (P+A) [95% Wilson] |", "|---|---:|---:|---:|---:|---:|---|"]
stat = {}
for f in ("F1", "F2", "F3", "F4", "F5", "F6"):
    cnt = Counter(c[f] for c in inc)
    P, A, U, N = cnt["P"], cnt["A"], cnt["U"], cnt["N"]
    lo, hi = wilson(P, P + A)
    stat[f] = dict(P=P, A=A, U=U, N=N, p_all=P / n, p_assessable=(P / (P + A) if P + A else None), ci=(lo, hi))
    lines.append("| %s %s | %d | %d | %d | %d | %s | %s (%d/%d) [%.0f%%, %.0f%%] |" % (
        f, NAMES[f], P, A, U, N, pct(P, n), pct(P, P + A), P, P + A, 100 * lo, 100 * hi))
out["flaws"] = stat
out["F1_first_pass"] = dict(Counter(cod_v1[c["pmcid"]]["F1"] for c in inc))
out["F1_corrected_pmcids"] = [c["pmcid"] for c in inc if c.get("F1_v1")]

anyP = [c for c in inc if any(c[f] == "P" for f in ("F1", "F2", "F3", "F5", "F6"))]
safeguard = [c for c in inc if c["F1"] == "A"]
f1_known = [c for c in inc if c["F1"] in ("P", "A")]
lines += ["", "## 关键比例", ""]
lines.append("- 至少有一项**编码为明确缺陷**的案例（F1/F2/F3/F5/F6 任一为 P）：%d / %d = %s [%.0f%%, %.0f%%]" % (
    len(anyP), n, pct(len(anyP), n), 100 * wilson(len(anyP), n)[0], 100 * wilson(len(anyP), n)[1]))
lines.append("- F1（特征选择与评估的数据关系）**无法判断**：%d / %d = %s（是\"抽取句子与扩展文章文本检索的命中片段仍无法判定\"，不等于论文没写；首轮编码为 %d / %d = %s，复核纠正了 %d 篇）" % (
    stat["F1"]["U"], n, pct(stat["F1"]["U"], n), sum(1 for c in inc if cod_v1[c["pmcid"]]["F1"] == "U"), n, pct(sum(1 for c in inc if cod_v1[c["pmcid"]]["F1"] == "U"), n),
    sum(1 for c in inc if c.get("F1_v1"))))
lines.append("- F1 明确写出特征选择只用训练部分（A）：%d / %d = %s" % (len(safeguard), n, pct(len(safeguard), n)))
lines.append("- F1 可判定的论文中，明确存在缺陷的比例：%d / %d = %s [%.0f%%, %.0f%%]" % (
    stat["F1"]["P"], len(f1_known), pct(stat["F1"]["P"], len(f1_known)), 100 * stat["F1"]["ci"][0], 100 * stat["F1"]["ci"][1]))
resamp_used = [c for c in inc if c["F2"] != "N"]
lines.append("- 用了重采样 / 增强的论文：%d；其中交代了时点的（P 或 A）：%d；明确写 '只在训练部分'：%d；明确 '先重采样后划分'：%d" % (
    len(resamp_used), sum(1 for c in resamp_used if c["F2"] in "PA"), sum(1 for c in resamp_used if c["F2"] == "A"), sum(1 for c in resamp_used if c["F2"] == "P")))
flags = lambda k: sum(1 for c in inc if c["_flags"][k] > 0)
lines.append("- 全文出现嵌套 / 内层折 / 外层折相关词：%d / %d = %s；统计检验（Wilcoxon / Friedman 等）：%d = %s；提供代码链接：%d = %s；出现 'leakage' 一词：%d = %s" % (
    flags("nested"), n, pct(flags("nested"), n), flags("stats_test"), pct(flags("stats_test"), n), flags("code"), pct(flags("code"), n),
    flags("leak_claim"), pct(flags("leak_claim"), n)))

lines += ["", "## 按年份分组（F1 的构成）", "", "| 年份 | n | P | A | U | A / n |", "|---|---:|---:|---:|---:|---:|"]
groups = {"2021–2022": (2021, 2022), "2023–2024": (2023, 2024), "2025–2026": (2025, 2026)}
trend = {}
for g, (a, b) in groups.items():
    sub = [c for c in inc if a <= c["_year"] <= b]
    cnt = Counter(c["F1"] for c in sub)
    trend[g] = dict(n=len(sub), **{k: cnt[k] for k in "PAUN"})
    lines.append("| %s | %d | %d | %d | %d | %s |" % (g, len(sub), cnt["P"], cnt["A"], cnt["U"], pct(cnt["A"], len(sub))))
out["trend_F1"] = trend

lines += ["", "## 验证方案（描述性，取自编码的 validation 字段）", ""]
val = Counter()
for c in inc:
    v = c["validation"].lower()
    key = "嵌套 / 内层 CV" if ("nested" in v or "inner" in v or "within" in v) else (
        "k 折" if "fold" in v or "cv" in v else ("划分 hold-out" if ("split" in v or "holdout" in v or "train" in v or "test" in v) else "未说明 / 其他"))
    val[key] += 1
for k, v in val.most_common():
    lines.append("- %s：%d（%s）" % (k, v, pct(v, n)))
open(os.path.join(ROOT, "audit", "audit_summary.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
json.dump(out, open(os.path.join(ROOT, "audit", "audit_summary.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# human verification, BLIND version (after an external review): two independent readers read the FULL text of ~43 papers and fill in their own codes and
# the location + wording of their evidence; the AI codes are written to a separate key file that nobody opens before both readers are finished.
# Sample: every paper with an explicit flaw (any P), plus seeded random samples of 12 papers coded F1 = A and 20 coded F1 = U; the rows are shuffled.
import sys
sys.path.insert(0, os.path.join(ROOT, "src"))
from efsbench.splits import rng_for  # noqa: E402
rng = rng_for("audit_verify", 2)
anyP_ids = {c["pmcid"] for c in inc if any(c[f] == "P" for f in ("F1", "F2", "F3", "F5", "F6"))}
poolA = [c for c in inc if c["F1"] == "A" and c["pmcid"] not in anyP_ids]
poolU = [c for c in inc if c["F1"] == "U" and c["pmcid"] not in anyP_ids]
sel = [c for c in inc if c["pmcid"] in anyP_ids] + [poolA[int(k)] for k in rng.permutation(len(poolA))[:12]] + [poolU[int(k)] for k in rng.permutation(len(poolU))[:20]]
sel = [sel[int(k)] for k in rng.permutation(len(sel))]
with open(os.path.join(ROOT, "audit", "verification_sheet.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["编号", "pmcid", "year", "title", "link"] + ["读者%d_%s" % (r, c) for r in (1, 2) for c in ("F1(P/A/U)", "F2(P/A/U/N)", "F6(P/A/U/N)", "证据所在位置(章节/表/附录)", "证据原句")] + ["裁决后F1", "备注"])
    for k, c in enumerate(sel, 1):
        w.writerow([k, c["pmcid"], c["_year"], c["_title"], "https://pmc.ncbi.nlm.nih.gov/articles/%s/" % c["pmcid"]] + [""] * 10 + ["", ""])
with open(os.path.join(ROOT, "audit", "verification_key_DO_NOT_OPEN_BEFORE_CODING.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["编号", "pmcid", "F1", "F2", "F3", "F4", "F5", "F6", "分层", "evidence(AI)"])
    for k, c in enumerate(sel, 1):
        w.writerow([k, c["pmcid"], c["F1"], c["F2"], c["F3"], c["F4"], c["F5"], c["F6"], "anyP" if c["pmcid"] in anyP_ids else ("F1=A" if c["F1"] == "A" else "F1=U"), c["evidence"]])
out["verification_sample"] = dict(n=len(sel), n_anyP=len(anyP_ids), n_A=12, n_U=20)
json.dump(out, open(os.path.join(ROOT, "audit", "audit_summary.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("\n".join(lines))
