"""Second, broader recall pass (see RECALL_CHECK.md): for every paper coded F1 = U, collect every full-text sentence (not shown to the coder in the first pass)
that mentions an optimiser / feature-selection term AND a data-partition term.  Writes recall_broad.jsonl; the sentences are then read and F1 re-coded where an
explicit statement exists (recode_v1_1.jsonl)."""
import json, os, re, sys
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import extract as EX
import recall_check as RC
I = re.I
OPT = re.compile(r"feature selection|selected features|feature subset|selecting features|feature reduction|wrapper|fitness|genetic algorithm|\bGA\b|\bPSO\b|swarm|evolutionary|metaheuristic|"
                 r"meta-heuristic|differential evolution|optimi[sz]er|optimi[sz]ation algorithm|grey wolf|gray wolf|whale|harris hawk|firefly|ant colony|bat algorithm|cuckoo|\bNSGA|binary [a-z]+ optimi[sz]", I)
PART = re.compile(r"\btrain(ing)?\b|\btest(ing)?\b|validation|\bfolds?\b|\bsplit\b|hold-?out|partition|divided|\bsubsets?\b of the data|cross[- ]validat", I)
def main():
    ex = {}
    for l in open(os.path.join(HERE, "extracts.jsonl"), encoding="utf-8"):
        r = json.loads(l); ex[r["pmcid"]] = r
    cod = {}
    for l in open(os.path.join(HERE, "coding_v1.jsonl"), encoding="utf-8"):
        c = json.loads(l); cod[c["pmcid"]] = c
    U = [p for p, c in cod.items() if c["F1"] == "U" and c["incl"] == 1 and ex[p]["flags"]["ec_terms"] >= 5 and ex[p]["flags"]["fs_terms"] >= 3 and ex[p].get("article_type") == "research-article"]
    def one(p):
        raw = EX.fetch(p)
        if raw is None: return dict(pmcid=p, error="fetch")
        sents = RC.parse_full(raw)
        seen = {RC.norm(e["text"]) for lst in ex[p]["extracts"].values() for e in lst}
        out = []
        for loc, sec, s in sents:
            if loc in ("body", "body-intro/discussion", "appendix", "back", "box", "figure-caption", "abstract") and len(s) <= 700 and OPT.search(s) and PART.search(s) and RC.norm(s) not in seen:
                k = len(set(m.group(0).lower() for m in OPT.finditer(s))) + len(set(m.group(0).lower() for m in PART.finditer(s)))
                out.append(dict(loc=loc, sec=sec[:40], text=s[:420], score=k))
        out.sort(key=lambda d: (-int(d["loc"] == "body"), -d["score"]))
        return dict(pmcid=p, n=len(out), sents=out[:8])
    with ThreadPoolExecutor(max_workers=4) as pool, open(os.path.join(HERE, "recall_broad.jsonl"), "w", encoding="utf-8") as f:
        for r in pool.map(one, U):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("done", len(U))
if __name__ == "__main__":
    main()
