# X11c locally frozen additional-benchmark research materials

This archive contains the completed eight-dataset CUDA execution and its
reproducibility inputs. It is an additional-benchmark validation by the same
research team, **locally frozen and not established as publicly preregistered
before execution**. No upload or OSF operation is performed by this build.

## Scientific sample and fixed design

The validation sample is exactly **4,000 GPU jobs and 12,000 checkpoints**:
eight datasets × five searches × two fixed learners × ten repeats × five outer
folds. Budgets are 250, 1,000 and 4,000 requests. The three original contrasts,
dataset-level inference, ordinary 95% intervals and the fixed three-contrast
Bonferroni family intervals are retained. The completed results and decisions
are in `results/new_data_confirmation_gpu/REPORT.md` and `primary.csv`; raw job hashes are in
`results/new_data_confirmation_gpu/job_hashes.json`. The eight datasets remain separate from the old
13-dataset experiments. Uncertain effects retain their prespecified decisions.

## Execution version and interrupted history

The original plan and local CPU execution freeze precede the versioned CUDA
technical amendment. The GPU freeze is `docs/NEW_DATA_CONFIRMATION_GPU_EXECUTION_FREEZE.json`, SHA-256
`f3aac49226b2c2a9aede0081ad3eb8ad11ba43836d4dcfe78ef2b7be394512e0`. Learner calculations use CUDA float64 with
deterministic operations and TF32 disabled. NumPy search/RNG, training-only
scaler statistics, kNN argpartition and metrics are retained. GPU and CPU
floating-point search paths are not asserted to be bitwise equivalent.

All **684 CPU records are retained solely as interrupted execution history**
under `results/jobs_extra/X11c_local/`. They are not additional validation
samples and are not pooled into the GPU analysis. All 4,000 GPU jobs were run
under the GPU technical freeze and stored separately in
`results/jobs_extra/X11c_gpu/`. CUDA operation counters count learner/scaling
operations rather than individual kernel launches.

## Explicit archive inventory

- The GPU freeze's 44 source files and 33 data/provenance files, byte-matched
  against their frozen SHA-256 values.
- Three X11c freezes: original, local execution and GPU execution.
- All 4,000 GPU raw records and all 14 completed GPU analysis files.
- Three independent reviews: complete execution integrity (JSON and Markdown),
  independent statistics (JSON and Markdown), and interpretation (Markdown).
- The 684 interrupted CPU records, their original hash mapping in the frozen
  GPU test report, this README, the builder and the SHA-256 inventory.

The builder uses these explicit lists and frozen inventories. It never scans
the audit directory. Private audit verification files are excluded and are
not read or hashed.

## Verify the archive

`SHA256SUMS.txt` lists the SHA-256 of every other member. The checksum list
excludes itself to avoid a circular self-hash; its SHA-256 and the ZIP's
SHA-256, byte size and verified member count are in the adjacent external
`research_package_validation.json` receipt. The builder verifies every member
by streaming the completed ZIP, checks duplicate/path inventories and confirms
the preceding R22 archive's SHA-256 again after packaging.

After extraction, paths preserve their project-root layout. The frozen
execution command is `D:/Anaconda/envs/evolve/python.exe extras/run_extra7_gpu.py
--run --workers 1` (join the command onto one line). Reproduction requires the
frozen numerical and CUDA environment and all parent freezes. Existing records
are validated and skipped; use a separate extracted project copy for a new
execution rather than modifying archived records.

## Relationship to preceding research materials

The previous R22 archive is unchanged and is deliberately not nested in this
ZIP: `submission/asc/materials/ASC_reproducibility_r22_fd9b3a6c3d79e828.zip`; SHA-256 `640268a649ffce7e1c257aac16075e39ddc1548de7c6276f182ba889fad55cc9`. It contains the earlier study, not
additional X11c observations. This archive does not establish public release
or a new license for third-party datasets. Dataset source/provenance and their
upstream conditions remain in the included registry and access records.

The independent reviews check saved results; they do not claim to have rerun
all 4,000 jobs. Primary statistical decisions and interpretation should be
read from the completed report and the three independent reviews.
