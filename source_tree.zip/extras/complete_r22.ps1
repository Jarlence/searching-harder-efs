param(
    [int]$Workers = 6,
    [int]$PrerequisiteProcessId = 0
)
$ErrorActionPreference = 'Stop'
$experimentRoot = Split-Path -Parent $PSScriptRoot
$experimentPython = 'D:\Anaconda\envs\evolve\python.exe'
Set-Location -LiteralPath $experimentRoot

function Write-Phase([string]$Phase, [string]$Message) {
    $record = [ordered]@{
        phase = $Phase
        updated_utc = [DateTime]::UtcNow.ToString('o')
        message = $Message
        workers = $Workers
        supervisor_pid = $PID
    }
    $statusPath = Join-Path $experimentRoot 'results/r22_pipeline_status.json'
    $record | ConvertTo-Json | Set-Content -LiteralPath $statusPath -Encoding UTF8
    Write-Output ((Get-Date -Format 'o') + ' ' + $Phase + ': ' + $Message)
}

try {
    if ($PrerequisiteProcessId -gt 0) {
        $prefixProcess = Get-Process -Id $PrerequisiteProcessId -ErrorAction SilentlyContinue
        if ($null -ne $prefixProcess) {
            if ($prefixProcess.Path -ne $experimentPython) {
                throw 'The prerequisite process is not the expected experiment Python.'
            }
            Write-Phase 'resource_check' 'Waiting for the fixed first 50 jobs; no performance summaries are inspected.'
            $prefixProcess.WaitForExit()
        }
    }
    $errorDirectory = Join-Path $experimentRoot 'results/jobs_extra/X10s/errors'
    if ((Test-Path -LiteralPath $errorDirectory) -and
        @(Get-ChildItem -LiteralPath $errorDirectory -Filter '*.json' -File).Count -gt 0) {
        throw 'Experiment errors require inspection before continuation.'
    }
    Write-Phase 'running' 'Continuing the complete frozen 5350-job list.'
    & $experimentPython extras/run_extra6.py --workers $Workers
    if ($LASTEXITCODE -ne 0) { throw 'The experiment runner failed.' }
    Write-Phase 'analysis' 'Complete-coverage analysis and frozen-input verification.'
    & $experimentPython analysis/strict_scaling_r22.py
    if ($LASTEXITCODE -ne 0) { throw 'The frozen analysis failed.' }
    Write-Phase 'independent_verification' 'Rechecking the nine fixed estimands directly from raw jobs.'
    & $experimentPython analysis/verify_strict_scaling_r22.py
    if ($LASTEXITCODE -ne 0) { throw 'Independent verification failed.' }
    Write-Phase 'ready_for_manuscript_review' 'Experiment and numerical checks complete. The current manuscript and submission package have not been replaced; scientific interpretation and integration remain.'
} catch {
    Write-Phase 'failed' $_.Exception.Message
    Write-Error $_
    exit 1
}
