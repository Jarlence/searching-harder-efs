"""Quick start: honest (nested, leak-free) evaluation of an evolutionary wrapper vs its budget-matched random-search null.

    conda activate evolve        # or any env with numpy / scipy (sklearn only for the RF / L1 baselines)
    set PYTHONPATH=src           # (PowerShell:  $env:PYTHONPATH = "src")
    python examples/quickstart.py [dataset] [budget]

For every outer fold the standardisation, the inner folds and the whole search see the OUTER-TRAINING part only; the outer-test part is
used once, to score the subset chosen by the inner criterion.  `inner_err` is what a paper would report if it quoted the fitness;
`test_ba` is the honest number.  The difference is the over-statement of protocol B (docs/PROTOCOL.md)."""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import numpy as np  # noqa: E402

from efsbench import datasets as D, protocols as P, splits as S  # noqa: E402

ds = sys.argv[1] if len(sys.argv) > 1 else "colon"
budget = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
X, y, groups = D.load(ds)                       # groups is None unless the data set has repeated measures (parkinson)
print("%s: n=%d p=%d minority=%d" % (ds, *X.shape, int(y.sum())))
rows = {}
t0 = time.time()
for algo in ("ga", "rs"):
    fit, test = [], []
    for fold, (tr, te) in enumerate(S.make_folds(y, 5, S.rng_for("quickstart", ds), groups)):
        out = P.honest_core(X[tr], y[tr], X[te], y[te], algo, "ridge", ("qs_inner", ds, fold), ("qs_algo", ds, algo, fold), (budget,),
                            groups_tr=(groups[tr] if groups is not None else None))[budget]
        fit.append(1.0 - out["inner_err"]); test.append(out["test_ba"])
    rows[algo] = (np.mean(fit), np.mean(test))
print("budget = %d wrapper evaluations, ridge learner, 5 outer folds  (%.0f s)" % (budget, time.time() - t0))
for algo, (f, t) in rows.items():
    print("  %-3s  reported fitness BA %.3f   honest outer-test BA %.3f   over-statement %+.3f" % (algo, f, t, f - t))
print("An evolutionary wrapper is only worth reporting if its honest BA beats the matched random search 'rs' by more than the noise.")
